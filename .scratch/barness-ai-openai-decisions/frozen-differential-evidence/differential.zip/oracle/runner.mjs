// Frozen pi-ai runner for the barness-ai differential oracle.
//
// Reads one case from stdin, drives the frozen pi-ai against the local
// controlled Provider named by the case, and writes what pi observed to stdout:
// every event (serialized when received, so live partials are snapshots) and
// the final message. It never runs pi's own test suite.
//
// Isolation (spec Testing Decisions §2): before pi is loaded, every outgoing
// socket is restricted to loopback, so a misrouted request can never reach a
// real vendor; the caller passes a scrubbed environment and the runner refuses
// to start if credentials or endpoints leak in through it; the API key comes
// only from the case, and pi's provider-env lookup gets an explicit empty map.

import { createHash } from "node:crypto";
import { readdirSync, readFileSync, statSync } from "node:fs";
import net from "node:net";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const LEAKY_ENV = /(API_KEY|_TOKEN|_SECRET|BASE_URL|ENDPOINT|PROXY)$/i;
const SOURCE_SHA256 = "39a9951108d0e7faf60886302ce4bc953d8c51d5ebad22370301f23b29aa2504";
let controlledEndpoint;

// One case per API. A table entry is added when that protocol joins the
// oracle; each catalog is a provider's model data whose entries on
// catalogApi (default: the case's API) the case may name.
const APIS = {
	"openai-decisions": {
		api: "@earendil-works/pi-ai/api/openai-decisions",
		catalogs: [{ models: "@earendil-works/pi-ai/providers/openai.models", catalog: "OPENAI_CLASSIFIER_MODELS", type: "classifier" }],
	},
	"typesafe-system-one": {
		api: "@earendil-works/pi-ai/api/typesafe-system-one",
		catalogs: [{ models: "@earendil-works/pi-ai/providers/typesafe.models", catalog: "TYPESAFE_CLASSIFIER_MODELS", type: "classifier" }],
	},
	"openai-responses": {
		api: "@earendil-works/pi-ai/api/openai-responses",
		catalogs: [{ models: "@earendil-works/pi-ai/providers/openai.models", catalog: "OPENAI_MODELS" }],
	},
	"anthropic-messages": {
		api: "@earendil-works/pi-ai/api/anthropic-messages",
		catalogs: [{ models: "@earendil-works/pi-ai/providers/anthropic.models", catalog: "ANTHROPIC_MODELS" }],
	},
	"google-generative-ai": {
		api: "@earendil-works/pi-ai/api/google-generative-ai",
		catalogs: [{ models: "@earendil-works/pi-ai/providers/google.models", catalog: "GOOGLE_MODELS" }],
	},
	// pi's data lists OpenAI's models for Responses only; a pi user reaches
	// them over Chat Completions as a custom model with the API swapped,
	// which is what barness-ai's catalog lists (ADR-0013). DeepSeek's data
	// is pi's own Chat route, used as is (ADR-0015).
	"openai-completions": {
		api: "@earendil-works/pi-ai/api/openai-completions",
		catalogs: [
			{ models: "@earendil-works/pi-ai/providers/openai.models", catalog: "OPENAI_MODELS", catalogApi: "openai-responses" },
			{ models: "@earendil-works/pi-ai/providers/deepseek.models", catalog: "DEEPSEEK_MODELS" },
		],
	},
};

// catalogModels lists the models entry's catalogs serve on api, each with
// its API set to api.
async function catalogModels(api, entry) {
	const out = [];
	for (const c of entry.catalogs) {
		const catalog = (await import(c.models))[c.catalog];
		const listed = Object.values(catalog).filter((m) => m.type === (c.type ?? "chat") && m.api === (c.catalogApi ?? api));
		out.push(...listed.map((m) => ({ ...m, api })));
	}
	return out;
}

function fail(message) {
	process.stderr.write(`pi-oracle runner: ${message}\n`);
	process.exit(2);
}

function refuseLeakyEnv() {
	const leaked = Object.keys(process.env).filter((k) => LEAKY_ENV.test(k));
	if (leaked.length > 0) fail(`refusing to run with credential/endpoint environment variables: ${leaked.join(", ")}`);
}

function isLoopbackHost(host) {
	const bare = host.replace(/^\[|\]$/g, "");
	if (net.isIPv4(bare)) return bare.startsWith("127.");
	if (net.isIPv6(bare)) return bare === "::1";
	return false;
}

// installLoopbackGuard rejects every TCP connect whose target is not a
// loopback literal, and every IPC (path) connect. fetch (undici), http and the
// vendor SDKs all end up in net.Socket#connect.
function installLoopbackGuard() {
	const connect = net.Socket.prototype.connect;
	net.Socket.prototype.connect = function guardedConnect(...args) {
		let opts = args[0];
		if (Array.isArray(opts)) opts = opts[0];
		let host;
		if (opts !== null && typeof opts === "object") {
			if (opts.path !== undefined) throw new Error("pi-oracle loopback guard: IPC connect refused");
			host = opts.host ?? "localhost";
		} else if (typeof opts === "string" && Number.isNaN(Number(opts))) {
			throw new Error("pi-oracle loopback guard: IPC connect refused");
		} else {
			host = typeof args[1] === "string" ? args[1] : "localhost";
		}
		if (!isLoopbackHost(host)) throw new Error(`pi-oracle loopback guard: refusing non-loopback host ${host}`);
		const port = typeof opts === "object" ? opts.port : opts;
		if (!controlledEndpoint || host.replace(/^\[|\]$/g, "") !== controlledEndpoint.hostname.replace(/^\[|\]$/g, "") || Number(port) !== Number(controlledEndpoint.port)) {
			// undici connects from a later microtask; a synchronous throw there
			// escapes fetch's promise. Fail through the socket's error channel.
			process.nextTick(() => this.destroy(new Error("pi-oracle loopback guard: refusing target outside controlled loopback endpoint")));
			return this;
		}
		return connect.apply(this, args);
	};
}

async function readStdin() {
	const chunks = [];
	for await (const chunk of process.stdin) chunks.push(chunk);
	return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

// packageInfo reports the installed pi-ai version and a hash over its generated
// model data, so the Go side can refuse a copy that drifted from PROVENANCE.md.
function packageInfo() {
 const provenance = JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), "provenance.json"), "utf8"));
 if (provenance.pi_commit !== "abe508e1b89912adde45528136c3221eb69acdd7") fail("pi commit mismatch");
	const dist = dirname(fileURLToPath(import.meta.resolve("@earendil-works/pi-ai")));
	const pkg = JSON.parse(readFileSync(join(dist, "..", "package.json"), "utf8"));
	const dataDir = join(dist, "providers", "data");
	const hash = createHash("sha256");
	for (const name of readdirSync(dataDir).sort()) {
		const sum = createHash("sha256").update(readFileSync(join(dataDir, name))).digest("hex");
		hash.update(`${sum}  ${name}\n`);
	}
	// Hash every dist file, including source maps/types, in the same sorted
	// relative-path format as ADR-0004's source-equivalent rebuild.
	const sourceHash = createHash("sha256");
	for (const name of readdirSync(dist, { recursive: true }).filter((n) => statSync(join(dist, n)).isFile()).sort()) {
		const sum = createHash("sha256").update(readFileSync(join(dist, name))).digest("hex");
		sourceHash.update(`${sum}  ${name}\n`);
	}
	return { version: pkg.version, modelDataSha256: hash.digest("hex"), sourceSha256: sourceHash.digest("hex") };
}

// Refuse a stale or altered installation before any provider code runs.
// The Go caller checks the same identity on returned records as well.
function verifiedPackageInfo() {
	const provenance = JSON.parse(readFileSync(new URL("./provenance.json", import.meta.url), "utf8"));
	const info = packageInfo();
	if (info.version !== "1.1.0" || info.version !== provenance.pi_version) fail("version mismatch");
	if (info.modelDataSha256 !== provenance.model_data_sha256) fail("model data hash mismatch");
	if (info.sourceSha256 !== SOURCE_SHA256) fail("source hash mismatch");
	return info;
}

// thinkingBudgets evaluates pi's shared thinking budget rules
// (api/simple-options adjustMaxTokensForThinking) for each case. These rules
// have no Responses wire effect, so they are compared directly.
async function thinkingBudgets(cases) {
	const { adjustMaxTokensForThinking } = await import("@earendil-works/pi-ai/api/simple-options");
	return cases.map((c) => adjustMaxTokensForThinking(c.baseMaxTokens ?? undefined, c.modelMaxTokens, c.level, c.budgets));
}

// costs evaluates pi's calculateCost for each case, and reports the cost
// entry of each requested model, looked up by id in the catalog of every API
// in the oracle. Multiple tiers have no wire path in the oracle's protocols,
// so the rule is compared directly.
async function costs(input) {
	const { calculateCost } = await import("@earendil-works/pi-ai");
	const results = input.cases.map((c) => {
		const usage = { ...c.usage, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } };
		return calculateCost({ cost: c.cost }, usage);
	});
	const known = [];
	for (const [api, entry] of Object.entries(APIS)) {
		known.push(...(await catalogModels(api, entry)));
	}
	const models = {};
	for (const id of input.models ?? []) {
		// The existing ID-only cost seam queries chat catalogs. Classifiers
		// use the operation-specific Models seam, so same-name models cannot
		// replace a chat price when a new operation joins the oracle.
		const m = known.find((m) => m.type === "chat" && m.id === id);
		models[id] = m ? m.cost : null;
	}
	return { results, models };
}

// models reports pi's model entry for each requested provider, api and id
// (null when pi does not list it), with the api as the oracle routes it, so
// the built-in catalog can be checked field by field against pi's data.
async function models(input) {
	const results = [];
	for (const key of input.models) {
		const entry = APIS[key.api];
		const known = entry ? await catalogModels(key.api, entry) : [];
		results.push(known.find((m) => m.provider === key.provider && m.id === key.id) ?? null);
	}
	return results;
}

async function main() {
	refuseLeakyEnv();
	installLoopbackGuard();
	verifiedPackageInfo();
	const input = await readStdin();
	if (input.entry === "models") {
		const results = await models(input);
		process.stdout.write(JSON.stringify({ pi: packageInfo(), node: process.version, results }));
		return;
	}
	if (input.entry === "costs") {
		const out = await costs(input);
		process.stdout.write(JSON.stringify({ pi: packageInfo(), node: process.version, ...out }));
		return;
	}
	if (input.entry === "thinkingBudgets") {
		const results = await thinkingBudgets(input.cases);
		process.stdout.write(JSON.stringify({ pi: packageInfo(), node: process.version, results }));
		return;
	}
	const entry = APIS[input.api];
	if (!entry) fail(`unsupported api ${JSON.stringify(input.api)}`);
	if (!input.baseUrl) fail("baseUrl must name a controlled loopback endpoint");
	controlledEndpoint = new URL(input.baseUrl);
	if (!isLoopbackHost(controlledEndpoint.hostname) || !controlledEndpoint.port || controlledEndpoint.protocol !== "http:" || controlledEndpoint.username || controlledEndpoint.password) fail("baseUrl must name a controlled loopback HTTP endpoint");
	if (!input.apiKey) fail("apiKey is required; the runner never falls back to the environment");

	const pi = await import("@earendil-works/pi-ai");
	const api = await import(entry.api);
	const known = (await catalogModels(input.api, entry)).find((m) => m.provider === input.provider && m.id === input.model);
	if (!known) fail(`model ${input.provider}/${input.model} is not in pi's ${input.api} catalog`);
	// modelCompat overrides compat flags of the catalog model, the way a pi
	// user configures a custom model; it lets a case exercise a flag that
	// pi's catalog only sets on models barness-ai does not list yet.
	// modelPatch replaces other top-level model fields (thinkingLevelMap,
	// samplingParams, contextWindow, ...) the same way.
	const compat = input.modelCompat ? { ...known.compat, ...input.modelCompat } : known.compat;
	// A patched compat replaces the catalog's whole, as for every other field.
	const model = { ...known, ...(compat ? { compat } : {}), ...(input.modelPatch ?? {}), baseUrl: input.baseUrl };

	const context = input.entry === "classify" ? input.context : pi.normalizeContext(input.context);
	// abortAfterEvents > 0 aborts the call, as a caller canceling it would, once
	// that many events were received.
	const controller = new AbortController();
	const options = { ...(input.options ?? {}), apiKey: input.apiKey, env: {}, signal: controller.signal };
	if (input.entry === "classify") {
		if (model.type !== "classifier" || typeof api.classify !== "function") fail("classify requires a classifier model and API");
		if (!Number.isInteger(options.maxRetries) || options.maxRetries < 0) fail("classify requires an explicit nonnegative maxRetries");
		const events = [];
		if (input.traceHooks) {
			options.onPayload = () => { events.push({ type: "callback", name: "payload" }); return input.payload; };
			options.onResponse = () => { events.push({ type: "callback", name: "response" }); };
		}
		const result = await api.classify(model, context, options);
		process.stdout.write(JSON.stringify({ pi: packageInfo(), node: process.version, events, result }));
		return;
	}
	if (input.entry !== "stream" && input.entry !== "streamSimple") fail(`unsupported entry ${input.entry}`);
	const run = input.entry === "streamSimple" ? api.streamSimple : api.stream;

	const events = [];
	const stream = run(model, context, options);
	for await (const event of stream) {
		events.push(JSON.parse(JSON.stringify(event)));
		if (events.length === input.abortAfterEvents) controller.abort();
	}
	const result = JSON.parse(JSON.stringify(await stream.result()));

	process.stdout.write(JSON.stringify({ pi: packageInfo(), node: process.version, events, result }));
}

main().catch((error) => fail(error?.stack ?? String(error)));
