// Package live is barness-ai's real official API smoke (spec Testing
// Decisions §2, §5): the same public Client a host uses, connected to a
// vendor's real API with a low-privilege test account, run before a release
// and after an SDK or model upgrade. Its results feed the support matrix
// (support-matrix.json in this directory). The Decisions candidate is separate
// pre-inclusion evidence and never emits a formal matrix report.
//
// Its tests are behind two switches, so `go test ./...` never reaches the
// network: the build tag live and BARNESS_AI_LIVE=1. One process runs one
// Operation × Provider × API combination and holds only that combination's key:
//
//	BARNESS_AI_LIVE=1 \
//	BARNESS_AI_LIVE_COMBO=deepseek-chat \
//	BARNESS_AI_LIVE_ACCOUNT_ALIAS=ci-deepseek-lowpriv@cn \
//	BARNESS_AI_LIVE_KEY_DEEPSEEK_CHAT=<injected by the CI secret store> \
//	go test -tags live -count=1 ./ai/live
//
// Formal Decisions: openai-decisions uses BuiltinCatalog and TestFormalDecisions,
// emits schema-3 live-report.json plus decisions-execution-report.json and
// decisions-integrity.json. Its nine capabilities require its own official live
// at the current catalog Hash. Candidate: openai-decisions-candidate uses its own fixed host catalog and
// candidate-decisions-report.json. TestCandidateDecisions requires verified
// account/region aliases and a Decisions-only host permissions record by default.
// Explicit BARNESS_AI_LIVE_ALLOW_UNKNOWN_ACCOUNT=1 allows missing verification
// and records account/region/permissions as unknown, as authorized on 2026-10-13.
// It never fabricates a verification record or ignores a malformed supplied one.
// The optional host verification file
// (BARNESS_AI_LIVE_PERMISSIONS_FILE), and explicit loopback HTTP transport proxy
// (BARNESS_AI_LIVE_PROXY). Official endpoint is fixed; Binding has no retries.
// Limits: 12 calls/12 attempt reservations/24 questions/4 MiB total state,
// 8 images/4 MiB total decoded images, 180 s process/30 s call. Nine required
// scenarios are never UNSUPPORTED. Absent key is NOT_RUN; malformed config
// refuses before spend. Sources, replay, captures and actual current status:
// .scratch/barness-ai-openai-decisions/candidate-live-evidence/README.md.
//
// Combinations (BARNESS_AI_LIVE_COMBO, key variable suffix):
// openai-responses, openai-chat, anthropic-messages, google-gemini,
// deepseek-responses, deepseek-chat, typesafe-classifier, openai-images, google-interactions-image, openai-decisions; the key variable is
// BARNESS_AI_LIVE_KEY_ followed by the name in upper case with "-" as "_".
// TypeSafe uses fixed jev-1.13.0; at most 6 calls / 10 questions and 131072
// state bytes per call. Its public Client context probe reports the actual
// guard (observed 400 max_tokens_exceeded); 422 is explicitly unconfirmed.
// Local dotenv injection and current evidence are described in issue 08.
// OpenAI Images uses the fixed gpt-image-2.5-sunburst-2026-09-08 snapshot.
// Its first required check is an inline JSON edit; generation and mask run only
// after that check passes in this process. At most four logical calls / four
// requested images (including faults and retries), one per call, at 1024x1024.
// Binding retries are disabled. A mask-specific unsupported response is optional;
// JSON editing/generation must PASS. A sourced host probe catalog is used before
// inclusion and for future revalidation. PNG/JPEG/WebP rasters and checksums are
// saved independently of bounded wire captures; a truncated capture stays labelled.
// The explicit local dotenv launcher and verification are in issue 11's evidence.
// Google images pins gemini-nano-banana-2.1 on official v1beta/interactions.
// Required generation and one-reference edit use 1K/1:1, with the same four-call
// and four-image reservation budget. store=false; delivery is deliberately
// omitted after a real 400 and maintainer-approved ADR-0023. Only completed
// inline data is accepted. Capture is bounded to 16 MiB before eliding image
// data/signatures, preserving every output step and trailing usage. Reported
// identity may be absent; it is never fabricated from attribution. Own local
// injection and artifacts are in issue 14's google-images-live-evidence.
// Account privileges and region must be configured by the host: an alias records
// provenance and does not prove key permissions.
// Each combination's models are fixed in the suite (combos_test.go), chosen
// to have every capability the combination promises.
//
// The key is read from that one variable only. Nothing falls back to
// OPENAI_API_KEY or any other ambient credential, and a process that also
// sees another combination's key refuses to run: keys are injected per
// combination process, never shared. Without a key every scenario is
// NOT_RUN; a vendor fault is retried within the budget and then FAIL, never
// a skip. Every outcome is PASS, FAIL, NOT_RUN or UNSUPPORTED.
//
// Each run leaves an evidence bundle (.evidence/barness-ai/<run-id>, or
// BARNESS_AI_EVIDENCE_DIR) with redacted wire captures per scenario and
// live-report.json; the key never enters it. Merge reports into the matrix
// with:
//
//	go run ./ai/live/cmd/supportmatrix <bundle-dir>...
//
// A combination's row changes only through its own report: a pass through a
// shared adapter never marks another combination.
package live
