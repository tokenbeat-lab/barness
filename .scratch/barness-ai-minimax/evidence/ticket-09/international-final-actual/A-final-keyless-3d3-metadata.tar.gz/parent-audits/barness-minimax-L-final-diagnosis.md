# L final15: read-only outcome and failure-boundary audit

Parent notified **FINAL15CLOSED**. All15 original L jobs are now closed at
source `3d3a1fb28e143a2c29d684f78edcad94c0217243`. This diagnosis read
current producer artifacts, source and canonical receipts only; no source,
HEAD, captures or root data were edited. No credentials/.env or ambient
proxy values were read; no tests, network calls, paid retries or process
interruptions were made. Temporary diagnostic documents are separate from
original evidence. Parent's independent keyless A is underway; **no final
release-gate result is claimed here**.

## Original outcomes and consumed resources

| Own L job | Outcome | Calls/HTTP attempts | Direct captured evidence |
| --- | --- | ---: | --- |
|openai-responses|FAIL|15/15|15s ConnectTimeout; no HTTP response|
|openai-chat|FAIL|17/17|15s ConnectTimeout; no HTTP response|
|anthropic-messages|FAIL|11/11|HTTP403; error.type=forbidden|
|google-gemini|FAIL|11/11|15s ConnectTimeout; no HTTP response|
|deepseek-responses|PASS|10/10|Own scenarios PASS; HTTP200|
|deepseek-chat|PASS|13/13|Own scenarios PASS; includes expected HTTP400 control|
|openai-images|FAIL|2/2|15s ConnectTimeout; required edit fails, other scenes NOT_RUN|
|google-interactions-image|FAIL|4/4|15s ConnectTimeout; no HTTP response|
|openai-decisions|FAIL|9/9|10s ConnectTimeout; no HTTP response|
|typesafe-classifier|FAIL|3/3|HTTP451; explicit regional refusal|
|protocol114|FAIL|1/1|HTTP451; first attempted call, partial formal inventory|
|text-jev|FAIL|24/24|24 HTTP451 regional refusals|
|text-luna|FAIL|24/24|24 request deadlines, no HTTP response, ~5s each|
|visual-jev|FAIL|12/12|12 HTTP451 regional refusals|
|visual-decisions|FAIL|12/12|12 request deadlines, no HTTP response, ~5s each|

All15 canonical receipts and commands are COMPLETED, same exact frozen source.
Each own report exists and its SHA256 matches the original canonical pin;
command and receipt exits agree; every launcher audit passes and each bundle
audit has zero findings. These integrity checks do not waive any FAIL.
Full metadata/pins: [final audit JSON](/tmp/barness-minimax-L-final-audit.json).

Measured totals: **168 logical calls /168 HTTP attempts;2 jobs PASS and13 jobs
FAIL**. All168 Attempts are accounted for:20 usageReporting=complete,148
unreported, no partial reporting. The20 complete Attempts belong to the two
DeepSeek routes; their deliberate cancellations and expected HTTP400 refusal
remain unreported. Default zero totals on failures are **unknown reported
usage**, not proof of zero provider work, billing or charged cost.

Current canonical renewal accounting reads300/300 legacy (132/132 prior GLM
original+corrective consumption plus168/168 L), ceiling440/464; prior unrelated
GLM task history remains separate, not erased. MiniMax canonical stage counters
remain candidate49/45, formal39/36. The independent consumption.json hash and
source-pinned own receipt/report hashes are retained in the final JSON.

## What the failures actually establish

**OpenAI and Google text/image/Decisions connection failures.** The58 generic
Attempts on OpenAI Responses/Chat/Images/Decisions and Google Gemini/Interactions
Image have an exact resource ConnectTimeout:15s except Decisions10s. No HTTP
status, response headers or response body exists. The watchdog ends only on
net/http/httptrace GotConn (`ai/timeouts.go:68–103`); the configured standard
transport supports that notification. Terminal code=deadline_exceeded,
phase=request. This is preconnection-establishment evidence, before response
decoding/SSE, not proof of a parser or model/business failure. DNS/TCP/TLS/path
cause and credential validity cannot be separated from this capture.

The other36 no-response Attempts are Luna text24 and Decisions visual12.
Their captures mark status0/network failure or empty response; terminal code
is deadline_exceeded, phase=request. Luna samples last5,000.828–5,002.796ms;
visual samples5,001.835–5,004.771ms. Both Host policies use a5s connection bound
(and a5s TLS handshake transport limit); their evidence retains only public
code/phase, not an underlying failure message. Therefore the precise watcher
vs TLS cause is not independently identifiable; it is a roughly5s pre-response
failure consistent with the connection policy, not an observed HTTP rejection
or model answer. Do not invent a finer network cause.

Cancellation cases on these failed text/classifier routes retain their actual
assertion failures: no provider content arrived, and the terminal deadline
event did not become the expected canceled/aborted result. They do not prove
a regression in cancellation after received provider content. Original bounded
per-scene retries remain exactly those recorded; failed assertions did not gain
extra retries.

**Anthropic access refusal, not a proven invalid key.** All11 Attempts received
actual HTTP403 in220–1191ms, JSON error.type=forbidden. No401, invalid-key or
authentication_error type was observed. Core `codeForStatus` maps both401 and
403 to upstream_auth (`ai/errors.go:147–150`); the normalized name does not
establish which account/edge/location/permission cause applies. It establishes
upstream access refusal. No model response or provider usage was returned.

**TypeSafe explicit regional availability refusal.** All40 TypeSafe Attempts
(classifier3, protocol1, text24, visual12) have actual HTTP451 with
`{title,status}` and safe exact title: **Typesafe is not available in your
region.** The status field is451. This is an upstream regional refusal, not
local payload validation, a reported authentication failure, or model-not-found
evidence. Generic4xx normalization maps451 to invalid_request. The
context-422 negative control properly FAILs because it received451, not422.
The same explicit refusal affects jev-1.13.0 classifier/text and jev-1.14.0
protocol/visual, so it does not prove version-specific model unavailability.
No model, endpoint, region, proxy or key workaround was attempted.

**DeepSeek actual successful and negative controls.** Both independent routes
PASS. Responses has10 HTTP200 Attempts; Chat has12 HTTP200 and one expected
HTTP400 invalid_request refusal for thinking+forced-tool choice, accepted by
the existing explicit ADR0015 control (`ai/live/extras_test.go:89–113`). Do not
relabel that intended refusal as a model failure. The successful routes also
show that a universal outbound-network outage is not established. None of
the13 failed jobs supplied a successful model/business answer that an adapter
then lost; their captured failures are connection, access or regional boundary
observations. They do not establish future service outcomes.

## Partial Jev protocol and actual final gate

The1.14 protocol first attempted call failed451; budget1/1, complete=false,
outcome=FAIL, scenarios=null. Its first real failed assertion/result/exchange
remain in the manifest and budget; it must not be rewritten into12 completed
scenarios. All12 independent Jev visual attempts also failed451.

Public jevformal checks complete original protocol/effects **before** creating
its output (`ai/live/cmd/jevformal/main.go:42–47`). Therefore real support
derivation must refuse these partial/failed inputs and may leave L/support
absent. No counterfeit17th projection, stale substitute or edited report is
permitted to make the temporary matrix valid. The original actual support
matrix must remain unchanged on failed temporary import.

All15 own producer reports now exist, including genuine FAILs, so the parent
finalizer's initial own-report resolver can inspect their provenance. Its
planned Jev support path is deliberately not required to exist until real
derivation. Subsequent derive/verify/temporary-import failures must be recorded,
and must not skip the actual releasegate. The public releasegate runs both
vets and full ordinary/race suites before supplied-live/effect auditing; it
can then record actual missing/failed Jev support and other required inputs.
This diagnosis does not claim either suite or final gate has completed.

## Fixed-contract disposition

Preserve all original receipts, authentic FAIL/NOT_RUN scene records, known
consumption and unreported usage. No automatic R2, process rerun, scene splice,
source/catalog/price/capture rehash, retry grant or weaker importer follows from
unused numeric headroom. Source remains frozen for current evidence. Future
paid remediation would require a distinct concrete reviewed plan and explicit
authorization; none is proposed or performed as an existing entitlement.

Detailed earlier observations remain separately available:
[OpenAI first failure](/tmp/barness-minimax-L-openai-failure.md),
[provisional evolving generic note](/tmp/barness-minimax-L-generic-diagnosis.md),
and its eight-route snapshots. The final audit JSON supersedes provisional
scope only; original producer bytes and prior diagnostic claims are not edited.
