#!/usr/bin/env python3
"""Parent-inspected, one-shot keyless finalization; default mode only plans.

Failure inventory: wrong source/HEAD/binary, active or foreign paid receipts,
missing/ambiguous/symlink reports, changed producer pins, duplicate identity,
wrong catalog/source, pre-existing output/support, and concurrent matrix change
must refuse before mutation. Independent verifier failures are recorded and do
not skip the actual gate. Invalid temporary import never updates the matrix.
Authentic FAIL remains FAIL. No credentials, paid child, report edit, retry,
GLM selector renewal, supplied offline bundle, or source edit is available.

Inspect this file, then invoke `python3 /tmp/barness-minimax-final-keyless.py run`
only after all 15 L paid jobs finish. `plan` (the default) performs no writes or
subprocess business execution. Both modes require complete original inputs.
"""
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import signal
import stat
import sys
import tempfile

sys.dont_write_bytecode = True
ROOT = Path('/Users/cyber/RestoX/barness')
TOOLS = ROOT / '.scratch/barness-ai-minimax/tools'
sys.path.insert(0, str(TOOLS))
import paid_core as c
import paid_plan as p

FROZEN = '3d3a1fb28e143a2c29d684f78edcad94c0217243'
L = ROOT / '.evidence/minimax-global-legacy-final'
M = ROOT / '.evidence/minimax-global-formal-glm'
Q = ROOT / '.evidence/minimax-global-glm-corrective-1-reviewed'
A = ROOT / '.evidence/minimax-global-final-keyless'
MATRIX = ROOT / 'ai/live/support-matrix.json'
ROUTES = ('chat', 'responses', 'messages')
NAMES = tuple(row[0] for row in p.GENERIC) + (
    'protocol114', 'text-jev', 'text-luna', 'visual-jev', 'visual-decisions')
REPORT_LIMIT = 16 << 20


def regular(path, limit=REPORT_LIMIT):
    """Check each parent without resolving away a symlink before bounded read."""
    path = Path(path)
    if not path.is_absolute() or not path.is_relative_to(ROOT):
        raise RuntimeError('artifact must remain in this exact repository')
    for item in (path, *path.parents):
        info = item.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise RuntimeError('symlink in artifact path')
        if item == ROOT:
            break
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
        raise RuntimeError('regular bounded artifact required')
    with path.open('rb') as stream:
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise RuntimeError('artifact exceeds byte bound')
    return raw


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def document(path):
    def pairs(items):
        value = {}
        for key, child in items:
            if key in value:
                raise RuntimeError('duplicate JSON artifact field')
            value[key] = child
        return value
    value = json.loads(regular(path), object_pairs_hook=pairs)
    if not isinstance(value, dict):
        raise RuntimeError('JSON object artifact required')
    return value


def directory(path):
    path = Path(path)
    for item in (path, *path.parents):
        info = item.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise RuntimeError('symlink directory forbidden')
        if item == ROOT:
            break
    if not path.is_dir() or not path.is_relative_to(ROOT):
        raise RuntimeError('owned repository directory required')
    return path


def unique(base, leaf):
    directory(base)
    found = []
    with os.scandir(base) as entries:
        for index, entry in enumerate(entries):
            if index >= 1024:
                raise RuntimeError('direct bundle inventory exceeds 1024')
            if entry.is_symlink():
                raise RuntimeError('symlink child forbidden')
            if entry.is_dir(follow_symlinks=False):
                path = Path(entry.path) / leaf
                if path.exists() or path.is_symlink():
                    regular(path)
                    found.append(path.parent)
                    if len(found) > 1:
                        raise RuntimeError('ambiguous own session bundle')
    if len(found) != 1:
        raise RuntimeError('unique own session bundle absent')
    return found[0]


def mark(name):
    return c.common_root() / '.evidence/minimax-launches' / (name + '.json')


def remember(pins, path):
    pins[Path(path).relative_to(ROOT).as_posix()] = sha(regular(path))


def frozen():
    if c.ROOT != ROOT or c.git('rev-parse', 'HEAD') != FROZEN:
        raise RuntimeError('exact final L source HEAD required')
    state = c.guard(L)
    if state['sourceCommit'] != FROZEN:
        raise RuntimeError('L frozen source differs')
    return state


def resolve():
    state = frozen()
    pins, paid_rows = {}, []
    snapshot = document(ROOT / 'ai/release/catalog-snapshot.json')
    catalog = (snapshot['catalog']['version'], snapshot['hash'])
    jobs = p.jobs(ROOT, L, c.common_root())
    for name in NAMES:
        receipt_path = mark(name)
        receipt = document(receipt_path)
        command_path = L / (name + '-command.json')
        command = document(command_path)
        report_path = p.report_path(L, jobs[name])
        budget = receipt.get('budget', {})
        if (receipt.get('route') != name or receipt.get('state') != 'COMPLETED'
                or command.get('state') != 'COMPLETED'
                or receipt.get('sourceCommit') != FROZEN
                or receipt.get('collectionRoot') != c.redact(str(L))
                or receipt.get('exitCode') != command.get('exitCode')
                or receipt.get('credentialsRead') is not True
                or receipt.get('launcherAudit', {}).get('passed') is not True
                or budget.get('state') not in ('REPORTED', 'NOT_RUN')
                or receipt.get('reportedFileSha256') != sha(regular(report_path))):
            raise RuntimeError('one final own completed L paid receipt required: ' + name)
        for path in (receipt_path, command_path, report_path):
            remember(pins, path)
        paid_rows.append(dict(name=name, exitCode=receipt.get('exitCode'), budget=budget))
    own = {name: unique(L / 'live' / name, 'live-report.json') for name, *_ in p.GENERIC}
    for route in ROUTES:
        own['zhipu-' + route] = unique(Q / ('glm-corrective-1-' + route), 'live-report.json')
        own['minimax-' + route] = unique(M / ('mm-global-formal-m3-' + route), 'live-report.json')
    own['typesafe-classifier-jev-1.14.0'] = L / 'support'
    if len(own) != 17 or set(own) != set(p.LIVE_IDENTITIES) or len(set(own.values())) != 17:
        raise RuntimeError('exact distinct 17 own input roles required')
    for combo, bundle in own.items():
        if combo == 'typesafe-classifier-jev-1.14.0':
            continue  # Generated exclusively by the public Jev command later.
        value = document(bundle / 'live-report.json')
        if (value.get('combo') != combo or value.get('schema') != 3
                or (value.get('catalogVersion'), value.get('catalogHash')) != catalog):
            raise RuntimeError('own report identity/catalog mismatch: ' + combo)
        if combo in {name for name, *_ in p.GENERIC} and value.get('gitCommit') != FROZEN:
            raise RuntimeError('generic own L source mismatch')
        remember(pins, bundle / 'live-report.json')
        if combo.startswith('zhipu-'):
            route = combo.removeprefix('zhipu-')
            receipt_path = mark('glm-corrective-1-' + route)
            receipt = document(receipt_path)
            detail = bundle / 'formal-glm-report.json'
            if (receipt.get('state') != 'COMPLETED'
                    or receipt.get('correctiveRound') != 'corrective-1'
                    or receipt.get('sourceCommit') != value.get('gitCommit')
                    or receipt.get('reportedFileSha256') != sha(regular(detail))
                    or receipt.get('launcherAudit', {}).get('passed') is not True):
                raise RuntimeError('Q own original receipt/detail mismatch')
            remember(pins, receipt_path)
            remember(pins, detail)
        if combo.startswith('minimax-'):
            detail = bundle / 'minimax-report.json'
            remember(pins, detail)
    protocol = unique(L / 'protocol114', 'multimodal-report.json')
    text = {route: unique(L / ('text-' + route), 'manifest.json') for route in ('jev', 'luna')}
    visual = {route: directory(L / ('visual-' + route)) for route in ('jev', 'decisions')}
    for path in [protocol / 'multimodal-report.json', *(v / 'manifest.json' for v in text.values()),
                 *(v / 'report.json' for v in visual.values())]:
        remember(pins, path)
    return dict(sourceCommit=state['sourceCommit'], catalogVersion=catalog[0], catalogHash=catalog[1],
                inputs=[dict(identity=name, path=str(own[name])) for name in p.LIVE_IDENTITIES],
                protocol=str(protocol), text={k: str(v) for k, v in text.items()},
                visual={k: str(v) for k, v in visual.items()}, paid=paid_rows, originalPins=pins)


def commands(plan):
    paths = [row['path'] for row in plan['inputs']]
    checks = []
    for route in ('jev', 'luna'):
        checks.append(('verify-text-' + route, [L / 'chineseeval', '-route', route, '-verify', plan['text'][route]], 240))
    for route in ('jev', 'decisions'):
        checks.append(('verify-visual-' + route, [L / 'visualeval', '-verify', plan['visual'][route], '-require-live'], 240))
    derive = ['go', 'run', './ai/live/cmd/jevformal', '-protocol', plan['protocol'],
              '-effects', plan['visual']['jev'], '-out', L / 'support', '-require-live']
    checks.append(('verify-jev-support', ['go', 'run', './ai/live/cmd/jevformal',
                                         '-verify', L / 'support', '-require-live'], 240))
    for route in ROUTES:
        combo = 'minimax-' + route
        bundle = next(row['path'] for row in plan['inputs'] if row['identity'] == combo)
        checks.append(('verify-minimax-' + route, ['go', 'run', './ai/live/cmd/minimaxverify', '-formal', bundle], 240))
    merge = ['go', 'run', './ai/live/cmd/supportmatrix', *paths]
    gate = ['go', 'run', './ai/release/cmd/releasegate', '-out', A / 'gate',
            '-evaluation-jev', plan['text']['jev'], '-evaluation-luna', plan['text']['luna'],
            '-visual-evaluation-jev', plan['visual']['jev'], '-visual-evaluation-decisions', plan['visual']['decisions']]
    for path in paths:
        gate.extend(('-live', path))
    return dict(derive=derive, verify=checks, merge=merge, gate=gate, gateOuterTimeoutSeconds=6600)


def retain(path, value):
    c.dump(path, c.redact(value))


def guard_originals(plan):
    frozen()
    for name, expected in plan['originalPins'].items():
        if sha(regular(ROOT / name)) != expected:
            raise RuntimeError('original receipt/report changed during keyless finalization')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('plan', 'run'), nargs='?', default='plan')
    args = parser.parse_args()
    plan = resolve()
    argv = commands(plan)
    if A.exists() or A.is_symlink():
        raise RuntimeError('final keyless output already exists; no automatic retry')
    if (L / 'support').exists() or (L / 'support').is_symlink():
        raise RuntimeError('Jev support destination already exists; never overwrite')
    manifest = dict(schema=1, kind='keyless-final-mixed-own-inputs', credentialsRead=False,
                    paidCalls=0, automaticReruns=False, cwd=str(ROOT), plan=plan, argv=argv,
                    runnerSHA256=sha(Path(__file__).read_bytes()))
    if args.mode == 'plan':
        print(json.dumps(c.redact(manifest), ensure_ascii=False, indent=2, default=str))
        return 0
    A.mkdir(mode=0o700)
    retain(A / 'argv-manifest.json', json.loads(json.dumps(manifest, default=str)))
    statuses = []
    def perform(name, command, timeout):
        guard_originals(plan)
        code = c.execute(A, name, command, env={'PYTHONDONTWRITEBYTECODE': '1'}, timeout=timeout,
                         cwd=ROOT, source=None, injected=None)
        receipt = document(A / (name + '-command.json'))
        statuses.append(dict(name=name, state=receipt.get('state'), exitCode=code, credentialsRead=False))
        retain(A / 'progress.json', dict(steps=statuses, automaticReruns=False, credentialsRead=False))
        print(json.dumps(dict(step=name, exitCode=code, credentialsRead=False)), flush=True)
        if receipt.get('state') == 'INTERRUPTED':
            raise RuntimeError('explicit interruption retained; no further steps executed')
        guard_originals(plan)
        return code
    # Each public verifier gets an independent command receipt and real exit.
    perform('derive-jev-support', argv['derive'], 240)
    for name, command, timeout in argv['verify']:
        perform(name, command, timeout)
    before = regular(MATRIX)
    (A / 'matrix-before.json').write_bytes(before)
    before_hash = sha(before)
    temporary_code = None
    with tempfile.TemporaryDirectory(prefix='matrix-validation-', dir=A) as temporary:
        target = Path(temporary) / 'matrix.json'
        target.write_bytes(before)
        command = ['go', 'run', './ai/live/cmd/supportmatrix', '-matrix', target,
                   *[row['path'] for row in plan['inputs']]]
        retain(A / 'temporary-validation-argv.json', dict(argv=list(map(str, command)),
               credentialsRead=False, sourceVariable=None))
        temporary_code = perform('validate-17-temporary-matrix', command, 600)
        (A / 'matrix-validation-after.json').write_bytes(regular(target))
    default_code = None
    if temporary_code == 0:
        if sha(regular(MATRIX)) != before_hash:
            raise RuntimeError('default matrix changed after temporary validation')
        default_code = perform('merge-17-default-matrix', argv['merge'], 600)
    else:
        statuses.append(dict(name='merge-17-default-matrix', outcome='NOT_RUN',
                             reason='temporary import rejected; original matrix retained', credentialsRead=False))
        if sha(regular(MATRIX)) != before_hash:
            raise RuntimeError('default matrix changed despite rejected temporary validation')
    (A / 'matrix-after.json').write_bytes(regular(MATRIX))
    # Never gate this call on expected vendor/verification/import failures.
    gate_code = perform('actual-releasegate', argv['gate'], 6600)
    report_path = A / 'gate/release-report.json'
    gate_report = None
    report_error = None
    try:
        gate_report = document(report_path)
    except (OSError, RuntimeError, ValueError) as error:
        report_error = type(error).__name__
    success = (all(row.get('exitCode') == 0 for row in statuses)
               and default_code == 0 and gate_code == 0
               and gate_report is not None and gate_report.get('pass') is True)
    summary = dict(schema=1, completedAt=dt.datetime.now(dt.timezone.utc).isoformat(),
                   credentialsRead=False, paidCalls=0, automaticReruns=False, steps=statuses,
                   temporaryImportExitCode=temporary_code, defaultMergeExitCode=default_code,
                   matrixBeforeSHA256=before_hash, matrixAfterSHA256=sha(regular(MATRIX)),
                   gateExitCode=gate_code, releaseReportPresent=gate_report is not None,
                   releaseReportSHA256=sha(regular(report_path)) if gate_report is not None else None,
                   releaseReportReadError=report_error, releasePass=gate_report.get('pass') if gate_report else None,
                   passVerdict=success, fullAcceptanceClaimed=False,
                   note='Authentic Q Responses FAIL and stale historical GLM selectors remain visible; no renewal or waiver.')
    retain(A / 'summary.json', summary)
    print(json.dumps(c.redact(summary), ensure_ascii=False, indent=2))
    return 0 if success else 1


if __name__ == '__main__':
    def interrupted(_number, _frame):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, interrupted)
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print('INTERRUPTED: no automatic continuation or retry', file=sys.stderr)
        sys.exit(130)
    except (OSError, RuntimeError, ValueError, KeyError, TypeError) as error:
        print('REFUSED: ' + str(c.redact(str(error))), file=sys.stderr)
        sys.exit(2)
