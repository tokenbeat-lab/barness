# A retention failure inventory, before implementation

This draft was prepared while the A public release gate was running. No A raw
capture, assertion, race audit, outer command closure or final verdict was collected.
Only immutable public Git3d3 code, producer-script code, published argv/path metadata
and the published ordinary/race manifest case metadata were read.

- In-flight audit/log/report data may change. The collector requires a separate
  parent A-CLOSED notification and explicit --a-closed argument before any collection.
- The source can be relabelled after the reviewed P2 fix merges. Every A claim stays
  at original3d3; full1034 source bytes already reside in the immutable paid L capsule.
  This package pins that external proof and includes exact public-gate code bytes.
- A real command failure is not an absent test. Preserve both suites' actual six
  failed GLM import/known-usage assertions, 12,385 PASS cases and every raw artifact.
- A mixed input may be absent. Preserve all17 planned roles and original argv; the
  missing L/support reference remains missing and authentic derivation/import FAILs
  remain FAIL. Do not require, invent, merge or mint the missing support report.
- The real gate can be substituted with supplied -bundle/-race-bundle outputs.
  Reject those flags; retain original gate command receipt, release-report commands,
  both vets, normal/race command outcomes and PIDiff/Pressure switches.
- A command tail or exit alone may omit evidence. Keep full original A command logs,
  gate top-level files, complete ordinary and race raw trees, and full SHA inventories.
- A source/run audit can expose a selected key. Require each closed suite audit to
  have zero findings before reading its raw tree. No environment or .env is read.
- More than200k total files may exceed a single discovery budget. Split ordinary and
  race into separate bounded archives; each has independent400k entries/4GiB expanded,
  depth24 and128MiB regular-file limits. Do not scan A as one giant root.
- Negative fixture symlinks are intentional. Hash only original target text, without
  following or extracting it. Reject special files, unsafe paths and mutable files.
- Deliberately corrupt inner fixture manifests are not producer authority. Validate
  outer main manifest artifact references; preserve inner negative bytes unchanged.
- Existing L/M/Q/C archives may be duplicated or treated as new certification.
  Keep hash/size/original-member boundaries; full paid captures and source proofs stay
  external. Their original outcomes/source commits and GLM noR2 accounting remain.
- Original matrix or selectors may be modified after failed temporary import. Retain
  matrix-before/after/temporary bytes and command exits; do not alter actual matrix.
- Byte integrity can be mistaken for release success. Report integrity separately;
  original gate passfalse/exit1 remains an actual failure, never a curator approval.
- Current P2 fixes or later reruns may be spliced into A. Capture only original3d3
  closed A; reviewed later source is separate and does not repair its old verdict.
- The curator could mutate source/HEAD or rerun captured commands. Outputs are /tmp
  only. No root edits, Git mutation, test/public-gate execution, network or vendor call.


The parent subsequently declared A CLOSED. Original metadata confirmed there is no
release-report.json: outerexit1, child CLI exit-status2 at LoadBundle, releasePass
null and summary passVerdictfalse. The concrete profile preserves this failed-load
window and exact original log/summary/outer receipt hashes. No report.commands is
available; derived banner offsets retain four original command lines only, with
individual numeric exits explicitly unknown/unpersisted. Recorded suite audits0
are distinct from later public gate audits/Evaluate/report-writing not reached by
the original source control flow. These original absence/failure facts must never
be repaired by the later source fix or rerun. This archive is not release approval.
