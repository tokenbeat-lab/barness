# Original A failed-load evidence retention

Parent explicitly declared original A CLOSED at source3d3. The original public gate
executed both suite bodies and produced their recorded audits0, then failed loading
the ordinary bundle before release evaluation/report creation. Outer go-run exit1,
child CLI text `exit status 2`, releaseReportPresentfalse/releasePassnull and parent
summary passVerdictfalse remain unchanged. There is no release-report.json and no
persisted internal per-command exit/result list. No replacement report or command
receipt is generated. Exact original log banners/offsets are a derived index only.

`curate_a.py` retains original source3d3 bytes/references; `verify_a.py` with a_core.py
and retention_core.py verifies the archives. Complete ordinary and race raw trees
are separate bounded archives with full SHA inventories. The small metadata proof
pins the immutable paid L capsule's full1034 committed source bytes and retains
exact public-gate/loader code, original A metadata/logs,17 planned own-input roles,
one honest missing L/support,4 effect references and12 exact failed assertions.
Original GLM failures, later P2 source and any future reruns stay separate.

Each suite has separate400k entry/4GiB expanded, depth24 and128MiB regular-file
limits. Symlink fixture target text is hashed without following/extracting it.
Outer producer artifact refs are checked; inner intentionally corrupt fixture
claims are preserved as data. Full raw manifests stay inside raw archives; small
metadata contains labelled derived summaries, avoiding unnecessary duplication.
Existing L/M/Q/C source/capture archives remain immutable external boundaries.

All writes are under /tmp. The parent can inspect/copy original raw archives to
ignored common retention and commit the small metadata, indexes and portable tools.
Neither curator nor verifier executes captured commands, tests, environment reads,
network or paid calls. Byte integrity never certifies support or release.

The earlier prospective `A.closed-template.json` still has parentClosureConfirmed
false. The concrete `A.closed-config.json` records this explicit closure and exact
original summary/log/outer receipt hashes. The collector requires --a-closed.
