import collections, gzip, hashlib, io, json, os, pathlib, stat, subprocess, tarfile
work=pathlib.Path.cwd()
common=pathlib.Path(subprocess.check_output(['git','rev-parse','--git-common-dir'],text=True).strip()).resolve().parent
out=work/'.scratch/barness-ai-minimax/evidence/ticket-09/release-consumer'
source=work/'.evidence/release-consumer'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,limit=64<<20):
 with p.open('rb') as f:b=f.read(limit+1)
 if len(b)>limit:raise ValueError('owned artifact exceeds preregistered cap')
 return b
members={};runs=[]
def add(name,p=None,data=None):
 if name in members or not pathlib.PurePosixPath(name).is_relative_to('.') or '..' in pathlib.PurePosixPath(name).parts:raise ValueError('duplicate or unsafe owned member')
 if p is not None:
  st=p.lstat()
  if not stat.S_ISREG(st.st_mode):raise ValueError('nonregular owned artifact')
  data=read(p)
 members[name]=data
 if len(members)>20000 or sum(map(len,members.values()))>256<<20:raise ValueError('owned retention exceeds finite cap')
def tree(prefix,base):
 entries=0
 for folder,dirs,files in os.walk(base,followlinks=False):
  dirs.sort();files.sort()
  for n in dirs+files:
   p=pathlib.Path(folder)/n;entries+=1
   if entries>20000 or len(p.relative_to(base).parts)>24 or p.is_symlink():raise ValueError('owned tree unsafe or oversized')
  for n in files:
   p=pathlib.Path(folder)/n;add(prefix+'/'+p.relative_to(base).as_posix(),p)
def bundle(prefix,base):
 tree(prefix,base)
 m=json.loads(read(base/'manifest.json'));a=json.loads(read(base/'audit.json'))
 checks=0
 for c in m['cases']:
  for n,h in c['artifacts'].items():
   p=base/c['dir']/n
   if sha(read(p))!=h:raise ValueError('original case artifact pin mismatch')
   checks+=1
 runs.append({'prefix':prefix,'sourceCommit':m['git_commit'],'manifestSHA256':sha(read(base/'manifest.json')),'cases':len(m['cases']),'statuses':dict(collections.Counter(c['status'] for c in m['cases'])),'recordedAuditFindings':len(a['findings']),'artifactRefsVerified':checks})
for d in sorted((work/'.evidence/barness-ai').iterdir()):
 if d.name>='20261018T055437' and (d/'manifest.json').is_file():bundle('intermediate/'+d.name,d)
for label,base in [('root-selection-red',common/'.evidence/minimax-retained/release-consumer-root-selection-red/release-consumer/root-selection-red'),('root-selection-green',source/'root-selection-green')]+[(n,source/('cases-'+n)) for n in ['fixed-ordinary','fixed-race','fixed-actual-read-only','catalog-red','catalog-red-actual','catalog-red-corrected','catalog-green','catalog-final-ordinary','catalog-final-race']]:
 for d in sorted(base.iterdir()):
  if (d/'manifest.json').is_file():bundle(label+'/'+d.name,d)
for p in sorted(source.iterdir()):
 if p.is_file() and p.suffix in {'.log','.json','.py','.txt'}:add('commands/'+p.name,p)
# Original tracked implementation and final complete changed consumer/test source
# are retained separately; no uncommitted RED working-tree snapshot is invented.
changed=subprocess.check_output(['git','diff','3d3a1fb','7754c7f','--name-only'],cwd=work,text=True).splitlines()
for commit in ['e3b90a3','c6801d0','09fea1b','7754c7f']:
 for n in changed:
  if not n.endswith('.go'):continue
  p=subprocess.run(['git','show',commit+':'+n],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if p.returncode==0:add('source/'+commit+'/'+n,data=p.stdout)
add('source/failure-inventory.md',work/'.scratch/barness-ai-minimax/evidence/ticket-12/release-consumer/failure-inventory.md')
# Optional adopted-input diagnostic is appended only after final review closure.
diagnostic=source/'diagnostic-releasegate'
if diagnostic.is_dir():tree('diagnostic-releasegate',diagnostic)
for commit in ['7754c7f','ad20469']:
 for n in subprocess.check_output(['git','diff','7754c7f','ad20469','--name-only'],cwd=work,text=True).splitlines():
  result=subprocess.run(['git','show',commit+':'+n],cwd=work,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
  if result.returncode==0:add('future-producer-source/'+commit+'/'+n,data=result.stdout)
add('context/source-proof.py',pathlib.Path('/tmp/barness-release-consumer-source-proof.py'))
add('context/curation.py',pathlib.Path(__file__))
archive=out/'release-consumer-ad20469.tar.gz'
class ArchiveWriter:
 def __init__(self,file):self.file=file;self.digest=hashlib.sha256();self.size=0
 def write(self,data):
  self.size+=len(data)
  if self.size>8<<20:raise ValueError('compact owned archive exceeds 8 MiB')
  self.digest.update(data);return self.file.write(data)
with archive.open('wb') as f:
 writer=ArchiveWriter(f)
 with gzip.GzipFile(filename='',fileobj=writer,mode='wb',mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w|') as tar:
   for name,data in sorted(members.items()):
    t=tarfile.TarInfo(name);t.size=len(data);t.mode=0o644;t.mtime=0
    tar.addfile(t,io.BytesIO(data))
 expected_archive=writer.digest.hexdigest()
# Authenticate bounded compressed bytes against the write-time digest BEFORE
# decoding. Only the immutable just-produced owned stream is parsed below.
compressed=read(archive,8<<20)
if sha(compressed)!=expected_archive:raise ValueError('archive changed after writing')
index={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())}
raw=json.dumps(index,sort_keys=True,separators=(',',':')).encode()+b'\n'
(out/'members.json.gz').write_bytes(gzip.compress(raw,mtime=0))
# Positive byte-for-byte archive roundtrip; the archive is just produced here,
# not an untrusted import. Bound actual expanded reads before comparisons.
seen=set();total=0
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tar:
 for t in tar:
  if not t.isfile() or t.name not in index or t.name in seen or t.size>64<<20:raise ValueError('invalid archive member')
  seen.add(t.name);r=tar.extractfile(t);data=r.read((64<<20)+1);total+=len(data)
  if len(data)>64<<20 or total>256<<20 or {'bytes':len(data),'sha256':sha(data)}!=index[t.name]:raise ValueError('roundtrip mismatch')
if seen!=set(index):raise ValueError('archive member omission')
summary={'schema':1,'kind':'release-consumer-targeted-red-green-and-adopted-input-diagnostic','testedSource':'7754c7fe9c71c1203a0c9f860da35dbf5973c3d9','futureProducerSource':'ad20469d0a0d854ebda35c15b9c4ed49beebfda5','diagnostic':{'source':'7754c7fe9c71c1203a0c9f860da35dbf5973c3d9','pass':False,'commands':None,'outerExit':1,'adoptedHistoricalInputs':True,'originalCommandNumericExits':'UNKNOWN','secondGateRun':False},'originalActualSource':'3d3a1fb28e143a2c29d684f78edcad94c0217243','archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(read(archive)),'members':len(index),'expandedBytes':total},'memberIndex':{'file':'members.json.gz','sha256':sha(read(out/'members.json.gz')),'expandedBytes':len(raw)},'runs':runs,'archiveRoundtrip':'PASS: every member exact; all recorded case.Artifacts pins checked; fixtures remain distinct raw attribution pins','historicalCaveat':'Original early RED commands ran with uncommitted test additions; their complete uncommitted working tree was not independently frozen. Retained original tracked implementation commits, genuine logs/manifests/artifacts, and final regression test source are distinct. No retrospective current-source certification.','originalActualA':'../international-final-actual/A-final-keyless-3d3.json','originalActualL':'../../ticket-10/international-legacy-final/legacy-paid-3d3.json','fullCertificate':False,'paidCalls':0}
(out/'index.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'source-map-equivalence.json').write_bytes(read(source/'source-map-equivalence.json'))
(out/'commands-summary.json').write_text(json.dumps({p.stem:json.loads(read(p)) for p in sorted(source.glob('*.json')) if p.name!='source-map-equivalence.json'},indent=2)+'\n')
print(json.dumps({'archiveBytes':archive.stat().st_size,'members':len(index),'expandedBytes':total,'runs':len(runs),'recordedAuditFindings':sum(r['recordedAuditFindings'] for r in runs)}))
