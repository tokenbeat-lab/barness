import hashlib, json, os, pathlib, subprocess, sys
root=pathlib.Path(sys.argv[1])
work=pathlib.Path.cwd()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def selected(kind):
 out={}
 shared={'ai/live/'+f+'_test.go' for f in ['main','recorder','proxy','combos','decisions_config','decisions_sources','session']}
 prefixes=['ai/examples/requestid/','ai/internal/testkit/evidence/','ai/internal/testkit/audit/']
 if kind=='M3':prefixes+=['ai/internal/testkit/minimax/','ai/internal/testkit/minimaxlive/','ai/internal/testkit/supportmatrix/','ai/live/testdata/minimax/']
 else:prefixes+=['ai/internal/testkit/glm/']
 for base,dirs,files in os.walk(work/'ai'):
  dirs[:]=[d for d in dirs if d not in {'node_modules','.evidence'}]
  for file in files:
   p=pathlib.Path(base)/file;n=p.relative_to(work).as_posix()
   runtime=p.parent==work/'ai' and n.endswith('.go') and not n.endswith('_test.go')
   capture=n in shared or n.startswith('ai/live/'+('minimax_' if kind=='M3' else 'glm_')) and n.endswith('.go')
   prefix=any(n.startswith(q) for q in prefixes) and not n.endswith('_test.go') and (kind=='M3' or n.endswith('.go'))
   if runtime or capture or prefix:out[n]=sha(p.read_bytes())
 for n in ['go.mod','go.sum']:out[n]=sha((work/n).read_bytes())
 return out
maps={k:selected(k) for k in ['M3','Q']}
proof=[]
for kind,base,pattern,filename in [('M3','minimax-global-formal-glm','mm-global-formal-m3-*','minimax-report.json'),('Q','minimax-global-glm-corrective-1-reviewed','glm-corrective-1-*','glm-execution-source.json')]:
 routes=sorted(p for p in (root/'.evidence'/base).glob(pattern) if p.is_dir())
 assert len(routes)==3
 for d in routes:
  found=list(d.glob('*/'+filename));assert len(found)==1
  p=found[0];raw=p.read_bytes();obj=json.loads(raw)
  expected=obj['executionSource'] if kind=='M3' else obj
  expected={n:v.removeprefix('sha256:') for n,v in expected.items()}
  current=maps[kind]
  changed=[n for n in sorted(set(expected)|set(current)) if expected.get(n)!=current.get(n)]
  assert not changed,(d.name,changed)
  assert len(current)==(263 if kind=='M3' else 217)
  proof.append({'family':kind,'route':d.name,'proof':p.relative_to(root).as_posix(),'proofSHA256':sha(raw),'files':len(current),'currentMapSHA256':sha(json.dumps(current,sort_keys=True,separators=(',',':')).encode()),'changed':changed,'qualificationUnchanged':True})
changed=subprocess.check_output(['git','diff','3d3a1fb','HEAD','--name-only'],cwd=work,text=True).splitlines()
changed_go=[n for n in changed if n.endswith('.go')]
producer_tests={'ai/e2e/minimax_pidiff_catalog_test.go','ai/e2e/minimax_pidiff_test.go','ai/e2e/minimax_catalog_release_test.go'}
assert all(n.startswith('ai/internal/testkit/release/') or n.startswith('ai/e2e/release_') or n in producer_tests for n in changed_go)
assert all(n not in m for m in maps.values() for n in changed_go)
out={'checkedHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=work,text=True).strip(),'originalRootSource':'3d3a1fb28e143a2c29d684f78edcad94c0217243','proofs':proof,'changedGo':changed_go,'scope':'release consumer/tests and authorized future-only catalog producer/tests; strict consumer SDK/oracle rules unchanged; all 3 M3 and all 3 Q execution sets exactly unchanged including additions/deletions','broadSourceStatus':'L1034 prepared guard and Jev protocol/text/visual Go-wide proofs are historical/stale; all five original producer jobs already FAIL. No pin refresh, paid approval reuse or new PASS. Original A full ordinary/race executions remain literal 3d3 history; targeted current tests do not replace them.'}
p=work/'.evidence/release-consumer/source-map-equivalence.json';p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'files':[(p['family'],p['route'],p['files']) for p in proof],'changedGo':len(changed_go),'drift':0}))
