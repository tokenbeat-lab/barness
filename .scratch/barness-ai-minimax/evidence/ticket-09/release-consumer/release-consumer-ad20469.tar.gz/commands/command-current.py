import datetime, json, os, pathlib, subprocess, sys, time
out = pathlib.Path(sys.argv[1]).resolve(); out.mkdir(parents=True, exist_ok=True)
name = sys.argv[2]; argv = sys.argv[3:]
start = time.time(); started = datetime.datetime.now(datetime.timezone.utc).isoformat()
env = {k:os.environ[k] for k in ["PATH","HOME","TMPDIR","GOCACHE","GOPATH","BARNESS_RELEASE_DIAGNOSTIC_BUNDLES"] if k in os.environ}
env["PYTHONDONTWRITEBYTECODE"] = "1"
evidence_dir = out / ("cases-" + name)
if name.startswith("fixed-"):env["BARNESS_AI_EVIDENCE_DIR"] = str(evidence_dir)
with (out / (name + ".log")).open("wb") as log:
    result = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, timeout=1200, env=env)
receipt = {"argv":argv,"workingDirectory":"/tmp/barness-minimax-10-global","sourceHead":subprocess.check_output(["git","rev-parse","HEAD"], text=True).strip(),"exit":result.returncode,"elapsedSeconds":round(time.time()-start,3),"startedAt":started,"finishedAt":datetime.datetime.now(datetime.timezone.utc).isoformat(),"environmentKeys":sorted(env),"credentialsRead":False,"evidenceDirectory":evidence_dir.name if name.startswith("fixed-") else None}
(out / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
