import json, pathlib, subprocess, sys, time
out = pathlib.Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
name = sys.argv[2]; argv = sys.argv[3:]
start = time.time()
with (out / (name + ".log")).open("wb") as log:
    result = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, timeout=1200)
receipt = {"argv":argv,"workingDirectory":"/tmp/barness-minimax-10-global","sourceHead":subprocess.check_output(["git","rev-parse","HEAD"], text=True).strip(),"exit":result.returncode,"elapsedSeconds":round(time.time()-start,3)}
(out / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
