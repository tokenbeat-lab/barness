import argparse
import datetime
import gzip
import io
import json
import tarfile
from collections import Counter
from pathlib import Path
from common import State, ROOT, COLLECTION, OUT, SOURCE, C_SOURCE, C_ARCHIVE_SHA, STEM, sha, load, compact
from minimax import curate as curate_minimax
from glm import curate as curate_glm
from glm_forensic import curate as curate_glm_forensic

parser = argparse.ArgumentParser()
parser.add_argument('--all-six-complete', action='store_true', required=True,
                    help='Use only after the parent confirms the six paid processes completed.')
parser.parse_args()
s = State()
names = ['mm-global-formal-m3-' + route for route in ('chat', 'responses', 'messages')]
names += ['glm-' + route for route in ('chat', 'responses', 'messages')]
intents = {}
# Refuse an incomplete or unaudited process before reading raw material.
for name in names:
    path = ROOT / '.evidence/minimax-launches' / (name + '.json')
    intent = load(path)
    s.check(intent['state'] == 'COMPLETED' and intent['exitCode'] in (0, 1)
            and intent['sourceCommit'] == SOURCE
            and intent['launcherAudit'] == {'passed': True, 'findings': []},
            'completed audited canonical launch', name)
    intents[name] = intent
    s.file('launches/' + path.name, path)
manifest = s.source_manifest()
review = load(COLLECTION / 'prerelease-source-review.json')
s.check(review['decision'] == 'APPROVED' and review['sourceCommit'] == SOURCE
        and review['authorizedRoutes'] == names, 'exact six-route approval', SOURCE)
for key, filename in [('sourceManifestSHA256', 'source-at-start.json'),
                      ('binariesManifestSHA256', 'binaries.json'), ('planSHA256', 'plan.json')]:
    s.check(review[key] == sha((COLLECTION / filename).read_bytes()), 'approval artifact binding', filename)
for name, pin in review['reviewReferences'].items():
    raw = s.git(name)
    s.check(sha(raw) == pin, 'fixed source review reference', name)
    s.add('reviews/' + name, raw, 'git:' + SOURCE + ':' + name)
prepared = load(COLLECTION / 'prepared.json')
s.check(prepared['planSHA256'] == sha((COLLECTION / 'plan.json').read_bytes()), 'prepared plan binding', SOURCE)
for name, pin in prepared['authorizationFiles'].items():
    s.check(sha((COLLECTION / name).read_bytes()) == pin, 'prepared authorization binding', name)
s.check(load(COLLECTION / 'checks.json') == {
    'passed': True, 'commands': {'vet': 0, 'vet-live': 0, 'no-key-live': 0}, 'credentialsRead': False},
    'keyless prerelease checks', SOURCE)
s.check(review['sourceEquivalenceSHA256'] == sha((COLLECTION / 'parent-source-equivalence.json').read_bytes()),
        'approved source equivalence binding', SOURCE)
for path in sorted(COLLECTION.iterdir()):
    if path.is_file() and path.name not in ('live.test', 'chineseeval', 'visualeval'):
        s.check(path.suffix in ('.json', '.log'), 'selected collection metadata', path.name)
        s.file('collection/' + path.name, path)
external_binaries = {}
for name, pin in load(COLLECTION / 'binaries.json').items():
    path = COLLECTION / name
    s.check(sha(path.read_bytes()) == pin, 'original prepared binary hash', name)
    external_binaries[name] = {'path': str(path), 'sha256': pin, 'bytes': path.stat().st_size,
                               'archived': False, 'retention': 'original prepared collection'}

reports = []
mini_ledgers = []
for name, intent in intents.items():
    s.check((COLLECTION / (name + '-intent.json')).read_bytes() ==
            (ROOT / '.evidence/minimax-launches' / (name + '.json')).read_bytes(),
            'collection and canonical launch bytes', name)
    if name.startswith('mm-'):
        report, ledger = curate_minimax(s, name, intent)
        mini_ledgers.append((name, ledger))
        prior_verify = load(COLLECTION / (name + '-origin-command.json'))
        s.check(prior_verify['exitCode'] == 0 and prior_verify['credentialsRead'] is False,
                'prior keyless public verification receipt', name)
    elif intent['exitCode'] == 0:
        report = curate_glm(s, name, intent)
    else:
        report = curate_glm_forensic(s, name, intent)
    reports.append(report)
catalogs = {report['catalogHash'] for report in reports}
s.check(catalogs == {'sha256:3718603f6ad6cee8a5b66251bede572b62e58fd290b3d7fc7a49504a1d274e4f'},
        'shared activated catalog hash', SOURCE)
formal_path = ROOT / '.evidence/minimax-stages/formal.jsonl'
formal_raw = formal_path.read_bytes()
receipts = [json.loads(raw) for raw in formal_raw.splitlines()]
previous = ''
slots = Counter()
for sequence, receipt in enumerate(receipts, 1):
    blank = dict(receipt)
    blank['hash'] = ''
    s.check(receipt['sequence'] == sequence and receipt['previous'] == previous
            and sha(compact(blank)) == receipt['hash'] and receipt['stage'] == 'formal',
            'formal canonical receipt chain', str(sequence))
    previous = receipt['hash']
    slots[receipt['kind']] += 1
s.check(len(receipts) == 75 and slots == {'reserve': 39, 'attempt': 36}, 'formal cumulative stage budget', SOURCE)
for name, prefix in mini_ledgers:
    s.check(prefix == receipts[:len(prefix)], 'formal exact canonical ledger prefix', name)
s.add('accounting/formal.jsonl', formal_raw, str(formal_path))

# This external boundary is an immutable retained candidate checkpoint, never a
# rewritten formal predecessor or a claim that candidate proof is formal proof.
c_dir = OUT.parent / 'barness-minimax-global-candidate-capsule'
c_index_path = c_dir / 'international-candidates-7605332.json'
c_index = load(c_index_path)
c_archive = c_dir / c_index['archive']
s.check(c_index['sourceCommit'] == C_SOURCE and sha(c_archive.read_bytes()) == C_ARCHIVE_SHA
        and c_index['archiveSha256'] == C_ARCHIVE_SHA, 'retained candidate archive lineage', C_SOURCE)
for name in ('international-candidates-7605332.json', 'international-candidates-7605332-audit.md',
             'international-candidates-7605332-provenance.json'):
    s.file('candidate-lineage/' + name, c_dir / name)
candidate_path = ROOT / '.evidence/minimax-stages/candidate.jsonl'
candidate_raw = candidate_path.read_bytes()
s.check(sha(candidate_raw) == c_index['stageBudgetSnapshot']['ledgerSha256'],
        'unchanged historical inclusive candidate accounting', C_SOURCE)
s.add('accounting/candidate.jsonl', candidate_raw, str(candidate_path))
promotion_path = ROOT / '.evidence/minimax-global-candidate-complete/promotion.json'
equivalence = load(COLLECTION / 'parent-source-equivalence.json')
s.check(sha(promotion_path.read_bytes()) == equivalence['promotionReceiptSHA256'],
        'activation candidate promotion receipt', C_SOURCE)
s.file('candidate-lineage/promotion.json', promotion_path)
before = {name.split('/' + C_SOURCE + '/', 1)[1]: pin['sha256']
          for name, pin in c_index['files'].items() if name.startswith('source/' + C_SOURCE + '/')}
changes = {name: {'before': before.get(name), 'after': pin}
           for name, pin in manifest['files'].items() if before.get(name) != pin}
s.check(changes == equivalence['changedDataFiles'] and len(changes) == 6
        and all(name.endswith('.json') for name in changes), 'six data changes only since candidates', SOURCE)
consumption = load(COLLECTION / 'consumption.json')
route_consumption = {row['route']: row for row in consumption['routes']}
for name, intent in intents.items():
    budget = route_consumption[name]
    expected_calls = 13 if name.startswith('mm-') else 22
    expected_attempts = 12 if name.startswith('mm-') else 22
    expected_status = 'PASS' if intent['exitCode'] == 0 else 'FAIL'
    s.check(budget['state'] == 'REPORTED' and budget['status'] == expected_status
            and budget['calls'] == expected_calls and budget['attempts'] == expected_attempts
            and intent['budget']['calls'] == expected_calls and intent['budget']['attempts'] == expected_attempts,
            'completed collection consumption snapshot', name)

archive = OUT / (STEM + '.tar.gz')
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, raw in sorted(s.items.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    s.check(len(members) == len(s.items) and {x.name for x in members} == set(s.items),
            'archive roundtrip complete inventory', archive.name)
    for member in members:
        s.check(member.isfile() and tar.extractfile(member).read() == s.items[member.name],
                'archive roundtrip exact bytes', member.name)
created = datetime.datetime.now(datetime.timezone.utc).isoformat()
index = {'schema': 1, 'kind': 'actual-international-M3-formal-and-partial-GLM-renewal-checkpoint',
         'createdAt': created, 'sourceCommit': SOURCE, 'archive': archive.name,
         'archiveSha256': sha(archive.read_bytes()), 'archiveBytes': archive.stat().st_size,
         'files': {name: {'sha256': sha(raw), 'bytes': len(raw), 'original': s.locations[name]}
                   for name, raw in sorted(s.items.items())},
         'generationSourceFileCount': 1026,
         'portableSourceFileCount': sum(name.startswith('source/' + SOURCE + '/') for name in s.items),
         'reports': reports, 'externalBinaries': external_binaries,
         'candidateLineage': {'sourceCommit': C_SOURCE, 'archive': c_archive.name,
                              'archiveSha256': C_ARCHIVE_SHA, 'archiveBytes': c_archive.stat().st_size,
                              'archivedInThisCapsule': False, 'original': str(c_archive),
                              'stageBudget': c_index['stageBudgetSnapshot']},
         'miniMaxFormalBudget': {'calls': 39, 'reservedAttempts': 39, 'attempts': 36,
                                 'maxCalls': 60, 'maxAttempts': 72, 'receipts': 75,
                                 'ledgerSha256': sha(formal_raw)},
         'glmBudget': {'calls': 66, 'attempts': 66, 'maxCalls': 72, 'maxAttempts': 96,
                       'modelsPerRoute': 2, 'casesPerModel': 11},
         'actualQualificationOutcome': 'PARTIAL' if any(report['outcome'] != 'PASS' for report in reports) else 'PASS',
         'changedDataFilesSinceCandidates': changes,
         'checks': dict(sorted(s.checks.items())), 'totalChecks': sum(s.checks.values()),
         'credentialsReadByCurator': False, 'networkUsedByCurator': False,
         'testsRunByCurator': False, 'repositoryModifiedByCurator': False,
         'authority': 'Original common-root completed launcher origin/capture-pin receipts; future curated origins may reference these unchanged bytes. Imported bundles do not mint authority.',
         'scope': 'Three own international M3 formal identities plus original GLM renewal outcomes, including unchanged failed incomplete forensic captures. Failed/incomplete inputs provide no formal support. Other old-route renewal, four business effects and the final release gate remain separate.'}
index_path = OUT / (STEM + '.json')
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
lines = ['# International M3 formal and GLM renewal capsule audit', '',
         'Integrity PASS; actual qualification ' + index['actualQualificationOutcome'] +
         '. Keyless, read-only curation of committed source `' + SOURCE + '`.', '',
         f"All {sum(s.checks.values())} curation checks passed. The {archive.stat().st_size:,}-byte archive "
         f"contains {len(s.items)} exact files, including all 1026 generation-source files plus captured "
         'execution-source additions, six original raw captures, existing published support reports, fixed official '
         'sources, source/binary/plan/approval/check/command receipts, original canonical launcher receipts, '
         'and both MiniMax stage ledger snapshots. Every archived byte passed a roundtrip comparison. '
         'Executable binaries stay in the original collection with explicit hashes and sizes.', '',
         '| Original process | Outcome / complete | Models | PASS cases | Calls / actual attempts | Known usage / unknown final consumption |',
         '| --- | --- | --- | --- | --- | --- |']
for report in reports:
    models = 'MiniMax-M3' if report['family'] == 'minimax' else 'glm-5.3 + glm-5.2'
    cases = sum(x['outcome'] == 'PASS' for x in report.get('cases', report.get('scenes', [])))
    calls = 13 if report['family'] == 'minimax' else 22
    attempts = 12 if report['family'] == 'minimax' else 22
    lines.append(f"| {report['job']} | {report['outcome']} / {report['complete']} | {models} | {cases} | {calls} / {attempts} | "
                 f"{report['knownUsageAttempts']} / {report['unknownFinalConsumptionAttempts']} |")
lines += ['',
          'All actual exchanges returned HTTP 200 and carried the selected actual model at the captured '
          'endpoint. MiniMax used `https://api.minimax.io/v1` for Chat/Responses and '
          '`https://api.minimax.io/anthropic` for Messages. All M3 native continuations passed. '
          'GLM model-qualified tool-result/native-history cases retain their original outcomes. M3 preflight checks made '
          'zero HTTP attempts. Existing published reports match their own sealed formal reports and original '
          'canonical origin or capture-pin receipts; failed GLM Responses has no seal, published support '
          'view or successful capture pins. Its 21 PASS scenes and failed `glm-5.3/control-low` scene '
          'remain forensic evidence. That scene retains 4096 known output tokens (4094 reasoning), '
          'truncated capture and original `inventory read failed`; both model views remain incomplete. '
          'All six use activated catalog '
          '`sha256:3718603f6ad6cee8a5b66251bede572b62e58fd290b3d7fc7a49504a1d274e4f`.', '',
          'MiniMax formal totals: 39 / 60 Logical Calls, 36 / 72 actual Attempts, 39 reservations and '
          '75 linked receipts. GLM renewal totals: 66 / 72 calls and 66 / 96 attempts, with no process '
          'retries. The separately retained candidate archive remains source 7605332, SHA-256 '
          '`' + C_ARCHIVE_SHA + '`, with 49 calls / 45 actual attempts and unchanged historical failures. '
          'Exactly six declared activation/catalog-pin JSON files changed between candidate and formal '
          'generation sources; all other selected source stayed identical.', '',
          'Exact complete/partial/unreported Observer labels and known token/cost values are preserved in '
          'the index. Normal partial reports retain known counters while omitted categories remain '
          'unknown; a known-usage count does not mean complete reporting. Cancellation consumption is '
          'unknown, including partial initial-zero frames; zero DTO counters never establish a free bill. '
          'Known usage and FX-derived GLM estimates are not '
          'invoices. GLM account/region/privilege verification remains recorded as unknown. All selected-key '
          'launcher audits and capture audits have no findings.', '',
          'Authority comes from the original common-root launcher receipts. This archive does not mint '
          'authority for an imported bundle. This curator read no `.env`, called no vendor, ran no tests '
          'or public verifier, and changed no repository files. Other old-route renewal, four business '
          'effects and the final release gate are separate evidence.', '',
          f"Repeatable keyless byte verification: `python3 verify_capsule.py {index_path.name}`. "
          'The separate candidate archive may be supplied with `--candidate-archive` to verify that external boundary.', '',
          f"Archive SHA-256: `{index['archiveSha256']}`."]
audit_path = OUT / (STEM + '-audit.md')
audit_path.write_text('\n'.join(lines) + '\n')
scripts = ('retain.py', 'common.py', 'minimax.py', 'glm.py', 'glm_forensic.py', 'prepare_source.py', 'verify_capsule.py')
provenance = {'schema': 1, 'createdAt': created, 'curator': '/root/candidate_capsule',
              'sourceCommit': SOURCE, 'originalCollection': str(COLLECTION),
              'scripts': {name: {'sha256': sha((OUT / name).read_bytes()), 'bytes': (OUT / name).stat().st_size}
                          for name in scripts},
              'outputs': {path.name: {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
                          for path in (archive, index_path, audit_path)},
              'credentialsRead': False, 'networkUsed': False, 'testsRun': False, 'repositoryModified': False}
prov_path = OUT / (STEM + '-provenance.json')
prov_path.write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(s.items), 'checks': sum(s.checks.values()), 'outputs': {
    path.name: {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
    for path in (archive, index_path, audit_path, prov_path)}}, indent=2))
