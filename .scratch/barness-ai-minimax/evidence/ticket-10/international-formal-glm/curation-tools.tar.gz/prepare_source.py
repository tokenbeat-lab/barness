from common import State, COLLECTION, OUT, SOURCE, C_SOURCE, C_ARCHIVE_SHA, sha, load
import json
import datetime

s = State()
manifest = s.source_manifest()
equivalence = load(COLLECTION / 'parent-source-equivalence.json')
c_index = load(OUT.parent / 'barness-minimax-global-candidate-capsule/international-candidates-7605332.json')
s.check(c_index['sourceCommit'] == C_SOURCE and c_index['archiveSha256'] == C_ARCHIVE_SHA,
        'retained candidate source lineage', C_SOURCE)
before = {name.split('/' + C_SOURCE + '/', 1)[1]: pin['sha256']
          for name, pin in c_index['files'].items() if name.startswith('source/' + C_SOURCE + '/')}
changed = {name: {'before': before.get(name), 'after': pin}
           for name, pin in manifest['files'].items() if before.get(name) != pin}
s.check(changed == equivalence['changedDataFiles'] and len(changed) == 6,
        'exact six activation and pin changes', SOURCE)
s.check(all(name.endswith('.json') for name in changed), 'only data source changes', SOURCE)
for name, raw in s.items.items():
    relative = name.split('/' + SOURCE + '/', 1)[1]
    target = OUT / 'source-cache' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
result = {'kind': 'read-only-committed-source-preparation',
          'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'sourceCommit': SOURCE, 'generationSourceFiles': 1026,
          'sourceManifestSHA256': sha((COLLECTION / 'source-at-start.json').read_bytes()),
          'candidateArchiveSHA256': C_ARCHIVE_SHA, 'changedDataFiles': changed,
          'checks': dict(s.checks), 'totalChecks': sum(s.checks.values()),
          'credentialsRead': False, 'networkUsed': False, 'rootModified': False,
          'collectionMetadataFinalized': False}
(OUT / 'source-preparation.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'sourceFiles': 1026, 'checks': sum(s.checks.values()),
                  'dataChanges': list(changed), 'collectionMetadataFinalized': False}, indent=2))
