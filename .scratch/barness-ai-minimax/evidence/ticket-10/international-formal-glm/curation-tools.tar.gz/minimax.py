from collections import Counter
from decimal import Decimal
import base64
import json
from common import COLLECTION, SOURCE, sha, load


def curate(s, name, intent):
    origin = intent['origin']
    base = COLLECTION / name / origin['session']
    prefix = 'minimax/' + name + '/' + origin['session']
    manifest, count, size = s.sealed(name, base, prefix, 'minimax-integrity.json',
                                    {'minimax-integrity.json', 'live-report.json'})
    r = load(base / 'minimax-report.json')
    p = load(base / 'live-report.json')
    s.check(r['gitCommit'] == SOURCE and r['mode'] == 'live' and r['kind'] == 'minimax-formal'
            and r['stage'] == 'formal' and r['outcome'] == 'PASS' and r['complete']
            and r['auditPassed'], 'MiniMax complete formal outcome', name)
    s.check(len(r['expected']) == len(r['calls']) == len(manifest['cases']) == 13,
            'MiniMax fixed inventory', name)
    s.check([x['id'] for x in r['expected']] == [x['id'] for x in r['calls']],
            'MiniMax exact case order', name)
    s.check(r['budget']['calls'] == r['budget']['reservedAttempts'] == 13 and
            r['budget']['attempts'] == 12 and r['cumulativeSlotBudget'] == r['budget'],
            'MiniMax formal budget', name)
    for path, pin in r['executionSource'].items():
        s.source(path, pin)
    official = load(base / 'minimax-sources.json')
    official_manifest = base64.b64decode(official['sources.json'], validate=True)
    s.check(sha(official_manifest) == r['sourceHash'], 'MiniMax official manifest', name)
    for entry in json.loads(official_manifest):
        s.check(sha(base64.b64decode(official[entry['file']], validate=True)) == entry['sha256'],
                'MiniMax official source', name + '/' + entry['file'])
    for key, filename in [('reportSha256', 'minimax-report.json'),
                          ('sealSha256', 'minimax-integrity.json'),
                          ('ledgerSha256', 'minimax-ledger.json')]:
        s.check(origin[key] == sha((base / filename).read_bytes()), 'MiniMax canonical origin hash', name)
    for key, filename in [('sourceManifestSha256', 'source-at-start.json'),
                          ('binariesManifestSha256', 'binaries.json'), ('planSha256', 'plan.json')]:
        s.check(origin[key] == sha((COLLECTION / filename).read_bytes()), 'MiniMax canonical origin source', name)
    s.check(intent['reportedFileSha256'] == origin['reportSha256'], 'MiniMax intent report binding', name)
    s.check(p['minimax']['reportSha256'] == origin['reportSha256'] and
            p['minimax']['sealSha256'] == origin['sealSha256'] and
            p['minimax']['planSha256'] == r['planHash'] and
            p['minimax']['sourceSha256'] == r['sourceHash'], 'MiniMax published source anchors', name)
    s.check(p['gitCommit'] == SOURCE and p['provider'] == 'minimax' and p['model'] == 'MiniMax-M3'
            and p['catalogHash'] == r['catalogHash'] and p['catalogVersion'] == r['catalogVersion']
            and p['endpoint'] == r['identity']['endpoint'] and p['api'] == r['identity']['api'],
            'MiniMax published target identity', name)
    s.check(p['expected'] == [x['id'] for x in r['expected']] and
            [x['id'] for x in p['scenarios']] == p['expected'] and
            all(x['outcome'] == 'PASS' for x in p['scenarios']) and
            p['budget']['callsUsed'] == 13 and p['budget']['httpAttempts'] == 12,
            'MiniMax published own inventory and budget', name)
    reporting = Counter()
    tokens = Counter()
    known_usd = Decimal('0')
    cases = []
    for call, published in zip(r['calls'], p['scenarios']):
        case = base / call['caseId']
        a = load(case / 'assertions.json')
        s.check(call['outcome'] == 'PASS' and call['rerun'] == 0 and a['status'] == 'PASS'
                and all(x['pass'] for x in a['assertions']), 'MiniMax own case assertions', name + '/' + call['id'])
        obs = load(case / 'observations.json')
        kinds = Counter(x['kind'] for x in obs)
        exchanges = load(case / 'exchanges.json')
        finished = [x['attempt'] for x in obs if x['kind'] == 'attempt_finished']
        attempts = len(call.get('attemptReceipts') or [])
        s.check(kinds['call_started'] == kinds['call_finished'] == 1 and
                kinds['attempt_started'] == kinds['attempt_finished'] == attempts == len(exchanges),
                'MiniMax Observer and call accounting', name + '/' + call['id'])
        s.check(published['caseId'] == call['caseId'] and published['attempts'] == attempts
                and published['calls'] == 1 and published['model'] == 'MiniMax-M3',
                'MiniMax published case exact facts', name + '/' + call['id'])
        metrics = load(case / 'metrics.json')
        s.check(metrics['activeBodies'] == 0 and metrics['observer']['failed'] == 0
                and metrics['observer']['dropped'] == 0, 'MiniMax settled resources', name + '/' + call['id'])
        result = load(case / 'result.json')
        for ex in exchanges:
            suffix = {'chat': '/chat/completions', 'responses': '/responses', 'messages': '/v1/messages'}[r['identity']['route']]
            s.check(ex['status'] == 200 and ex['url'].split('?', 1)[0] == r['identity']['endpoint'] + suffix,
                    'MiniMax actual global endpoint', name + '/' + call['id'])
            s.redacted_exchange(name + '/' + call['id'], ex)
        if call['id'] == 'preflight-error':
            s.check(attempts == 0 and result['errorCode'] == 'invalid_request', 'MiniMax zero attempt preflight', name)
        else:
            s.check(attempts == 1 and call['rawModels'] == ['MiniMax-M3']
                    and finished[0]['httpStatus'] == 200, 'MiniMax actual model and one attempt', name + '/' + call['id'])
            reporting[finished[0]['usageReporting']] += 1
            if call['id'] == 'cancel':
                s.check(result['errorCode'] == 'canceled' and
                        finished[0]['usageReporting'] in ('partial', 'unreported'),
                        'MiniMax cancellation unknown final consumption', name)
            else:
                s.check(finished[0]['usageReporting'] in ('complete', 'partial') and
                        finished[0]['usage']['totalTokens'] > 0, 'MiniMax known usage', name + '/' + call['id'])
                usage = finished[0]['usage']
                known_usd += Decimal(str(usage['cost']['total']))
                for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'reasoning', 'totalTokens'):
                    tokens[key] += usage.get(key, 0)
        cases.append({'id': call['id'], 'caseId': call['caseId'], 'outcome': call['outcome'],
                      'attempts': attempts, 'actualModels': call.get('rawModels') or [],
                      'usageReporting': finished[0]['usageReporting'] if finished else 'no-attempt'})
    ledger = load(base / 'minimax-ledger.json')
    s.check(ledger['predecessors'] in ({}, None), 'MiniMax formal ledger independent stage', name)
    own = [x for x in ledger['receipts'] if x['session'] == r['session']]
    expected = [receipt for call in r['calls'] for receipt in [call['reservation']] + (call.get('attemptReceipts') or [])]
    s.check(own == expected and len(own) == 25, 'MiniMax exact own ledger receipts', name)
    return {'family': 'minimax', 'job': name, 'archiveDirectory': prefix,
            'session': r['session'], 'sourceCommit': SOURCE, 'identity': r['identity'],
            'outcome': r['outcome'], 'complete': r['complete'], 'files': count, 'bytes': size,
            'reportFile': 'minimax-report.json', 'sealFile': 'minimax-integrity.json',
            'reportSha256': origin['reportSha256'], 'sealSha256': origin['sealSha256'],
            'publishedSupportReportSha256': sha((base / 'live-report.json').read_bytes()),
            'catalogHash': r['catalogHash'], 'catalogVersion': r['catalogVersion'],
            'budget': r['budget'], 'cases': cases, 'nativeContinuation': 'PASS',
            'knownUsageAttempts': 11, 'unknownFinalConsumptionAttempts': 1,
            'observerUsageReportingCounts': dict(reporting), 'knownUsageTokens': dict(tokens),
            'knownUsageUSD': str(known_usd), 'knownCostIsNotInvoice': True}, ledger['receipts']
