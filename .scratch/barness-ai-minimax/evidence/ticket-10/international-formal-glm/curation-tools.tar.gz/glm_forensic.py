"""Retain failed raw evidence without manufacturing a success seal or support view."""
from collections import Counter
from decimal import Decimal
from common import COLLECTION, SOURCE, sha, load
from glm import wire_models


def curate(s, name, intent):
    sessions = [p for p in (COLLECTION / name).iterdir() if p.is_dir()]
    s.check(len(sessions) == 1, 'forensic GLM exactly one session', name)
    base = sessions[0]
    prefix = 'glm-forensic/' + name + '/' + base.name
    files = {p.relative_to(base).as_posix(): p for p in base.rglob('*') if p.is_file()}
    for path, p in sorted(files.items()):
        s.file(prefix + '/' + path, p)
    s.check('glm-integrity.json' not in files and 'live-report.json' not in files
            and 'capturePins' not in intent, 'forensic GLM has no support authority', name)
    s.check(load(base / 'audit.json') == {'findings': []}, 'forensic capture audit', name)
    manifest = load(base / 'manifest.json')
    s.check(manifest['git_commit'] == SOURCE, 'forensic manifest source', name)
    for case in manifest['cases']:
        for kind in ('artifacts', 'fixtures'):
            for path, pin in case.get(kind, {}).items():
                p = base / case['dir'] / path
                s.check(p.is_file() and sha(p.read_bytes()) == pin,
                        'forensic manifest artifact reference', name + '/' + case['dir'] + '/' + path)
    raw = (base / 'formal-glm-report.json').read_bytes()
    r = load(base / 'formal-glm-report.json')
    s.check(sha(raw) == intent['reportedFileSha256'], 'forensic canonical own report hash', name)
    s.check(r['kind'] == 'glm-formal' and r['outcome'] == 'FAIL' and r['complete'] is False
            and r['auditPassed'] and r['gitCommit'] == SOURCE and r['mode'] == 'live',
            'forensic failed incomplete scope', name)
    for path, pin in load(base / 'glm-execution-source.json').items():
        s.source(path, pin)
    sources_base = base / 'GLM11-sources'
    sources_raw = (sources_base / 'sources.json').read_bytes()
    sources = load(sources_base / 'sources.json')
    s.check(sha(sources_raw) == r['sourceManifestHash'], 'forensic official source manifest', name)
    for pin in sources['sources']:
        s.check(sha((sources_base / pin['file']).read_bytes()) == pin['sha256'],
                'forensic official source pin', name + '/' + pin['file'])
    for key, filename in [('candidateSHA256', 'candidate.json'), ('planSHA256', 'plan.json')]:
        s.check(sha((sources_base / filename).read_bytes()) == sources[key], 'forensic official plan pin', name)
    plan = load(sources_base / 'plan.json')
    s.check((sources_base / 'plan.json').read_bytes() == s.git('ai/live/testdata/glm-candidate/plan.json'),
            'forensic frozen plan source', name)
    expected = [x['id'] for x in plan['routes'][r['route']]]
    s.check(r['expected'] == expected and [x['id'] for x in r['scenarios']] == expected
            and len(expected) == 22 and len(manifest['cases']) == 23,
            'forensic exact fixed inventory', name)
    s.check(r['budget']['callsUsed'] == r['budget']['httpAttempts'] == r['budget']['attemptsReserved'] == 22
            and r['budget']['replayAttempts'] == r['budget']['retries'] == 0,
            'forensic consumed budget retained', name)
    scenes = []
    reporting = Counter()
    known_tokens = Counter()
    known_cost = Decimal('0')
    for scene in r['scenarios']:
        case_id = 'GLM11-' + scene['id'].replace('/', '-')
        case = base / case_id
        s.check(scene['calls'] == scene['httpAttempts'] == 1 and scene['replayAttempts'] == 0,
                'forensic own scene accounting', name + '/' + scene['id'])
        assertions = load(case / 'assertions.json')
        s.check(assertions['status'] == scene['outcome'], 'forensic original case outcome', name + '/' + scene['id'])
        observations = load(case / 'observations-1.json')
        kinds = Counter(x['kind'] for x in observations)
        s.check(kinds['call_started'] == kinds['call_finished'] == kinds['attempt_started'] == kinds['attempt_finished'] == 1,
                'forensic Observer settles', name + '/' + scene['id'])
        finished = [x['attempt'] for x in observations if x['kind'] == 'attempt_finished'][0]
        reporting[finished['usageReporting']] += 1
        exchanges = load(case / 'attempt-1-exchanges.json')
        s.check(len(exchanges) == 1 and exchanges[0]['status'] == finished['httpStatus'] == 200,
                'forensic actual one HTTP attempt', name + '/' + scene['id'])
        exchange = exchanges[0]
        suffix = {'chat': '/chat/completions', 'responses': '/responses', 'messages': '/v1/messages'}[r['route']]
        s.check(exchange['url'].split('?', 1)[0] == r['endpoint'] + suffix,
                'forensic actual endpoint', name + '/' + scene['id'])
        s.redacted_exchange(name + '/' + scene['id'], exchange)
        models = wire_models(exchange['responseBody'])
        s.check(models and all(model.lower() == scene['model'] for model in models),
                'forensic observed actual model', name + '/' + scene['id'])
        canceled = scene['id'].endswith('/cancel')
        if not canceled:
            s.check(finished['usageReporting'] in ('complete', 'partial') and finished['usage']['totalTokens'] > 0,
                    'forensic retained known Observer usage', name + '/' + scene['id'])
            for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'reasoning', 'totalTokens'):
                known_tokens[key] += finished['usage'].get(key, 0)
            known_cost += Decimal(str(finished['usage']['cost']['total']))
        else:
            s.check(finished['usageReporting'] in ('partial', 'unreported'),
                    'forensic cancellation unknown final consumption', name + '/' + scene['id'])
        scenes.append({'id': scene['id'], 'model': scene['model'], 'actualModels': models,
                       'outcome': scene['outcome'], 'failure': scene['failure'], 'attempts': 1,
                       'usageReporting': finished['usageReporting'],
                       'finalConsumptionUnknown': canceled, 'captureTruncated': scene['truncated'],
                       'failedAssertions': [x for x in assertions['assertions'] if not x['pass']],
                       'capturedResponseBodyBytes': len(exchange['responseBody'].encode()),
                       'eventsBytes': (case / 'events.json').stat().st_size})
    model_reports = []
    for model in ('glm-5.3', 'glm-5.2'):
        path = base / ('formal-' + model + '-report.json')
        mr = load(path)
        s.check(mr['model'] == model and mr['complete'] is False and mr['gitCommit'] == SOURCE
                and mr['calls'] == mr['httpAttempts'] == 11, 'forensic incomplete model view retained', name + '/' + model)
        model_reports.append({'model': model, 'outcome': mr['outcome'], 'complete': mr['complete'],
                              'reportSha256': sha(path.read_bytes()), 'reportedKnownUsage': mr['reportedKnownUsage']})
    return {'family': 'glm-forensic', 'job': name, 'archiveDirectory': prefix, 'session': base.name,
            'sourceCommit': SOURCE, 'route': r['route'], 'api': r['api'], 'endpoint': r['endpoint'],
            'models': r['models'], 'outcome': r['outcome'], 'complete': r['complete'],
            'failure': r['failure'], 'files': len(files), 'bytes': sum(p.stat().st_size for p in files.values()),
            'reportFile': 'formal-glm-report.json', 'sealFile': None, 'producerSealPresent': False,
            'reportSha256': sha(raw), 'sealSha256': None, 'publishedSupportReportSha256': None,
            'supportEligible': False, 'forensicSnapshotOnly': True,
            'catalogHash': r['catalogHash'], 'catalogVersion': r['catalogVersion'], 'budget': r['budget'],
            'scenes': scenes, 'modelReports': model_reports, 'knownUsageAttempts': 20,
            'unknownFinalConsumptionAttempts': 2, 'observerUsageReportingCounts': dict(reporting),
            'knownUsageTokens': dict(known_tokens), 'knownUsageEstimatedUSD': str(known_cost),
            'knownCostIsNotInvoice': True, 'accountVerification': r['accountVerification'],
            'regionVerification': r['regionVerification'], 'privilegeVerification': r['privilegeVerification']}
