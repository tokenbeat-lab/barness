> ## Documentation Index
> Fetch the complete documentation index at: https://platform.minimax.io/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# Models

> Overview of MiniMax AI models and their capabilities

<Info className="model-retirement-notice">
  **MiniMax M2.5 and M2.7 Model Retirement Notice**

  As we roll out newer models, we’ll be retiring the MiniMax M2.5 and M2.7 model families. To give existing users time to migrate, we’ll follow this schedule:

  * **October 19, 2026:** These models will no longer be available to new users.
  * **November 18, 2026:** These models will be retired.

  **Pay-as-you-go API users**

  Existing users can continue accessing these models until their retirement on November 18, 2026. Once retired, API requests to these models will no longer work. Please review your usage of these models and complete your migration before the retirement date.

  **M Plan and Token Plan users**

  Starting October 19, 2026, all requests to M2.5 and M2.7 models under these plans will automatically be routed to **M3.1 Flash Preview**.

  Existing model names will continue to work for backward compatibility, so you won’t need to update the model names in your requests. Your plan’s usage allowances will remain unchanged.

  To avoid service disruptions, **please check whether your applications rely on these models and start planning your migration now.**

  Thank you for your continued support and trust in MiniMax.
</Info>

### Language

<Note>MiniMax-M3.1-Flash-Preview is available only through M Plan and MiniMax Code for now.</Note>

| **Models**           | **Description**           | **Features**                 |
| :- | :- | :- |
| <a href="/docs/api-reference/text-anthropic-api" style={{whiteSpace:"nowrap"}}>MiniMax-M3.1-Flash-Preview</a> | Frontier multimodal coding model with 1M context window and tunable thinking depth | • Multimodal<br />• 1M context window<br />• Frontier coding<br />• Tunable thinking depth |
| [MiniMax-M3](/docs/api-reference/text-anthropic-api) | Frontier multimodal coding model with 1M context window | • Multimodal<br />• 1M context window<br />• Frontier coding |
| [MiniMax-M2.7](/docs/api-reference/text-anthropic-api) | Beginning the journey of recursive self-improvement | • Top real-world engineering <br />• Professional office delivery <br /> •  Character-rich interaction |
| [MiniMax-M2.7-highspeed](/docs/api-reference/text-anthropic-api) | Same performance as M2.7<br /> • Significantly faster inference | • Polyglot code mastery<br />• Precision code refactoring <br /> • Low latency |

<Accordion title="Legacy Models">
  | **Models**           | **Description**           | **Features**                 |
  | :- | :- | :- |
  | [MiniMax-M2.5](/docs/api-reference/text-anthropic-api) | • Optimized for code generation and refactoring | • Peak Performance. Ultimate Value. Master the Complex. |
  | [MiniMax-M2.5-highspeed](/docs/api-reference/text-anthropic-api) | • Same performance as M2.5<br /> • Significantly faster inference | • Polyglot code mastery<br />• Precision code refactoring <br /> • Low latency |
  | [MiniMax-M2.1](/docs/api-reference/text-anthropic-api) | • 230B total parameters with 10B activated per inference<br /> • Optimized for code generation and refactoring | • Polyglot code mastery<br />• Precision code refactoring <br /> • Enhanced reasoning |
  | [MiniMax-M2.1-highspeed](/docs/api-reference/text-anthropic-api) | • Same performance as M2.1<br /> • Significantly faster inference | • Polyglot code mastery<br />• Precision code refactoring <br /> • Low latency |
  | [MiniMax-M2](/docs/api-reference/text-anthropic-api) | • Context Length: 200k tokens<br />• Maximum Output: 128k tokens (including CoT) | • Agentic capabilities<br />• Function calling<br />• Advanced reasoning<br />• Real-time streaming |
</Accordion>

### Video

| **Models**             | **Description**                   | **Res.& Dur.**         | **FPS**         |
| :- | :- | :- | :- |
| [MiniMax H3](/docs/api-reference/video-generation-v2-create) | Next-gen open general-purpose multimodal video model<br />• Text-to-Video / Image-to-Video / First–Last Frame / Multimodal reference | • 768P / 2K<br />• 4–15s | 24 fps |
| [MiniMax H3 Max](/docs/api-reference/video-generation-v2-create) | High-speed video model post-trained by [fal.ai](https://fal.ai/) on MiniMax H3, optimized for high-speed generation<br />• Text-to-Video / Image-to-Video (first / last frame) | • 480P / 768P<br />• 5–15s | 24 fps |

<Accordion title="Legacy Models">
  | **Models**             | **Description**                   | **Res.& Dur.**         | **FPS**         |
  | :- | :- | :- | :- |
  | [MiniMax Hailuo 2.3](/docs/api-reference/video-generation-t2v) | • Text to Video & Image to Video<br />• SOTA instruction following<br />• Extreme physics mastery | • 1080p 6s<br />• 768p 6s, 10s<br /> | 24 fps |
  | [MiniMax Hailuo 2.3Fast](/docs/api-reference/video-generation-i2v) | •  Image to Video<br />• Extreme physics mastery<br />• Value and Efficiency | • 1080p 6s<br />• 768p 6s, 10s<br /> | 24 fps |
  | [MiniMax Hailuo 02](/docs/api-reference/video-generation-t2v) | • Text to Video & Image to Video<br />• SOTA instruction following<br />• Extreme physics mastery | • 1080p 6s<br />• 768p 6s, 10s<br />• 512p 6s, 10s | 24 fps |
</Accordion>

### Audio

| **Models**             | **Description**           | **Features**                           |
| :- | :- | :- |
| [speech-2.8-hd](/docs/api-reference/speech-t2a-http) | • Ultra-realistic quality featuring sound tags | • 40 languages supported<br />• 7 emotions supported<br />• specified languages and dialects supported |
| [speech-2.8-turbo](/docs/api-reference/speech-t2a-http) | • Seamless speed meets natural flow | • 40 languages supported<br />• 7 emotions supported<br />• specified languages and dialects supported |

<Accordion title="Legacy Models">
  | **Models**             | **Description**           | **Features**                           |
  | :- | :- | :- |
  | [speech-2.6-hd](/docs/api-reference/speech-t2a-http) | • Ultimate Similarity<br />• Ultra-High Quality | • 40 languages supported<br />• 7 emotions supported<br />• specified languages and dialects supported |
  | [speech-2.6-turbo](/docs/api-reference/speech-t2a-http) | • Ultimate Value<br />• Low latency | • 40 languages supported<br />• 7 emotions supported<br />• specified languages and dialects supported |
  | [speech-02-hd](/docs/api-reference/speech-t2a-http) | • Stronger replication similarity<br />• High quality voice generation | • 24 languages supported<br />• 7 emotions supported<br />• specified languages and dialects supported |
  | [speech-02-turbo](/docs/api-reference/speech-t2a-http) | • Superior rhythm and stability<br />• Low latency | • 24 languages supported<br />• 7 emotions supported<br />• specified languages and dialects supported |
</Accordion>

### Music

<Note title="Music API Service Adjustment Notice">
  Starting August 20, 2026, the paid APIs (Music Generation and Lyrics Generation) will no longer be available to new users; existing paying users can continue to use the current API services. The free music generation APIs (Music-3.0-free, Music-2.6-free, music-cover-free) will be discontinued.

  To experience or use music generation capabilities, please visit [MiniMax Audio](https://www.minimax.io/audio), or use the open-source [MiniMax Music 3 model on Hugging Face](https://huggingface.co/MiniMaxAI/MiniMax-Music3).
</Note>

| **Models**             | **Description**           | **Features**                           |
| :- | :- | :- |
| [music-3.0](/docs/api-reference/music-generation) | • New Music Generation Capabilities | • Intent Understood<br />• Sound Elevated<br />• Vocals Humanized |
| [music-2.6](/docs/api-reference/music-generation) | • Cover Reborn. Bass Redefined. | • Cover Reborn. Bass Redefined. |
| [music-cover](/docs/api-reference/music-generation) | • Generate cover versions from reference audio | • One-step cover generation<br />• Two-step cover with lyrics modification<br />• Style transfer<br />• Auto lyrics extraction |

<Accordion title="Legacy Models">
  | **Models**             | **Description**           | **Features**                           |
  | :- | :- | :- |
  | [music-2.0](/docs/api-reference/music-generation) | • Text to Music<br />• Enhanced musicality <br />• Natural vocals and smooth melodies | • Human-like performance<br />• Riche emotional expression<br />• Enhanced tone control<br /> |
</Accordion>
