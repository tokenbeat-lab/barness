package ai

// Message is one entry of the transcript a host passes for a call:
// UserMessage, AssistantMessage (a previous turn's result) or
// ToolResultMessage. The set of message kinds is closed.
type Message interface {
	isMessage()
}

// UserContent is a content block allowed in a UserMessage.
type UserContent interface {
	isUserContent()
}

// AssistantContent is a content block allowed in an AssistantMessage.
type AssistantContent interface {
	isAssistantContent()
}

// Text is a text content block.
type Text struct {
	Text string `json:"text"`
	// Signature is opaque provider state attached to assistant text (for
	// Responses, the output message id as pi's TextSignatureV1 JSON). It is
	// empty on user text.
	Signature string `json:"textSignature,omitempty"`
}

func (Text) isUserContent()      {}
func (Text) isAssistantContent() {}

// Thinking is a reasoning content block of an assistant message.
type Thinking struct {
	Thinking string `json:"thinking"`
	// Signature is opaque provider replay state for the block (for Responses,
	// the reasoning item as pi's JSON.stringify, encrypted content included).
	// It is native state: replayed only to the same model under a trusted
	// envelope (see TrustedNativeState).
	Signature string `json:"thinkingSignature,omitempty"`
	// Redacted marks thinking the provider withheld; its opaque payload is in
	// Signature. Like pi, same-model replay keeps it and any other target
	// drops it, whatever its visible text.
	Redacted bool `json:"redacted,omitempty"`
}

func (Thinking) isAssistantContent() {}

// Image is an image input block, sent to a model that accepts images. Any
// other target gets pi-ai's placeholder text in its place.
type Image struct {
	// Data is the image bytes in standard base64, sent as is.
	Data string `json:"data"`
	// MimeType is the image's media type, such as image/png.
	MimeType string `json:"mimeType"`
}

func (Image) isUserContent()       {}
func (Image) isToolResultContent() {}

// UserMessage is user input.
type UserMessage struct {
	Content []UserContent `json:"content"`
}

func (UserMessage) isMessage() {}

// UserText builds a UserMessage holding one text block.
func UserText(text string) UserMessage {
	return UserMessage{Content: []UserContent{Text{Text: text}}}
}

// StopReason is how a generation turn ended. Values match pi-ai.
type StopReason string

const (
	// StopReasonPending is the stop reason of a message still being produced,
	// as seen through a PartialView. A finished message never carries it.
	StopReasonPending StopReason = "pending"
	StopReasonStop    StopReason = "stop"
	StopReasonLength  StopReason = "length"
	// StopReasonToolUse: the turn completed normally and holds tool calls the
	// host may validate and execute (see ValidateToolCall).
	StopReasonToolUse StopReason = "toolUse"
	StopReasonError   StopReason = "error"
	StopReasonAborted StopReason = "aborted"
)

// AssistantMessage is the final (or partial) result of one generation turn.
// Failed calls still produce one, carrying StopReason error/aborted and
// ErrorMessage.
type AssistantMessage struct {
	Content []AssistantContent `json:"content"`
	// API, Provider and Model identify what actually served the call; they are
	// empty when the call failed before the binding and model were resolved.
	API        API        `json:"api"`
	Provider   ProviderID `json:"provider"`
	Model      string     `json:"model"`
	ResponseID string     `json:"responseId,omitempty"`
	// ResponseModel is the model the provider reports having served the call
	// when it differs from Model (Anthropic Messages, as pi-ai records it).
	ResponseModel string `json:"responseModel,omitempty"`
	// ProviderThinkingLevel is the provider-native effort the call ran at,
	// recorded as pi-ai does for a model whose effort may change between
	// turns (Anthropic: Model.Compat.SupportsMidConvoEffort, the effort
	// option or high). Replaying the message tells that provider which
	// effort produced it. It is not native state: a host-supplied value
	// only describes the host's own turn, and a value that is not one of
	// the provider's efforts is ignored (ADR-0019). Empty for every other
	// model.
	ProviderThinkingLevel string     `json:"providerThinkingLevel,omitempty"`
	Usage                 Usage      `json:"usage"`
	StopReason            StopReason `json:"stopReason"`
	// RawStopReason is the provider's own terminal status as pi-ai reports
	// it (Responses: response.status, plus ".<reason>" for an incomplete
	// response with a reason). Empty when no terminal status was received.
	RawStopReason string `json:"rawStopReason,omitempty"`
	ErrorMessage  string `json:"errorMessage,omitempty"`
	// Timestamp is when the call started producing this message, in Unix
	// milliseconds as in pi-ai. Every message of a call — terminal event,
	// Result, failures included — carries the same value.
	Timestamp int64 `json:"timestamp"`
	// DurationMs is the non-negative, rounded monotonic time from call start
	// to settlement, including setup and retries (pi-ai 1.1.0). Pending views
	// are untimed. It is an elapsed measurement, not provider inference time.
	DurationMs Nullable[int64] `json:"durationMs,omitzero"`
	// NativeState vouches for the provenance of the message's native state.
	// barness-ai sets it on every message of a call that resolved its
	// binding; a message decoded from storage has the zero, untrusted value
	// until the host calls TrustNativeState. It is never serialized.
	NativeState TrustedNativeState `json:"-"`
}

// An AssistantMessage is also history: a previous turn's Result.Message
// replayed in a later call.
func (AssistantMessage) isMessage() {}

// clone copies the message so the copy shares no mutable storage with m.
// Content blocks are immutable values; a block type holding references (a
// slice or map) must be deep-copied here.
func (m AssistantMessage) clone() AssistantMessage {
	m.Content = append([]AssistantContent(nil), m.Content...)
	return m
}
