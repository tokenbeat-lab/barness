from pathlib import Path
from collections import Counter, defaultdict
from decimal import Decimal
import base64
import datetime
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/Users/cyber/RestoX/barness')
COLLECTION = ROOT / '.evidence/minimax-global-candidate-complete'
OUT = Path('/tmp/barness-minimax-global-candidate-capsule')
SOURCE = '760533299b71736998e15cdd027a53ae069aff9e'
STEM = 'international-candidates-7605332'
checks = Counter()
items = {}
locations = {}
historical_source = defaultdict(dict)
git_cache = {}


def check(condition, category, detail):
    if not condition:
        raise RuntimeError(category + ': ' + detail)
    checks[category] += 1


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def js(raw):
    return json.loads(raw)


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()


def add_bytes(name, raw, location):
    check(name not in items, 'archive selection', name)
    check(not name.startswith('/') and '..' not in Path(name).parts,
          'safe archive path', name)
    items[name] = raw
    locations[name] = location


def add_file(name, path):
    check(path.is_file() and not path.is_symlink(), 'regular source file', str(path))
    add_bytes(name, path.read_bytes(), str(path))


def git_bytes(commit, name):
    check(name != '.env' and '/.env' not in name, 'no credential source', name)
    key = (commit, name)
    if key not in git_cache:
        git_cache[key] = subprocess.check_output(['git', 'show', commit + ':' + name], cwd=ROOT)
    return git_cache[key]


def capture(name, base, intent, archive_prefix, candidate=False):
    check(intent['launcherAudit'] == {'passed': True, 'findings': []},
          'launcher audit', name)
    report_raw = (base / 'minimax-report.json').read_bytes()
    report = js(report_raw)
    seal_raw = (base / 'minimax-integrity.json').read_bytes()
    seal = js(seal_raw)
    files = {p.relative_to(base).as_posix(): p for p in base.rglob('*') if p.is_file()}
    check(set(files) == set(seal['files']) | {'minimax-integrity.json'},
          'complete sealed capture', name)
    for path, pin in seal['files'].items():
        check(sha(files[path].read_bytes()) == pin, 'sealed file hash', name + '/' + path)
    check(sha(report_raw) == intent['reportedFileSha256'], 'intent report binding', name)
    check(report['gitCommit'] == intent['sourceCommit'], 'capture source binding', name)
    check(js((base / 'audit.json').read_bytes()) == {'findings': []}, 'capture audit', name)
    manifest = js((base / 'manifest.json').read_bytes())
    check(manifest['git_commit'] == report['gitCommit'], 'manifest source binding', name)
    for case in manifest['cases']:
        for kind in ('artifacts', 'fixtures'):
            for path, pin in case.get(kind, {}).items():
                p = base / case['dir'] / path
                check(p.is_file() and sha(p.read_bytes()) == pin,
                      'manifest artifact hash', name + '/' + case['dir'] + '/' + path)
    for path, p in sorted(files.items()):
        add_file(archive_prefix + '/' + path, p)
    for path, pin in report['executionSource'].items():
        raw = git_bytes(report['gitCommit'], path)
        check(sha(raw) == pin, 'committed execution source', report['gitCommit'] + ':' + path)
        if report['gitCommit'] != SOURCE:
            historical_source[report['gitCommit']][path] = raw
        elif 'source/' + SOURCE + '/' + path not in items:
            add_bytes('source/' + SOURCE + '/' + path, raw, 'git:' + SOURCE + ':' + path)
    sources = js((base / 'minimax-sources.json').read_bytes())
    source_manifest_raw = base64.b64decode(sources['sources.json'], validate=True)
    check(sha(source_manifest_raw) == report['sourceHash'], 'official manifest pin', name)
    for src in js(source_manifest_raw):
        raw = base64.b64decode(sources[src['file']], validate=True)
        check(sha(raw) == src['sha256'], 'official source hash', name + '/' + src['file'])
    summary = {
        'job': name, 'archiveDirectory': archive_prefix,
        'session': report['session'], 'sourceCommit': report['gitCommit'],
        'identity': report['identity'], 'outcome': report['outcome'],
        'complete': report['complete'], 'budget': report['budget'],
        'cumulativeSlotBudget': report.get('cumulativeSlotBudget'),
        'reportSha256': sha(report_raw), 'sealSha256': sha(seal_raw),
        'files': len(files), 'bytes': sum(p.stat().st_size for p in files.values()),
        'launcherAudit': intent['launcherAudit'],
    }
    if not candidate:
        check(report['kind'] == 'minimax-research-only' and report['complete'] is False,
              'historical research scope', name)
        return report, summary
    check(report['kind'] == 'minimax-candidate-only' and report['stage'] == 'candidate'
          and report['mode'] == 'live' and report['outcome'] == 'PASS'
          and report['complete'] is True and report['auditPassed'] is True,
          'complete candidate outcome', name)
    check(report['gitCommit'] == SOURCE, 'candidate exact source', name)
    check(len(report['expected']) == len(report['calls']) == len(manifest['cases']) == 13,
          'thirteen case inventory', name)
    check([x['id'] for x in report['expected']] == [x['id'] for x in report['calls']],
          'exact case inventory', name)
    check(report['budget']['calls'] == report['budget']['reservedAttempts'] == 13
          and report['budget']['attempts'] == 12, 'candidate consumption', name)
    known_usage, unknown_usage = 0, 0
    usage_reporting = Counter()
    known_cost = Decimal('0')
    known_tokens = Counter()
    cases = []
    for call in report['calls']:
        case = base / call['caseId']
        check(call['outcome'] == 'PASS' and call['rerun'] == 0, 'own case outcome', name + '/' + call['id'])
        assertions = js((case / 'assertions.json').read_bytes())
        check(assertions['status'] == 'PASS' and all(x['pass'] for x in assertions['assertions']),
              'own case assertions', name + '/' + call['id'])
        observations = js((case / 'observations.json').read_bytes())
        events = Counter(x['kind'] for x in observations)
        check(events['call_started'] == events['call_finished'] == 1,
              'logical call settles', name + '/' + call['id'])
        exchanges = js((case / 'exchanges.json').read_bytes())
        metrics = js((case / 'metrics.json').read_bytes())
        check(metrics['activeBodies'] == 0 and metrics['observer']['failed'] == 0
              and metrics['observer']['dropped'] == 0, 'resources settle', name + '/' + call['id'])
        result = js((case / 'result.json').read_bytes())
        attempts = len(call.get('attemptReceipts') or [])
        check(events['attempt_started'] == events['attempt_finished'] == attempts == len(exchanges),
              'attempt observer accounting', name + '/' + call['id'])
        finished = [x['attempt'] for x in observations if x['kind'] == 'attempt_finished']
        if finished:
            usage_reporting[finished[0]['usageReporting']] += 1
        for ex in exchanges:
            check(ex['status'] == 200, 'actual HTTP status', name + '/' + call['id'])
            suffix = {'chat': '/chat/completions', 'responses': '/responses', 'messages': '/v1/messages'}[report['identity']['route']]
            expected_url = report['identity']['endpoint'] + suffix
            check(ex['url'].split('?', 1)[0] == expected_url, 'actual global endpoint', name + '/' + call['id'])
            for key, value in ex.get('requestHeaders', {}).items():
                if key.lower() in ('authorization', 'x-api-key', 'api-key'):
                    check(value == '[REDACTED]', 'credential header redaction', name + '/' + call['id'])
        if call['id'] == 'preflight-error':
            check(attempts == 0 and result['errorCode'] == 'invalid_request',
                  'preflight no HTTP attempt', name)
        else:
            check(attempts == 1 and call['rawModels'] == ['MiniMax-M3'],
                  'actual model and one attempt', name + '/' + call['id'])
            check(finished[0]['httpStatus'] == 200, 'observer HTTP status', name + '/' + call['id'])
            if call['id'] == 'cancel':
                check(finished[0]['usageReporting'] in ('unreported', 'partial')
                      and result['errorCode'] == 'canceled', 'cancellation unknown consumption', name)
                unknown_usage += 1
            else:
                check(finished[0]['usageReporting'] in ('complete', 'partial') and
                      finished[0]['usage']['totalTokens'] > 0,
                      'known usage presence', name + '/' + call['id'])
                known_usage += 1
                usage = finished[0]['usage']
                known_cost += Decimal(str(usage['cost']['total']))
                for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'reasoning', 'totalTokens'):
                    known_tokens[key] += usage.get(key, 0)
        cases.append({'id': call['id'], 'caseId': call['caseId'], 'outcome': 'PASS', 'attempts': attempts,
                      'actualModels': call.get('rawModels') or [],
                      'usageReporting': finished[0]['usageReporting'] if finished else 'no-attempt',
                      'rawUsageObjects': sum(x is not None for x in call.get('usagePresence') or [])})
    check(known_usage == 11 and unknown_usage == 1, 'known versus unknown usage count', name)
    summary.update({'cases': cases, 'knownUsageAttempts': known_usage,
                    'unknownFinalConsumptionAttempts': unknown_usage,
                    'observerUsageReportingCounts': dict(usage_reporting),
                    'knownUsageTokens': dict(known_tokens),
                    'knownUsageUSD': str(known_cost), 'knownCostIsNotInvoice': True,
                    'nativeContinuation': 'PASS'})
    return report, summary


# All selected-key audits are checked before reading any raw request/response.
intents = {}
for name in ['mm-global-candidate-m3-' + x for x in ('chat', 'responses', 'messages')] + [
        'mm-research-m3-chat', 'mm-global-research-m3-chat',
        'mm-global-research-m3-responses', 'mm-global-research-m3-messages']:
    path = ROOT / '.evidence/minimax-launches' / (name + '.json')
    value = js(path.read_bytes())
    check(value['launcherAudit'] == {'passed': True, 'findings': []}, 'pre-read launcher audit', name)
    intents[name] = value
    add_file('launches/' + path.name, path)

source_manifest = js((COLLECTION / 'source-at-start.json').read_bytes())
check(source_manifest['sourceCommit'] == SOURCE and len(source_manifest['files']) == 1026,
      'generation source inventory', SOURCE)
for name, pin in source_manifest['files'].items():
    raw = git_bytes(SOURCE, name)
    check(sha(raw) == pin, 'generation source hash', name)
    add_bytes('source/' + SOURCE + '/' + name, raw, 'git:' + SOURCE + ':' + name)

for p in sorted(COLLECTION.iterdir()):
    if p.is_file() and p.name not in ('live.test', 'chineseeval', 'visualeval'):
        check(p.suffix in ('.json', '.log'), 'selected collection metadata', p.name)
        add_file('collection/' + p.name, p)

review = js((COLLECTION / 'prerelease-source-review.json').read_bytes())
check(review['decision'] == 'APPROVED' and review['sourceCommit'] == SOURCE,
      'exact prerelease approval', SOURCE)
for key, name in [('sourceManifestSHA256', 'source-at-start.json'),
                  ('binariesManifestSHA256', 'binaries.json'), ('planSHA256', 'plan.json')]:
    check(review[key] == sha((COLLECTION / name).read_bytes()), 'approval artifact binding', name)
for name, pin in review['reviewReferences'].items():
    raw = git_bytes(SOURCE, name)
    check(sha(raw) == pin, 'review source binding', name)
    add_bytes('reviews/' + name, raw, 'git:' + SOURCE + ':' + name)
prepared = js((COLLECTION / 'prepared.json').read_bytes())
check(prepared['planSHA256'] == sha((COLLECTION / 'plan.json').read_bytes()), 'prepared plan binding', SOURCE)
for name, pin in prepared['authorizationFiles'].items():
    check(sha((COLLECTION / name).read_bytes()) == pin, 'prepared authorization binding', name)
check(js((COLLECTION / 'checks.json').read_bytes()) == {
    'passed': True, 'commands': {'vet': 0, 'vet-live': 0, 'no-key-live': 0}, 'credentialsRead': False},
    'keyless collection checks', SOURCE)

external_binaries = {}
for name, pin in js((COLLECTION / 'binaries.json').read_bytes()).items():
    path = COLLECTION / name
    check(sha(path.read_bytes()) == pin, 'original retained binary hash', name)
    external_binaries[name] = {'path': str(path), 'sha256': pin, 'bytes': path.stat().st_size,
                               'archived': False, 'retention': 'original prepared collection'}

candidates = []
reports = {}
for route in ('chat', 'responses', 'messages'):
    name = 'mm-global-candidate-m3-' + route
    intent = intents[name]
    check(intent['state'] == 'COMPLETED' and intent['exitCode'] == 0, 'candidate launcher outcome', name)
    origin = intent['origin']
    base = COLLECTION / name / origin['session']
    report, summary = capture(name, base, intent, 'candidates/' + name + '/' + origin['session'], True)
    reports[route] = report
    for key, filename in [('reportSha256', 'minimax-report.json'), ('sealSha256', 'minimax-integrity.json'),
                          ('ledgerSha256', 'minimax-ledger.json')]:
        check(origin[key] == sha((base / filename).read_bytes()), 'canonical origin file binding', name + '/' + filename)
    for key, filename in [('sourceManifestSha256', 'source-at-start.json'),
                          ('binariesManifestSha256', 'binaries.json'), ('planSha256', 'plan.json')]:
        check(origin[key] == sha((COLLECTION / filename).read_bytes()), 'canonical origin source binding', name + '/' + filename)
    command = js((COLLECTION / (name + '-origin-command.json')).read_bytes())
    check(command['exitCode'] == 0 and command['credentialsRead'] is False,
          'prior public verify receipt', name)
    check((COLLECTION / (name + '-intent.json')).read_bytes() ==
          (ROOT / '.evidence/minimax-launches' / (name + '.json')).read_bytes(),
          'canonical and collection intent bytes', name)
    candidates.append(summary)

historical = []
research_files = {}
for name, intent in intents.items():
    if 'candidate-m3-' in name:
        continue
    session = intent['researchCapture']['session']
    base = ROOT / '.evidence/minimax-research-captures' / name / session
    report, summary = capture(name, base, intent, 'predecessors/' + name + '/' + session)
    check(sha((base / 'minimax-integrity.json').read_bytes()) == intent['researchCapture']['sealSha256'],
          'historical seal intent binding', name)
    historical.append(summary)
    research_files[session] = {p.relative_to(base).as_posix(): p.read_bytes()
                               for p in base.rglob('*') if p.is_file()}
for commit, files in sorted(historical_source.items()):
    for name, raw in sorted(files.items()):
        add_bytes('historical-source/' + commit + '/' + name, raw, 'git:' + commit + ':' + name)

ledger_path = ROOT / '.evidence/minimax-stages/candidate.jsonl'
ledger_raw = ledger_path.read_bytes()
receipts = [js(x) for x in ledger_raw.splitlines()]
check(len(receipts) == 94, 'candidate stage immutable snapshot', '94 receipts')
previous = ''
totals = Counter()
slots = defaultdict(Counter)
for i, receipt in enumerate(receipts, 1):
    empty_hash = dict(receipt)
    empty_hash['hash'] = ''
    check(receipt['sequence'] == i and receipt['previous'] == previous
          and sha(compact(empty_hash)) == receipt['hash'], 'canonical receipt hash chain', str(i))
    previous = receipt['hash']
    kind = receipt['kind']
    check(kind in ('reserve', 'attempt') and receipt['stage'] == 'candidate', 'canonical receipt kind', str(i))
    slot = '/'.join(receipt['identity'][x] for x in ('route', 'model', 'purpose'))
    totals[kind] += 1
    slots[slot][kind] += 1
    if kind == 'reserve':
        slots[slot]['requestedOutput'] += receipt['output']
        slots[slot]['reservedInput'] += receipt['input']
check(totals == {'reserve': 49, 'attempt': 45}, 'historical inclusive stage totals', str(totals))
check(sha(b''.join(ledger_raw.splitlines(keepends=True)[:4])) ==
      '222c68c07ce06819b6c84f6aa739b0a08824f1b70893bae7accd014bcae2b4f8',
      'immutable old CN ledger prefix', 'first4 receipts')
check(sha((ROOT / '.evidence/minimax-launches/mm-research-m3-chat.json').read_bytes()) ==
      'cfac130565e33b804d22eb2bd7feb58e66d8d6baa12e2094edc4cdcf9f6dfff0',
      'immutable old CN intent', 'accounting-only')
for slot, b in slots.items():
    check(b['reserve'] <= 20 and b['attempt'] <= 24 and b['requestedOutput'] <= 40000
          and b['reservedInput'] <= 120000, 'cumulative budget slot caps', slot)
for route, report in reports.items():
    name = 'mm-global-candidate-m3-' + route
    base = COLLECTION / name / report['session']
    ledger = js((base / 'minimax-ledger.json').read_bytes())
    check(ledger['receipts'] == receipts[:len(ledger['receipts'])], 'canonical ledger prefix equality', name)
    own = [x for x in ledger['receipts'] if x['session'] == report['session']]
    expected = [x for call in report['calls'] for x in
                [call['reservation']] + (call.get('attemptReceipts') or [])]
    check(own == expected and len(own) == 25, 'report exact own receipts', name)
    for session, files in ledger['predecessors'].items():
        check(session in research_files, 'canonical predecessor exists', session)
        check(set(files) == set(research_files[session]), 'complete predecessor embedded set', session)
        for path, encoded in files.items():
            check(base64.b64decode(encoded, validate=True) == research_files[session][path],
                  'unchanged embedded predecessor bytes', name + '/' + session + '/' + path)
add_bytes('accounting/candidate.jsonl', ledger_raw, str(ledger_path))

promotion = js((COLLECTION / 'promotion.json').read_bytes())
check(promotion['kind'] == 'verified-candidates-for-catalog-activation', 'promotion receipt kind', SOURCE)
proposal_catalog = (json.dumps(promotion['catalog'], ensure_ascii=False, indent=2) + '\n').encode()
check(sha(proposal_catalog) == promotion['catalogSha256'], 'promotion catalog hash', SOURCE)
for entry in promotion['candidates']:
    report = reports[entry['route']]
    summary = next(x for x in candidates if x['identity']['route'] == entry['route'])
    check(entry['reportSha256'] == summary['reportSha256'] and
          entry['sealSha256'] == summary['sealSha256'] and entry['gitCommit'] == SOURCE,
          'promotion candidate binding', entry['route'])

archive = OUT / (STEM + '.tar.gz')
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, raw in sorted(items.items()):
                info = tarfile.TarInfo(name)
                info.size = len(raw)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    check(len(members) == len(items) and {x.name for x in members} == set(items),
          'archive roundtrip complete set', archive.name)
    for member in members:
        check(member.isfile() and tar.extractfile(member).read() == items[member.name],
              'archive roundtrip exact bytes', member.name)

created = datetime.datetime.now(datetime.timezone.utc).isoformat()
index = {
    'schema': 1, 'kind': 'actual-international-complete-candidates-not-formal',
    'createdAt': created, 'sourceCommit': SOURCE,
    'archive': archive.name, 'archiveSha256': sha(archive.read_bytes()),
    'archiveBytes': archive.stat().st_size,
    'files': {name: {'sha256': sha(raw), 'bytes': len(raw), 'original': locations[name]}
              for name, raw in sorted(items.items())},
    'generationSourceFileCount': 1026, 'historicalExecutionSourceCounts': {
        commit: len(files) for commit, files in sorted(historical_source.items())},
    'candidates': candidates, 'historicalResearch': historical,
    'stageBudgetSnapshot': {'calls': 49, 'reservedAttempts': 49, 'attempts': 45,
                            'maxCalls': 120, 'maxAttempts': 144, 'receipts': 94,
                            'ledgerSha256': sha(ledger_raw), 'finalReceiptHash': previous},
    'slotBudgetSnapshot': {name: dict(b) for name, b in sorted(slots.items())},
    'externalBinaries': external_binaries,
    'checks': dict(sorted(checks.items())), 'totalChecks': sum(checks.values()),
    'credentialsReadByCurator': False, 'networkUsedByCurator': False,
    'testsRunByCurator': False, 'rootFilesModifiedByCurator': False,
    'scope': 'Exact complete candidate capture bytes and source proof; historical failures and accounting remain unchanged. This capsule does not certify formal support or final release regression.',
}
index_path = OUT / (STEM + '.json')
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
lines = [
    '# International M3 complete candidate capsule audit', '',
    'PASS: keyless, read-only integrity curation of source `' + SOURCE + '`.', '',
    f"All {sum(checks.values())} integrity checks passed; {len(items)} exact archive files; "
    f"archive {archive.stat().st_size:,} bytes. Archive roundtrip verified every file byte. "
    'The archive includes all 1026 committed generation-source files, the exact sealed captures, '
    'source/binary/plan/approval/check/command/origin receipts, all four historical research captures, '
    'and the immutable candidate ledger snapshot. Executable binaries remain in the original '
    'prepared collection with SHA-256 and size recorded in the index.', '',
    '| Route | Base endpoint | Cases | Calls / actual attempts | Known usage / unknown final consumption | Known USD |',
    '| --- | --- | --- | --- | --- | --- |',
]
for x in candidates:
    lines.append(f"| {x['identity']['route']} | `{x['identity']['endpoint']}` | 13 PASS | 13 / 12 | 11 / 1 | {Decimal(x['knownUsageUSD']):.8f} |")
lines += ['',
    'Every actual request returned HTTP 200 and reported actual model `MiniMax-M3`; each route '
    'passed persisted trusted native tool-result continuation. The preflight case failed locally '
    'with zero HTTP attempts as required. Cancellation after visible output has unknown final consumption: '
    'Chat and Responses label it unreported; Messages labels the initial zero usage frame partial. '
    'Those zero DTO fields do not establish a zero bill. The index preserves every exact Observer label '
    '(Chat: 11 complete / 1 unreported; Responses: 3 complete / 8 partial / 1 unreported; '
    'Messages: 12 partial). The table rounds the known USD sum to eight decimal places; '
    'the JSON index keeps the exact sum of captured numeric values. '
    'Known usage is not an invoice. '
    'Cache-repeat checks retain observed usage without promising a cache hit. All bodies and '
    'Observers settled; selected-key launcher audits and capture audits have no findings.', '',
    'The cumulative candidate snapshot is 49 / 120 Logical Calls, 45 / 144 actual Attempts, '
    '49 reservations, and 94 linked receipts. This retains historical CN 2 calls / 2 attempts and '
    'international research 8 calls / 7 attempts. Slot totals are Chat 17 calls / 16 attempts, '
    'Responses 16 / 14, and Messages 16 / 15; all per-slot output and input caps hold. '
    'The original four CN receipts and old launch intent match their previously committed hashes. '
    'Historical Chat and Responses research failures remain FAIL; Messages research remains '
    'incomplete research PASS. They were neither relabelled nor treated as current candidate proof.', '',
    'The captured source and 1026 generation pins were checked against Git source 7605332, '
    'not the later catalog-activation working tree. All report execution-source pins, official '
    'source snapshots, source-review references, sealed file and manifest hashes, canonical origin '
    'bindings, exact own receipts, embedded predecessor bytes, and canonical ledger prefixes match. '
    'Prior launcher public-verification and keyless promotion receipts are retained; this curator '
    'did not rerun verification, read `.env`, execute tests, call a vendor, or modify the repository.', '',
    f"Archive SHA-256: `{index['archiveSha256']}`. Full portable file and source inventory: `{index_path.name}`. "
    f"Repeatable keyless verification: `python3 verify_capsule.py {index_path.name}`.", '',
    'Scope: complete international M3 standard candidates and data-only activation provenance. '
    'Formal reports, old-route renewal, business effects, and the final release gate are separate evidence.',
]
audit_path = OUT / (STEM + '-audit.md')
audit_path.write_text('\n'.join(lines) + '\n')
provenance = {'schema': 1, 'createdAt': created, 'curator': '/root/candidate_capsule',
              'sourceCommit': SOURCE, 'originalCollection': str(COLLECTION),
              'generator': {'path': str(Path(__file__)), 'sha256': sha(Path(__file__).read_bytes())},
              'outputs': {p.name: {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
                          for p in (archive, index_path, audit_path, OUT / 'verify_capsule.py')},
              'readOnlyIntegrityAudit': True, 'credentialsRead': False,
              'networkUsed': False, 'testsRun': False, 'repositoryModified': False}
prov_path = OUT / (STEM + '-provenance.json')
prov_path.write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(items), 'checks': sum(checks.values()),
                  'outputs': {p.name: {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
                              for p in (archive, index_path, audit_path, prov_path)}}, indent=2))
