> ## Documentation Index
> Fetch the complete documentation index at: https://platform.minimax.io/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# Prerequisites

> Before using the MiniMax API, you need to complete account registration and obtain an API Key.

<Steps>
  <Step title="Register or Login">
    Access MiniMax API Platform, [register](https://platform.minimax.io/login?source=platform_docs)  or [login](https://platform.minimax.io/login?source=platform_docs) .
  </Step>

  <Step title="Get a Key">
    * **Pay-as-you-go**：Visit [API Keys > Create new secret key](https://platform.minimax.io/user-center/basic-information/interface-key) to get your **API Key**
      <Note>Pay-as-you-go supports all modality models, including language, Video, Speech, and Image.</Note>
    * **M Plan**：Visit [Billing > M Plan](https://platform.minimax.io/user-center/payment/token-plan) to view your **Subscription Key**
      <Note>The Subscription Key is used for M Plan subscriptions and purchased Credits. It can exist before paid resources are available, and becomes usable when you have an M Plan seat or Credits access. See [M Plan Overview](https://platform.minimax.io/docs/m-plan/intro) for details.</Note>

    After generating an API Key, we recommend you export it as an environment variable in terminal or save it to a `.env` file:

    * Compatible Anthropic API (Recommended), see: [Anthropic SDK](/docs/api-reference/text-anthropic-api)

      ```bash theme={null}
      export ANTHROPIC_BASE_URL=https://api.minimax.io/anthropic
      export ANTHROPIC_API_KEY=${YOUR_API_KEY}
      ```

    * Compatible OpenAI API, see: [OpenAI SDK](/docs/api-reference/text-openai-api)

      ```bash theme={null}
      export OPENAI_BASE_URL=https://api.minimax.io/v1
      export OPENAI_API_KEY=${YOUR_API_KEY}
      ```

    * Compatible AI SDK, see: [AI SDK](/docs/api-reference/text-ai-sdk)

      ```bash theme={null}
      export MINIMAX_API_KEY=${YOUR_API_KEY}
      ```
  </Step>

  <Step title="Add resources">
    For pay-as-you-go, access [Billing/Balance](https://platform.minimax.io/user-center/payment/balance) to top up if needed. For M Plan, buy a subscription or Credits, or use resources assigned by your Team.
  </Step>
</Steps>
