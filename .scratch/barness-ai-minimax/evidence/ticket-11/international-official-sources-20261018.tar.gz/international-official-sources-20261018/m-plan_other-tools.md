> ## Documentation Index
> Fetch the complete documentation index at: https://platform.minimax.io/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# Other Tools

> Use the latest MiniMax M-series models in other AI tools.

If your tool has no dedicated guide but accepts a custom Base URL and API Key, use the values below.

## Configuration Reference

MiniMax exposes two protocols. Pick whichever your tool supports — most modern tools support at least one.

### OpenAI-Compatible Protocol

| Field | Value |
| - | - |
| **Provider** | `OpenAI Compatible` (sometimes called `Custom` or `OpenAI-format`) |
| **Base URL** | `https://api.minimax.io/v1` |
| **API Key** | [Get Subscription Key](https://platform.minimax.io/console/plan) |
| **Model ID** | `MiniMax-M3.1-Flash-Preview` |

### Anthropic-Compatible Protocol

| Field | Value |
| - | - |
| **Provider** | `Anthropic Compatible` (sometimes called `Claude` or `Custom Anthropic`) |
| **Base URL** | `https://api.minimax.io/anthropic` |
| **API Key** | [Get Subscription Key](https://platform.minimax.io/console/plan) |
| **Model ID** | `MiniMax-M3.1-Flash-Preview` |

## Protocol Selection

| Tool style | Recommended protocol | Typical env vars |
| - | - | - |
| Claude Code-style (TUI / CLI written for Anthropic) | Anthropic-Compatible | `ANTHROPIC_BASE_URL` + `ANTHROPIC_AUTH_TOKEN` |
| Cursor / Continue / Aider / OpenAI-format IDE plugins | OpenAI-Compatible | `OPENAI_BASE_URL` + `OPENAI_API_KEY` |
| Tools that ask for both | Either works — Anthropic-Compatible is recommended for prompt-cache benefits | |

## Dify

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Dify**](https://github.com/langgenius/dify) is an open-source LLM application development platform with workflows, RAG, agents, and observability.</div>

<Steps>
  <Step title="Install the plugin">
    Open [Dify Cloud](https://cloud.dify.ai), sign in, and go to **Settings → Workspace → Model Provider**. Find **Minimax** and click **Install**.
  </Step>

  <Step title="Configure API Key">
    Click **Add API Key**, enter your [Subscription Key](https://platform.minimax.io/console/plan), set **API Base** to `https://api.minimax.io/anthropic`, and leave **Group ID** blank.
  </Step>

  <Step title="Start using the model">
    Save the settings to use MiniMax-M3.1-Flash-Preview in your workflows.
  </Step>
</Steps>

## Oh My Pi

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Oh My Pi**](https://github.com/can1357/oh-my-pi) is an open-source terminal coding agent built on Pi, with integrated LSP, code editing, and subagents.</div>

<Tabs sync={false}>
  <Tab title="Option 1: One-click setup wizard">
    Run:

    ```bash theme={null}
    npx -y mmx-cli@latest agent setup
    ```

    Select **Oh my Pi (omp)**. If it is missing, keep Oh my Pi selected in the second multi-select. The wizard runs the official installer, checks `omp --version`, and adds MiniMax models to Oh My Pi's models and defaults.

    Then launch Oh My Pi directly:

    ```bash theme={null}
    omp
    ```
  </Tab>

  <Tab title="Option 2: Manual setup">
    <Steps>
      <Step title="Install Oh My Pi">
        Follow the [official Oh My Pi installation instructions](https://github.com/can1357/oh-my-pi#install), then run `omp --version` to verify the installation.
      </Step>

      <Step title="Configure MiniMax models">
        Edit or create `~/.omp/agent/models.yml` (`user directory\.omp\agent\models.yml` on Windows), replacing `<MINIMAX_API_KEY>` with your [Subscription Key](https://platform.minimax.io/console/plan). If the file already contains other providers, merge `minimax` into the existing `providers` mapping.

        ```yaml theme={null}
        providers:
          minimax:
            baseUrl: https://api.minimax.io/anthropic
            apiKey: "<MINIMAX_API_KEY>"
            api: anthropic-messages
            auth: apiKey
            models:
              - id: MiniMax-M3.1-Flash-Preview
                name: MiniMax-M3.1-Flash-Preview
                reasoning: true
                input: [text, image]
                contextWindow: 524288
                maxTokens: 128000
                thinking:
                  mode: anthropic-adaptive
                  efforts: [low, medium, high, xhigh, max]
                  defaultLevel: max
                  requiresEffort: true
        ```

        This example uses the Anthropic-compatible protocol and sets the client context window to **512K (524288 tokens)**. See the [512K configuration guidance](/docs/m-plan/codex#context-window-512k). Thinking is always enabled for MiniMax-M3.1-Flash-Preview and cannot be disabled.
      </Step>

      <Step title="Verify and launch">
        Run the following commands to confirm that `MiniMax-M3.1-Flash-Preview` appears in the model list, then launch it:

        ```bash theme={null}
        omp models minimax
        omp --model minimax/MiniMax-M3.1-Flash-Preview:max
        ```

        To save it as the default, enter `/model` in a session and assign the model to the `default` role. For more options, see the [Oh My Pi model configuration docs](https://github.com/can1357/oh-my-pi/blob/main/docs/models.md).
      </Step>
    </Steps>
  </Tab>
</Tabs>

## Cherry Studio

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Cherry Studio**](https://github.com/CherryHQ/cherry-studio) is an open-source desktop client supporting 50+ LLM providers, with built-in MCP servers and 300+ assistants.</div>

<Steps>
  <Step title="Install">
    Install Cherry Studio per the [official docs](https://docs.cherryai.com.cn/docs/en-us/cherry-studio/installation).
  </Step>

  <Step title="Add MiniMax provider">
    Open Cherry Studio → click **Choose other Providers** → search `MiniMax`, then pick **MiniMax**.
  </Step>

  <Step title="Enter API Key">
    Enter your [Subscription Key](https://platform.minimax.io/console/plan) (the API Host is prefilled), then click **Check** to verify.
  </Step>

  <Step title="Pick the model">
    Select `MiniMax-M3.1-Flash-Preview` from the model list.
  </Step>
</Steps>

## Chatbox

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Chatbox**](https://github.com/chatboxai/chatbox) is a free, open-source, cross-platform AI client supporting advanced LLMs, custom API keys (BYOK), and AI agents across desktop, mobile, and web.</div>

<Steps>
  <Step title="Install Chatbox">
    Install Chatbox per the [official docs](https://chatboxai.app/en/guide).
  </Step>

  <Step title="Add MiniMax provider">
    Open Chatbox → click **Settings** → click **Model Provider** → click **Add** → search `MiniMax`, then pick **MiniMax Global**.
  </Step>

  <Step title="Enter API Key">
    Enter your [Subscription Key](https://platform.minimax.io/console/plan) (the API Host is prefilled), then click **Check** next to **API Key** to verify the connection.
  </Step>

  <Step title="Pick the model">
    Select `MiniMax-M3.1-Flash-Preview` from the model list.
  </Step>
</Steps>

## Xcode

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Xcode**](https://developer.apple.com/xcode/) is Apple's official IDE for macOS, iOS, iPadOS, watchOS, and visionOS, now with built-in Coding Intelligence.</div>

<Steps>
  <Step title="Install Xcode">
    Install Xcode 26 or later from the [Mac App Store](https://apps.apple.com/us/app/xcode/id497799835).
  </Step>

  <Step title="Add a Model Provider">
    Open Xcode → top menu **Xcode → Settings → Intelligence → Add a Model Provider**, choose the **Internet Hosted** tab, and fill in:

    * **URL**: `https://api.minimax.io` (bare host, no path)
    * **API Key Header**: `Authorization` (override the default `x-api-key`)
    * **API Key**: `Bearer <your Subscription Key>` (the word `Bearer`, **a single space**, then your `sk-cp-…` key — [get one here](https://platform.minimax.io/console/plan))
    * **Description**: `MiniMax` (any value)

    <img src="https://file.cdn.minimax.io/public/xcode-provider-filled-en.png" alt="Xcode Add a Model Provider dialog" style={{borderRadius: '8px', marginTop: '12px', maxWidth: '100%'}} />
  </Step>

  <Step title="Enable the model">
    Click **Add**. Back in the Intelligence pane, open the new MiniMax provider and enable `MiniMax-M3.1-Flash-Preview`.
  </Step>

  <Step title="Start chatting">
    Open any project, press **⌘+0** to bring up the Coding Assistant, click the edit icon at the top-left to pick `MiniMax-M3.1-Flash-Preview`.
  </Step>
</Steps>

## Kilo Code

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Kilo Code**](https://github.com/Kilo-Org/kilocode) is an open-source AI coding agent for VS Code, supporting multiple LLM providers and MCP servers.</div>

<Warning>First clear the `ANTHROPIC_AUTH_TOKEN` and `ANTHROPIC_BASE_URL` env vars — otherwise they will override the configuration.</Warning>

<Steps>
  <Step title="Install the extension">
    Search `Kilo Code` in the VS Code Extensions panel and install.
  </Step>

  <Step title="Configure MiniMax provider">
    Open Kilo Code → **Settings**:

    * **API Provider** = `MiniMax`
    * **MiniMax Entrypoint** = `api.minimax.io`
    * **MiniMax API Key** = your [Subscription Key](https://platform.minimax.io/console/plan)
    * **Model** = `MiniMax-M3.1-Flash-Preview`

    Click **Save** then **Done**.
  </Step>
</Steps>

## Zed

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Zed**](https://github.com/zed-industries/zed) is an open-source, high-performance multiplayer code editor written in Rust by the Atom creators.</div>

<Steps>
  <Step title="Install Zed">
    Install Zed per the [official docs](https://zed.dev/docs/getting-started).
  </Step>

  <Step title="Add LLM Provider">
    Settings → **LLM Provider** → **+Add Provider** → choose **OpenAI**, fill:

    * **API URL** = `https://api.minimax.io/v1`
    * **API Key** = from [M Plan](https://platform.minimax.io/console/plan)
    * **Model Name** = `MiniMax-M3.1-Flash-Preview`
  </Step>

  <Step title="Re-confirm API Key">
    Click **Save Provider**. Then back in the LLM Provider list, click the new MiniMax entry, **re-enter the API Key and press Enter** to confirm.
  </Step>

  <Step title="Pick the model">
    Return to the agent panel, click **Select a Model** at the bottom-right and pick `MiniMax-M3.1-Flash-Preview`.
  </Step>
</Steps>

## Grok CLI

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Grok CLI**](https://github.com/superagent-ai/grok-cli) is an open-source terminal coding agent that connects to xAI's Grok and OpenAI-compatible providers.</div>

<Note>Not recommended for Agent workflows — use **Claude Code** or **Cursor** for best results.</Note>

<Warning>First clear the `OPENAI_API_KEY` and `OPENAI_BASE_URL` env vars.</Warning>

<Tabs sync={false}>
  <Tab title="Option 1: One-click setup wizard">
    Run:

    ```bash theme={null}
    npx -y mmx-cli@latest agent setup
    ```

    Select **Grok CLI**. If it is missing, keep Grok CLI selected in the second multi-select. The wizard runs the official Grok Build installer, checks `grok --version`, preserves unrelated settings, and adds a MiniMax model to `~/.grok/config.toml`.

    Run `grok` when setup finishes.
  </Tab>

  <Tab title="Option 2: Manual setup">
    <Steps>
      <Step title="Install Grok CLI">
        ```bash theme={null}
        npm install -g grok-dev
        ```
      </Step>

      <Step title="Set env vars and launch">
        ```bash theme={null}
        export GROK_BASE_URL=https://api.minimax.io/v1
        export GROK_API_KEY=sk-cp-...   # from M Plan
        grok --model MiniMax-M3.1-Flash-Preview
        ```
      </Step>
    </Steps>
  </Tab>
</Tabs>

## Droid

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Droid**](https://factory.ai) is Factory's official terminal coding agent that integrates with IDEs and developer collaboration tools.</div>

<Warning>First clear the `ANTHROPIC_AUTH_TOKEN` env var, otherwise it overrides the API Key in the settings file.</Warning>

<Steps>
  <Step title="Install Droid">
    ```bash theme={null}
    curl -fsSL https://app.factory.ai/cli | sh        # macOS / Linux
    # Windows:  irm https://app.factory.ai/cli/windows | iex
    ```
  </Step>

  <Step title="Edit config file">
    Add the following to `customModels` in `~/.factory/settings.json`:

    ```json theme={null}
    {
      "customModels": [{
        "displayName": "MiniMax-M3.1-Flash-Preview",
        "model": "MiniMax-M3.1-Flash-Preview",
        "baseUrl": "https://api.minimax.io/anthropic",
        "apiKey": "<MINIMAX_API_KEY>",
        "provider": "anthropic",
        "maxOutputTokens": 64000
      }]
    }
    ```
  </Step>

  <Step title="Launch and pick model">
    Launch `droid`, then `/model` and pick `MiniMax-M3.1-Flash-Preview`.
  </Step>
</Steps>

## Qwen Code

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Qwen Code**](https://github.com/QwenLM/qwen-code) is Alibaba's open-source terminal coding agent optimized for the Qwen model family.</div>

<Steps>
  <Step title="Install Qwen Code">
    Linux / macOS:

    ```bash theme={null}
    bash -c "$(curl -fsSL https://qwen-code-assets.oss-cn-hangzhou.aliyuncs.com/installation/install-qwen.sh)"
    ```

    Windows (works in both Command Prompt and PowerShell):

    ```powershell theme={null}
    powershell -Command "Invoke-WebRequest 'https://qwen-code-assets.oss-cn-hangzhou.aliyuncs.com/installation/install-qwen.bat' -OutFile (Join-Path $env:TEMP 'install-qwen.bat'); & (Join-Path $env:TEMP 'install-qwen.bat')"
    ```
  </Step>

  <Step title="Launch and pick provider">
    Run `qwen` in your terminal. Pick **Third-party Providers** → **MiniMax API Key** → region **International**.
  </Step>

  <Step title="Enter API Key">
    Enter your API Key from [M Plan](https://platform.minimax.io/console/plan) (prefix `sk-cp-…`) and press Enter.
  </Step>

  <Step title="Confirm model IDs">
    The default model ID should be `MiniMax-M3.1-Flash-Preview` — press Enter to submit and start chatting.
  </Step>
</Steps>

## Open WebUI

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**Open WebUI**](https://github.com/open-webui/open-webui) is a self-hosted, open-source AI chat platform with offline support, RAG, and multi-model runners.</div>

<Steps>
  <Step title="Install Open WebUI">
    Install via Python pip (requires **Python 3.11** to avoid compatibility issues):

    ```bash theme={null}
    pip install open-webui
    open-webui serve
    ```
  </Step>

  <Step title="Create admin account">
    Open [http://localhost:8080](http://localhost:8080) in your browser and follow the prompt to create a local admin account.
  </Step>

  <Step title="Add OpenAI Connection">
    Click the avatar (top-right) → **Admin Panel** → top **Settings** tab → left **Connections**. In the **OpenAI** row, click **➕ Add Connection**, fill:

    * **URL**: `https://api.minimax.io/v1`
    * **Auth** (Bearer mode): your API Key from [M Plan](https://platform.minimax.io/console/plan) (prefix `sk-cp-…`)
  </Step>

  <Step title="Pick the model">
    Click **Save** and back in the chat view, pick `MiniMax-M3.1-Flash-Preview` from the top model selector to start chatting.
  </Step>
</Steps>

## nanobot

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**nanobot**](https://github.com/HKUDS/nanobot) is an ultra-lightweight open-source personal AI agent CLI from HKUDS, with chat channels, memory, and MCP support.</div>

<Steps>
  <Step title="Install nanobot">
    ```bash theme={null}
    uv tool install nanobot-ai
    # or:  pipx install nanobot-ai
    # or:  pip install nanobot-ai          # may need --user or --break-system-packages on macOS
    ```
  </Step>

  <Step title="Initialize">
    ```bash theme={null}
    nanobot onboard
    ```
  </Step>

  <Step title="Configure MiniMax in one shot">
    Replace `sk-cp-...` with your [Subscription Key](https://platform.minimax.io/console/plan):

    ```bash theme={null}
    python3 -c '
    import json, os, sys
    p = os.path.expanduser("~/.nanobot/config.json")
    c = json.load(open(p))
    c["providers"]["minimax"]["apiKey"] = sys.argv[1]
    c["providers"]["minimax"]["apiBase"] = "https://api.minimax.io/v1"
    c["agents"]["defaults"]["provider"] = "minimax"
    c["agents"]["defaults"]["model"] = "MiniMax-M3.1-Flash-Preview"
    json.dump(c, open(p, "w"), indent=2)
    ' sk-cp-...
    ```
  </Step>

  <Step title="Launch">
    ```bash theme={null}
    nanobot agent
    ```
  </Step>
</Steps>

## OpenHands

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**OpenHands**](https://github.com/All-Hands-AI/OpenHands) (formerly OpenDevin) is an open-source AI software-development agent by All-Hands-AI, with TUI, web GUI, and IDE integrations.</div>

<Steps>
  <Step title="Install OpenHands">
    ```bash theme={null}
    pipx install openhands
    ```
  </Step>

  <Step title="Configure MiniMax in one shot">
    Replace `sk-cp-...` with your [Subscription Key](https://platform.minimax.io/console/plan):

    ```bash theme={null}
    pipx run --spec openhands python -c '
    import sys
    from openhands_cli.stores.agent_store import AgentStore
    AgentStore().create_and_save_from_settings(
        llm_api_key=sys.argv[1],
        settings={"llm_model": "openai/MiniMax-M3.1-Flash-Preview",
                  "llm_base_url": "https://api.minimax.io/v1"},
    )
    ' sk-cp-...
    ```
  </Step>

  <Step title="Launch">
    ```bash theme={null}
    openhands
    ```
  </Step>
</Steps>

## LangChain

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**LangChain**](https://github.com/langchain-ai/langchain) is the open-source framework by LangChain Inc. for building LLM-powered applications, with model adapters, retrieval, agents, and tracing.</div>

<Steps>
  <Step title="Install">
    ```bash theme={null}
    pip install langchain-openai
    ```
  </Step>

  <Step title="Use MiniMax via the OpenAI-compatible adapter">
    Replace `sk-cp-...` with your [Subscription Key](https://platform.minimax.io/console/plan):

    ```python theme={null}
    from langchain_openai import ChatOpenAI

    llm = ChatOpenAI(
        model="MiniMax-M3.1-Flash-Preview",
        api_key="sk-cp-...",
        base_url="https://api.minimax.io/v1",
    )
    print(llm.invoke("Hello").content)
    ```
  </Step>
</Steps>

<h2 id="trae">
  TRAE
</h2>

<div style={{background:"#fffbeb",borderLeft:"4px solid #d97706",padding:"12px 16px",borderRadius:"6px",margin:"16px 0"}}>[**TRAE**](https://www.trae.ai) is ByteDance's AI-native IDE with intelligent collaboration and agent automation.</div>

**Install and Launch TRAE**

<Steps>
  <Step title="Download and Install TRAE">
    Go to [TRAE's website](https://www.trae.ai/?utm_source=content\&utm_medium=doc_minimax\&utm_campaign=minimax) to install TRAE
  </Step>

  <Step title="Complete Initial Setup">
    Click TRAE's icon to launch it. The following screen appears at TRAE's first launch

    ![](https://filecdn.minimax.chat/public/ace1b07e-9296-43f1-87ff-e423795716fb.png)
  </Step>

  <Step title="Start Setup">
    Click the Get Started button, TRAE's setup begins

    For detailed installation steps, please refer to: [Trae Setup Guide](https://docs.trae.ai/ide/set-up-trae?_lang=en)
  </Step>
</Steps>

**Configure MiniMax API**

<Warning>
  **Important: Clear OpenAI Environment Variables Before Configuration**

  Before configuring, ensure you clear the following OpenAI-related environment variables to avoid conflicts with MiniMax API:

  * `OPENAI_API_KEY`
  * `OPENAI_BASE_URL`
</Warning>

In TRAE, connect to MiniMax-M3.1-Flash-Preview with your M Plan [Subscription Key](https://platform.minimax.io/console/plan).

<Steps>
  <Step title="Open Settings">
    At the top right of the side chat box, click Settings icon > Models
  </Step>

  <Step title="Select Models Tab">
    Switch to the **Models** tab.
  </Step>

  <Step title="Add Model">
    Click the + Add Model button. The Add Model pop-up appears

    Enter Configuration Details:

    * Provider: Select **MiniMax-Global**
    * Model: Select **MiniMax-M3.1-Flash-Preview**
    * API Key: Input your **[Subscription Key](https://platform.minimax.io/console/plan)**
  </Step>

  <Step title="Complete Adding">
    Click the **Add Model** button
  </Step>
</Steps>
