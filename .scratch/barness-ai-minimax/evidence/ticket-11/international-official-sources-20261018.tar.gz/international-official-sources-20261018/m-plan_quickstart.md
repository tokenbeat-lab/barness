> ## Documentation Index
> Fetch the complete documentation index at: https://platform.minimax.io/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# Subscribe to M Plan

> Subscribe to M Plan, get your Subscription Key, and test an API call.

## 1. Subscribe to M Plan

Go to [Plan Details](https://platform.minimax.io/console/plan), choose a tier, and complete payment.

<Tip>
  If you only use M Plan in MiniMax Code, sign in to MiniMax Code after completing step 1. You do not need to configure a Subscription Key.
</Tip>

## 2. Get your Subscription Key

After subscribing, find your Subscription Key in [Plan Details](https://platform.minimax.io/console/plan). You need this Key to use M Plan in AI tools such as Claude Code and Cursor.

Note:

* Your Subscription Key only uses your M Plan usage and is not interchangeable with a pay-as-you-go API Key.
* Keep your Subscription Key secure. Do not share it with others or commit it to a code repository. Use an environment variable or configuration file to store it.

## 3. Test an API call (optional)

For example, use the Anthropic SDK to quickly test MiniMax-M3.1-Flash-Preview.

**Install the SDK**

<CodeGroup>
  ```bash Python theme={null}
  pip install anthropic
  ```

  ```bash Node.js theme={null}
  npm install @anthropic-ai/sdk
  ```
</CodeGroup>

**Configure environment variables**

Replace `${YOUR_API_KEY}` with your Subscription Key:

```bash theme={null}
export ANTHROPIC_BASE_URL=https://api.minimax.io/anthropic
export ANTHROPIC_API_KEY=${YOUR_API_KEY}
```

**Call the API**

```python Python theme={null}
import anthropic

client = anthropic.Anthropic()

message = client.messages.create(
    model="MiniMax-M3.1-Flash-Preview",
    output_config={"effort": "max"},
    max_tokens=4096,
    system="You are a helpful assistant.",
    messages=[
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": "Hi, how are you?"
                }
            ]
        }
    ]
)

for block in message.content:
    if block.type == "thinking":
        print(f"Thinking:\n{block.thinking}\n")
    elif block.type == "text":
        print(f"Text:\n{block.text}\n")
```
