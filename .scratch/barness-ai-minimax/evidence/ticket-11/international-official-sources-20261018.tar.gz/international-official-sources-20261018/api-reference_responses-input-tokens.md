> ## Documentation Index
> Fetch the complete documentation index at: https://platform.minimax.io/docs/llms.txt
> Use this file to discover all available pages before exploring further.

# Estimate Input Tokens

> Estimate the input token count of a request without invoking the model. Useful for evaluating request cost or checking context length limits before calling the main endpoint.



## OpenAPI

````yaml api-reference/text/api/openapi-responses.json POST /v1/responses/input_tokens
openapi: 3.1.0
info:
  title: MiniMax Responses API
  description: >-
    MiniMax OpenAI Responses API compatible endpoints, supporting chat
    generation and token estimation
  license:
    name: MIT
  version: 1.0.0
servers:
  - url: https://api.minimax.io
security:
  - bearerAuth: []
paths:
  /v1/responses/input_tokens:
    post:
      tags:
        - Responses
      summary: Estimate Input Tokens
      operationId: estimateInputTokens
      parameters:
        - name: Content-Type
          in: header
          required: true
          description: Media type of the request body. Must be set to `application/json`
          schema:
            type: string
            enum:
              - application/json
            default: application/json
      requestBody:
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/EstimateInputTokensReq'
            examples:
              Request:
                value:
                  model: MiniMax-M3.1-Flash-Preview
                  input:
                    - type: message
                      role: user
                      content: >-
                        Please implement a generic quicksort algorithm in Python
                        with these requirements: 1) in-place sorting to save
                        memory; 2) three-way partitioning to handle duplicate
                        elements; 3) switch to insertion sort for small
                        subarrays; 4) include complete unit tests. Finally,
                        explain the advantage of three-way partitioning over the
                        classic Lomuto scheme when keys repeat.
                  tools:
                    - type: function
                      name: search_docs
                      description: >-
                        Search the official documentation of the Python standard
                        library or a third-party package
                      parameters:
                        type: object
                        properties:
                          library:
                            type: string
                            description: Library name, e.g. `typing`, `itertools`
                          query:
                            type: string
                            description: Search keywords
                        required:
                          - library
                          - query
                    - type: function
                      name: run_python
                      description: >-
                        Execute Python code in a sandbox and return stdout /
                        error
                      parameters:
                        type: object
                        properties:
                          code:
                            type: string
                            description: Python code to execute
                          timeout_seconds:
                            type: integer
                            description: Execution timeout in seconds
                            default: 10
                        required:
                          - code
        required: true
      responses:
        '200':
          description: Successful response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/EstimateInputTokensResp'
              examples:
                Response:
                  value:
                    object: response.input_tokens
                    input_tokens: 588
components:
  schemas:
    EstimateInputTokensReq:
      type: object
      required:
        - model
        - input
      properties:
        model:
          type: string
          description: Model name to invoke, e.g. `MiniMax-M3.1-Flash-Preview`
          example: MiniMax-M3.1-Flash-Preview
        input:
          description: >-
            Conversation content. Supports either a simple text or a full
            conversation history array
          oneOf:
            - type: string
              description: Simple text input
            - type: array
              description: Full conversation history
              items:
                $ref: '#/components/schemas/InputItem'
        instructions:
          type: string
          description: System instructions
        tools:
          type: array
          description: Tool list
          items:
            $ref: '#/components/schemas/Tool'
        tool_choice:
          type: string
          enum:
            - none
            - auto
          description: >-
            Tool selection strategy: `none` means no tool will be called; `auto`
            lets the model decide whether to call tools
        text:
          type: object
          description: Output format control
          properties:
            format:
              type: object
              properties:
                type:
                  type: string
                  enum:
                    - text
                  default: text
                  description: Output format type
        reasoning:
          type: object
          description: >-
            Reasoning control. The default depends on the model, so no
            schema-level default is declared.

            - `MiniMax-M3.1-Flash-Preview`: reasoning is always on, including
            when `reasoning` is omitted. `effort` accepts `low`, `medium`,
            `high`, `xhigh` or `max`, and does tune reasoning depth. When
            omitted, it defaults to `max`. `effort: "none"` returns HTTP 400.

            - `MiniMax-M3`: reasoning is off unless `effort` is set to a
            non-`none` value, which turns reasoning on but does not tune its
            depth.

            - M2.x models: reasoning cannot be disabled; `effort: "none"` is
            accepted but ignored.
          properties:
            effort:
              type: string
              enum:
                - minimal
                - low
                - medium
                - high
                - xhigh
                - max
                - none
          required: []
    EstimateInputTokensResp:
      type: object
      required:
        - object
        - input_tokens
      properties:
        object:
          type: string
          enum:
            - response.input_tokens
          description: Object type, always `response.input_tokens`
        input_tokens:
          type: integer
          description: Estimated input token count
    InputItem:
      type: object
      description: >-
        Conversation history item. The `type` field determines the shape:
        `message` (default) / `function_call` / `function_call_output` /
        `reasoning`
      properties:
        type:
          type: string
          enum:
            - message
            - function_call
            - function_call_output
            - reasoning
          default: message
          description: Item type
        role:
          type: string
          enum:
            - user
            - assistant
            - system
            - developer
            - tool
          description: Message role (only when `type` is `message`)
        content:
          description: >-
            Message content; string or multimodal parts array (only when `type`
            is `message`)
          oneOf:
            - type: string
            - type: array
              items:
                $ref: '#/components/schemas/ContentPart'
        call_id:
          type: string
          description: >-
            Tool call ID (only when `type` is `function_call` or
            `function_call_output`)
        name:
          type: string
          description: Function name (only when `type` is `function_call`)
        arguments:
          type: string
          description: >-
            Function arguments as a JSON string (only when `type` is
            `function_call`)
        output:
          description: Tool return result (only when `type` is `function_call_output`)
          oneOf:
            - type: string
            - type: array
              items:
                $ref: '#/components/schemas/ContentPart'
        summary:
          type: array
          description: Reasoning segment array (only when `type` is `reasoning`)
          items:
            type: object
            properties:
              type:
                type: string
                enum:
                  - summary_text
              text:
                type: string
                description: Reasoning text
    Tool:
      type: object
      required:
        - type
        - name
      properties:
        type:
          type: string
          enum:
            - function
          description: Tool type
        name:
          type: string
          description: Function name
        description:
          type: string
          description: Function description, helps the model decide when to call it
        parameters:
          type: object
          description: Function parameter definition in JSON Schema format
    ContentPart:
      type: object
      required:
        - type
      description: Message content part
      properties:
        type:
          type: string
          enum:
            - input_text
            - output_text
            - input_image
            - input_video
          description: |-
            Content part type:
            - `input_text` / `output_text`: Text part
            - `input_image`: Image input
            - `input_video`: Video input
        text:
          type: string
          description: Text content (when `type` is `input_text` / `output_text`)
        image_url:
          description: >-
            Image input (when `type` is `input_image`). Supported formats: JPEG,
            PNG, GIF, WEBP
          oneOf:
            - type: string
            - type: object
              required:
                - url
              properties:
                url:
                  type: string
                  description: Image URL or Base64 encoding
                detail:
                  type: string
                  enum:
                    - low
                    - default
                    - high
                  default: default
                  description: Image understanding precision tier
        video_url:
          description: >-
            Video input (when `type` is `input_video`). Supported formats: MP4,
            AVI, MOV, MKV
          oneOf:
            - type: string
            - type: object
              required:
                - url
              properties:
                url:
                  type: string
                  description: >-
                    Video URL or Base64 encoding. Use the File API to upload
                    large files
                fps:
                  type: number
                  format: float
                  default: 1
                  minimum: 0.2
                  maximum: 5
                  description: Frame extraction rate
                detail:
                  type: string
                  enum:
                    - low
                    - default
                    - high
                  default: default
                  description: Video understanding precision tier
                max_long_side_pixel:
                  type: integer
                  description: Pixel constraint on the longest side of video frames
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
      description: |-
        `HTTP: Bearer Auth`
         - Security Scheme Type: http
         - HTTP Authorization Scheme: Bearer API_key, used to authenticate your account. View it in [Account Management > API Keys](https://platform.minimax.io/user-center/basic-information/interface-key)

````