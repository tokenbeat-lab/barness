"""Add committed source bytes to an externally retained failed keyless window."""
from pathlib import Path, PurePosixPath
import datetime
import gzip
import io
import json
import subprocess
import tarfile
from verify_q import SOURCE, ARCHIVE_SHA, sha, digest, verify_raw, verify_source

ROOT = Path('/Users/cyber/RestoX/barness')
OUT = Path('/tmp/barness-minimax-root-preflight-failure-capsule')
WORKER = Path('/tmp/barness-minimax-10-global/.scratch/barness-ai-minimax/evidence/ticket-12')
NAME = 'glm-corrective-q-9dc-audit-failure'
RAW = ROOT / '.evidence/minimax-retained' / (NAME + '.tar.gz')
RAW_INDEX = WORKER / (NAME + '.json')
RAW_INVENTORY = WORKER / (NAME + '-files.json.gz')
STEM = 'q-9dc-committed-source-proof'
audit, selected, original_index = verify_raw(RAW, RAW_INDEX, RAW_INVENTORY)
source_raw = selected['original-Q/source-at-start.json']
source = json.loads(source_raw)
paths = list(source['files'])
for path in paths:
    if path.startswith('/') or '..' in PurePosixPath(path).parts or '\n' in path or path == '.env':
        raise ValueError('unsafe source manifest path')
queries = ''.join(SOURCE + ':' + path + '\n' for path in paths).encode()
batch = subprocess.run(['git', 'cat-file', '--batch'], cwd=ROOT, input=queries,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout
items = {}
offset = 0
source_total = 0
for path in paths:
    end = batch.index(b'\n', offset)
    header = batch[offset:end].split()
    if len(header) != 3 or header[1] != b'blob':
        raise ValueError('committed source blob unavailable')
    size = int(header[2])
    if size > 8 << 20:
        raise ValueError('source file exceeds bound')
    raw = batch[end + 1:end + 1 + size]
    offset = end + 2 + size
    source_total += size
    if sha(raw) != source['files'][path] or source_total > 32 << 20:
        raise ValueError('committed source pin mismatch')
    items['source/' + path] = raw
if offset != len(batch):
    raise ValueError('unexpected committed source batch output')
items['source-at-start.json'] = source_raw
items['preflight-checks.json'] = selected['original-Q/checks.json']
items['source-review.template.json'] = selected['original-Q/prerelease-source-review.template.json']
items['human-approval.template.json'] = selected['original-Q/human-approval.template.json']
items['original-retention-index.json'] = RAW_INDEX.read_bytes()
items['independent-raw-audit.json'] = (json.dumps(audit, ensure_ascii=False, indent=2) + '\n').encode()
review = json.loads(items['source-review.template.json'])
human = json.loads(items['human-approval.template.json'])
prepared = json.loads(selected['original-Q/prepared.json'])
for value in (review, human):
    if (value['decision'] != 'PENDING' or value['sourceCommit'] != SOURCE
            or value['sourceManifestSHA256'] != sha(source_raw)
            or value['binariesManifestSHA256'] != sha(selected['original-Q/binaries.json'])
            or value['planSHA256'] != sha(selected['original-Q/plan.json'])):
        raise ValueError('original pending approval bindings differ')
if prepared['planSHA256'] != sha(selected['original-Q/plan.json']) or prepared['credentialsRead'] is not False:
    raise ValueError('original prepared plan binding differs')
plan = json.loads(selected['original-Q/plan.json'])
canonical_names = list(plan['routes'])
if any((ROOT / '.evidence/minimax-launches' / (name + '.json')).exists() for name in canonical_names):
    raise ValueError('unexpected current canonical corrective intent')
source_equivalence = json.loads(selected['original-Q/parent-source-equivalence.json'])
archive = OUT / (STEM + '.tar.gz')
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, raw in sorted(items.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                tar.addfile(info, io.BytesIO(raw))
created = datetime.datetime.now(datetime.timezone.utc).isoformat()
index = {'schema': 1, 'kind': 'committed-source-byte-proof-for-failed-keyless-preflight',
         'createdAt': created, 'sourceCommit': SOURCE, 'sourceFiles': 1033,
         'sourceExpandedBytes': source_total,
         'archive': archive.name, 'archiveBytes': archive.stat().st_size,
         'archiveSha256': digest(archive),
         'files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(items.items())},
         'originalRawArchive': {'file': RAW.name, 'commonRetention': original_index['commonRetention'],
                                'bytes': RAW.stat().st_size, 'sha256': ARCHIVE_SHA,
                                'duplicateCreated': False},
         'originalRawIndex': {'file': RAW_INDEX.name, 'sha256': digest(RAW_INDEX)},
         'originalRawInventory': {'file': RAW_INVENTORY.name, 'sha256': digest(RAW_INVENTORY)},
         'originalSourceEquivalence': {'sha256': sha(selected['original-Q/parent-source-equivalence.json']),
                                       'reviewedCodeCheckpoint': source_equivalence['reviewedCodeCheckpoint'],
                                       'generationFiles': source_equivalence['generationFiles']},
         'originalFailure': audit,
         'currentCorrectiveCanonicalIntentsAbsent': canonical_names,
         'canonicalAbsenceObservedAt': created,
         'sourceApproval': False, 'paidExecutionAuthorized': False,
         'credentialsRead': False, 'networkUsed': False, 'testsRun': False, 'rootModified': False,
         'sensitiveRawFailureFiles': 'Unchanged in original common-root ignored archive only; this proof contains committed source bytes and safe derived metadata.'}
index_path = OUT / (STEM + '.json')
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
portable = verify_source(index_path)
summary = {'integrity': 'PASS', 'sourceCommit': SOURCE, 'sourceFiles': 1033,
           'originalRawAuditChecks': audit['checks'], **portable,
           'sourceMatchesOriginal1033PinsAndGitBlobs': True,
           'originalPreflight': 'FAIL', 'sourceApproval': False, 'paidExecutionAuthorized': False,
           'sourceProofArchiveSha256': index['archiveSha256']}
(OUT / 'verification-result.json').write_text(json.dumps(summary, indent=2) + '\n')
text = f'''# Original 9dc failed preflight: independent retention audit

Integrity PASS. The original no-key preflight remains FAIL; this is no source approval or paid authorization.

The existing common-root raw archive is unchanged: 53,271,279 bytes, SHA-256 `{ARCHIVE_SHA}`. Independent streaming verified all 27,417 regular files, one intentional negative symlink, and all 15,261 main-manifest artifact references ({audit['checks']:,} bounded checks). No duplicate raw archive was created. Expanded inventory is 253,350,201 bytes, including 141 bytes of symlink target text; the symlink was never followed or extracted. Deliberately corrupt nested fixtures remain negative test inputs.

Original outcomes stay 335 PASS / 62 NOT_RUN / 0 case FAIL. Both vets exited 0. The full no-key Go command exited 1 with exactly two environment audit findings in `GLM-corrective-1-capture-large/assertions.json` and `new-capture-replay-exit.json`. Their raw diagnostics remain unchanged in the ignored raw archive. Neither diagnostic is copied into this safe source proof.

Both original source-review and human-approval templates remain PENDING, with exact source, binary-manifest and plan bindings. The original checks receipt remains false. No approved receipt exists in that captured top-level collection; the three corrective canonical intents were absent when this audit ran. No vendor was called and no credential was read by this audit.

The separate `{archive.name}` contains all 1,033 committed source-file bytes from Git `{SOURCE}`, checked against the exact original `source-at-start.json`, plus safe failed-check/PENDING metadata. All source archive bytes passed portable verification. It pins the existing raw archive, original index and compressed full inventory as external boundaries; it does not replace or relabel them. Executable `live.test` remains inside the original raw archive, with its original hash and size in that inventory.

Repeatable verification: run `verify_q.py` with `--source-index {index_path.name}`, `--raw-archive` pointing to the existing common-root archive, and `--raw-index` / `--raw-inventory` pointing to the original worker index files. The verifier uses only Python's standard library, streams bounded entries, never follows the negative symlink, and never executes captured commands.

Source-proof archive SHA-256: `{index['archiveSha256']}`. Repository files, Git state, raw artifacts and outcomes were not modified. Later reviewed or paid collections are outside this historical failed-window claim.
'''
audit_path = OUT / 'audit.md'
audit_path.write_text(text)
provenance = {'schema': 1, 'createdAt': created, 'sourceCommit': SOURCE,
              'curator': '/root/candidate_capsule',
              'inputs': {'originalIndexSHA256': digest(RAW_INDEX),
                         'originalFullInventorySHA256': digest(RAW_INVENTORY),
                         'originalRawArchiveSHA256': ARCHIVE_SHA},
              'scripts': {name: {'sha256': digest(OUT / name), 'bytes': (OUT / name).stat().st_size}
                          for name in ('retain_source.py', 'verify_q.py')},
              'outputs': {path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                          for path in (archive, index_path, audit_path, OUT / 'verification-result.json')},
              'originalPreflight': 'FAIL', 'sourceApproval': False, 'paidExecutionAuthorized': False,
              'credentialsRead': False, 'networkUsed': False, 'testsRun': False, 'rootModified': False}
provenance_path = OUT / 'provenance.json'
provenance_path.write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'sourceFiles': 1033, 'sourceBytes': source_total,
                  'originalRawAuditChecks': audit['checks'], 'originalPreflight': 'FAIL',
                  'outputs': {path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                              for path in (archive, index_path, audit_path, OUT / 'verification-result.json', provenance_path)}}, indent=2))
