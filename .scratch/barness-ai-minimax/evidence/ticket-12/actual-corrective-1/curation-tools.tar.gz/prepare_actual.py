"""Read only fixed prepay inputs and the already closed corrective Chat capture."""
from pathlib import Path
from collections import Counter
import datetime
import json
import subprocess
from common import State, ROOT, COLLECTION, OUT, SOURCE, sha, load
from glm import curate

s = State()
source = load(COLLECTION / 'source-at-start.json')
s.check(source['sourceCommit'] == SOURCE and len(source['files']) == 1034,
        'corrective source manifest', SOURCE)
paths = list(source['files'])
s.check(all('\n' not in name and not name.startswith('/') and '..' not in Path(name).parts for name in paths),
        'safe committed source paths', SOURCE)
queries = ''.join(SOURCE + ':' + name + '\n' for name in paths).encode()
raw_batch = subprocess.run(['git', 'cat-file', '--batch'], input=queries, cwd=ROOT,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout
offset = 0
for name in paths:
    end = raw_batch.index(b'\n', offset)
    header = raw_batch[offset:end].split()
    s.check(len(header) == 3 and header[1] == b'blob', 'committed source blob', name)
    size = int(header[2])
    s.check(size <= 8 << 20, 'source file size bound', name)
    raw = raw_batch[end + 1:end + 1 + size]
    offset = end + size + 2
    s.git_cache[name] = raw
s.check(offset == len(raw_batch), 'complete committed source batch', SOURCE)
s.source_manifest()
fixed = ('source-at-start.json', 'binaries.json', 'plan.json', 'prepared.json',
         'checks.json', 'parent-source-equivalence.json', 'approval-request.json',
         'user-approval-reply.json', 'prerelease-source-review.json',
         'prerelease-source-review.template.json', 'human-approval.json',
         'human-approval.template.json', 'build-live-command.json', 'build-live.log',
         'vet-command.json', 'vet.log', 'vet-live-command.json', 'vet-live.log',
         'no-key-live-command.json', 'no-key-live.log')
for name in fixed:
    s.file('prepay/' + name, COLLECTION / name)
parent = ROOT / '.evidence/minimax-global-glm-corrective-1-reviewed-parent'
for name in ('prepare-command.json', 'prepare.log', 'check-command.json', 'check.log'):
    s.file('prepay-parent/' + name, parent / name)
review = load(COLLECTION / 'prerelease-source-review.json')
human = load(COLLECTION / 'human-approval.json')
for value in (review, human):
    s.check(value['decision'] == 'APPROVED' and value['sourceCommit'] == SOURCE,
            'exact approved source', SOURCE)
    for key, file in [('sourceManifestSHA256', 'source-at-start.json'),
                       ('binariesManifestSHA256', 'binaries.json'), ('planSHA256', 'plan.json')]:
        s.check(value[key] == sha((COLLECTION / file).read_bytes()), 'approved artifact binding', file)
s.check(human['checksSHA256'] == sha((COLLECTION / 'checks.json').read_bytes()),
        'human approval exact passed checks', SOURCE)
s.check(human['authority'] == 'explicit-user-reply' and human['additionalMaxCalls'] == 72
        and human['additionalMaxAttempts'] == 96 and human['priorCalls'] == human['priorAttempts'] == 66,
        'explicit corrective budget and prior consumption', SOURCE)
reply_sha = sha((COLLECTION / 'user-approval-reply.json').read_bytes())
s.check(human['replyReference'].endswith('sha256:' + reply_sha), 'exact retained user reply', SOURCE)
s.check(load(COLLECTION / 'checks.json') == {'passed': True,
        'commands': {'vet': 0, 'vet-live': 0, 'no-key-live': 0}, 'credentialsRead': False},
        'full keyless prerelease checks', SOURCE)
plan = load(COLLECTION / 'plan.json')
s.check(plan['originalReceipts'] == human['originalReceipts'], 'original lifetime accounting pins', SOURCE)
for name, pin in plan['originalReceipts'].items():
    path = ROOT / '.evidence/minimax-launches' / (name + '.json')
    raw = path.read_bytes()
    receipt = json.loads(raw)
    s.check(sha(raw) == pin['receiptSHA256'] and receipt['sourceCommit'] == pin['sourceCommit']
            and receipt['reportedFileSha256'] == pin['reportSHA256']
            and receipt['budget']['calls'] == pin['calls'] == 22
            and receipt['budget']['attempts'] == pin['attempts'] == 22
            and receipt['budget']['status'] == pin['status'], 'original canonical accounting lineage', name)
    s.add('lineage/original-receipts/' + path.name, raw, '$COMMON/.evidence/minimax-launches/' + path.name)
original_m3 = ROOT / '.evidence/minimax-global-formal-glm'
unchanged_m3 = []
for route in ('chat', 'responses', 'messages'):
    intent = load(ROOT / '.evidence/minimax-launches' / ('mm-global-formal-m3-' + route + '.json'))
    p = original_m3 / ('mm-global-formal-m3-' + route) / intent['origin']['session'] / 'minimax-report.json'
    report = load(p)
    s.check(len(report['executionSource']) == 263, 'M3 retained execution inventory', route)
    for name, pin in report['executionSource'].items():
        s.source(name, pin)
    unchanged_m3.append({'route': route, 'sourceCommit': report['gitCommit'],
                         'reportSHA256': sha(p.read_bytes()), 'executionSourceFiles': 263,
                         'byteEqualAtCorrectiveSource': True})
name = 'glm-corrective-1-chat'
intent_path = ROOT / '.evidence/minimax-launches' / (name + '.json')
intent = load(intent_path)
s.check(intent['state'] == 'COMPLETED' and intent['exitCode'] == 0 and
        intent['launcherAudit'] == {'passed': True, 'findings': []}, 'closed Chat selected-key audit', name)
for key, file in [('humanApprovalSha256', 'human-approval.json'),
                  ('sourceManifestSha256', 'source-at-start.json'),
                  ('binariesManifestSha256', 'binaries.json'), ('planSha256', 'plan.json')]:
    s.check(intent[key] == sha((COLLECTION / file).read_bytes()), 'Chat exact approved collection binding', file)
s.file('launches/' + name + '.json', intent_path)
chat = curate(s, name, intent)
for suffix in ('-intent.json', '-command.json', '.log'):
    s.file('closed-chat-command/' + name + suffix, COLLECTION / (name + suffix))
for name, raw in s.items.items():
    target = OUT / 'stage' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
binaries = {}
for name, pin in load(COLLECTION / 'binaries.json').items():
    path = COLLECTION / name
    s.check(sha(path.read_bytes()) == pin, 'original prepared binary hash', name)
    binaries[name] = {'sha256': pin, 'bytes': path.stat().st_size,
                      'original': '$COMMON/.evidence/minimax-global-glm-corrective-1-reviewed/' + name,
                      'archived': False}
state = {'kind': 'fixed-approved-prepay-and-closed-Chat-preparation',
         'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'sourceCommit': SOURCE, 'generationSourceFiles': 1034,
         'portableSourceFiles': sum(name.startswith('source/') for name in s.items),
         'stagedFiles': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in s.items.items()},
         'chat': chat, 'unchangedM3ExecutionSources': unchanged_m3,
         'externalBinaries': binaries, 'checks': dict(s.checks), 'totalChecks': sum(s.checks.values()),
         'finalCollectionMetadataSnapshotted': False, 'pendingActualRoutesRead': False,
         'credentialsReadByCurator': False, 'networkUsedByCurator': False,
         'testsRunByCurator': False, 'rootModifiedByCurator': False}
(OUT / 'prepared-state.json').write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'generationSourceFiles': 1034,
                  'portableSourceFiles': state['portableSourceFiles'], 'stagedFiles': len(s.items),
                  'checks': sum(s.checks.values()), 'closedChat': chat['outcome'],
                  'finalCollectionMetadataSnapshotted': False, 'pendingActualRoutesRead': False}, indent=2))
