from common import State, ROOT, COLLECTION, OUT, SOURCE, sha, load
from glm_forensic import curate
import json

name = 'glm-corrective-1-responses'
s = State()
intent_path = ROOT / '.evidence/minimax-launches' / (name + '.json')
intent = load(intent_path)
s.check(intent['state'] == 'COMPLETED' and intent['exitCode'] == 1
        and intent['launcherAudit'] == {'passed': True, 'findings': []}, 'closed failed process audit', name)
for key, file in [('humanApprovalSha256', 'human-approval.json'),
                  ('sourceManifestSha256', 'source-at-start.json'),
                  ('binariesManifestSha256', 'binaries.json'), ('planSha256', 'plan.json')]:
    s.check(intent[key] == sha((COLLECTION / file).read_bytes()), 'failed process exact approved binding', file)
s.file('launches/' + name + '.json', intent_path)
report = curate(s, name, intent)
for suffix in ('-intent.json', '-command.json', '.log'):
    s.file('closed-responses-command/' + name + suffix, COLLECTION / (name + suffix))
for name, raw in s.items.items():
    target = OUT / 'stage' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        s.check(target.read_bytes() == raw, 'existing staged source unchanged', name)
    else:
        target.write_bytes(raw)
result = {'kind': 'closed-failed-Responses-forensic-preparation', 'sourceCommit': SOURCE,
          'report': report, 'files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in s.items.items()},
          'checks': sum(s.checks.values()), 'finalCollectionMetadataSnapshotted': False,
          'pendingMessagesRead': False, 'credentialsReadByCurator': False,
          'networkUsedByCurator': False, 'testsRunByCurator': False, 'rootModifiedByCurator': False}
(OUT / 'closed-responses-state.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'integrity': 'PASS', 'qualification': report['outcome'], 'complete': report['complete'],
                  'producerSealPresent': report['producerSealPresent'], 'publishedViewProduced': report['publishedViewProduced'],
                  'canonicalSuccessCapturePins': False, 'checks': sum(s.checks.values()),
                  'finalCollectionMetadataSnapshotted': False, 'pendingMessagesRead': False}, indent=2))
