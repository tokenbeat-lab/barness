from pathlib import Path
from collections import Counter
import hashlib
import json
import subprocess

ROOT = Path('/Users/cyber/RestoX/barness')
COLLECTION = ROOT / '.evidence/minimax-global-glm-corrective-1-reviewed'
OUT = Path('/tmp/barness-minimax-glm-corrective-actual-capsule')
SOURCE = '5bf2c16f2207a127723e4b19bfa0b59d23825cd4'
C_SOURCE = '760533299b71736998e15cdd027a53ae069aff9e'
C_ARCHIVE_SHA = '06fca74279c09495cf817c377311718f66290b63c43103285c26cfd87753ca08'
STEM = 'glm-corrective-actual-5bf2c16'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode()


class State:
    def __init__(self):
        self.items = {}
        self.locations = {}
        self.checks = Counter()
        self.git_cache = {}

    def check(self, ok, category, detail):
        if not ok:
            raise RuntimeError(category + ': ' + detail)
        self.checks[category] += 1

    def add(self, name, raw, location):
        self.check(name not in self.items, 'unique archive selection', name)
        self.check(not name.startswith('/') and '..' not in Path(name).parts,
                   'safe archive path', name)
        self.items[name] = raw
        self.locations[name] = location

    def file(self, name, path):
        self.check(path.is_file() and not path.is_symlink(), 'regular capture file', str(path))
        self.add(name, path.read_bytes(), str(path))

    def git(self, name):
        self.check(name != '.env' and '/.env' not in name, 'no credential source', name)
        if name not in self.git_cache:
            self.git_cache[name] = subprocess.check_output(['git', 'show', SOURCE + ':' + name], cwd=ROOT)
        return self.git_cache[name]

    def source(self, name, pin):
        raw = self.git(name)
        self.check(sha(raw) == pin, 'committed source hash', name)
        archive_name = 'source/' + SOURCE + '/' + name
        if archive_name not in self.items:
            self.add(archive_name, raw, 'git:' + SOURCE + ':' + name)

    def sealed(self, name, base, prefix, seal_name, extras):
        seal = load(base / seal_name)
        files = {p.relative_to(base).as_posix(): p for p in base.rglob('*') if p.is_file()}
        self.check(set(files) == set(seal['files']) | extras, 'complete sealed capture', name)
        for path, pin in seal['files'].items():
            self.check(path in files and sha(files[path].read_bytes()) == pin,
                       'sealed capture hash', name + '/' + path)
        for path, p in sorted(files.items()):
            self.file(prefix + '/' + path, p)
        self.check(load(base / 'audit.json') == {'findings': []}, 'capture audit', name)
        manifest = load(base / 'manifest.json')
        self.check(manifest['git_commit'] == SOURCE, 'manifest source binding', name)
        for case in manifest['cases']:
            for kind in ('artifacts', 'fixtures'):
                for path, pin in case.get(kind, {}).items():
                    p = base / case['dir'] / path
                    self.check(p.is_file() and sha(p.read_bytes()) == pin,
                               'manifest artifact reference', name + '/' + case['dir'] + '/' + path)
        return manifest, len(files), sum(p.stat().st_size for p in files.values())

    def source_manifest(self):
        manifest = load(COLLECTION / 'source-at-start.json')
        self.check(manifest['sourceCommit'] == SOURCE and len(manifest['files']) == 1034,
                   'generation source inventory', SOURCE)
        for name, pin in manifest['files'].items():
            self.source(name, pin)
        return manifest

    def redacted_exchange(self, name, exchange):
        for key, value in exchange.get('requestHeaders', {}).items():
            if key.lower() in ('authorization', 'x-api-key', 'api-key'):
                self.check(value == '[REDACTED]', 'credential header redaction', name)
