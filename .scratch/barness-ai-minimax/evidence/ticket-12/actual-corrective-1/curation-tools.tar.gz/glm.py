from collections import Counter
from decimal import Decimal
from pathlib import Path
import json
from common import COLLECTION, SOURCE, sha, load


def wire_models(body):
    models = set()
    for line in body.splitlines():
        if not line.startswith('data:'):
            continue
        raw = line[5:].strip()
        if raw == '[DONE]':
            continue
        try:
            value = json.loads(raw)
        except json.JSONDecodeError:
            continue
        for obj in (value, value.get('message'), value.get('response')):
            if isinstance(obj, dict) and isinstance(obj.get('model'), str):
                models.add(obj['model'])
    return sorted(models)


def curate(s, name, intent):
    sessions = [p for p in (COLLECTION / name).iterdir() if p.is_dir()]
    s.check(len(sessions) == 1, 'GLM exactly one session', name)
    base = sessions[0]
    prefix = 'glm/' + name + '/' + base.name
    manifest, count, size = s.sealed(name, base, prefix, 'glm-integrity.json',
                                    {'glm-integrity.json', 'live-report.json'})
    r = load(base / 'formal-glm-report.json')
    p = load(base / 'live-report.json')
    pins = intent['capturePins']
    for key, filename in [('formalReportSha256', 'formal-glm-report.json'),
                          ('integritySha256', 'glm-integrity.json'),
                          ('supportReportSha256', 'live-report.json'),
                          ('executionSourceSha256', 'glm-execution-source.json')]:
        s.check(pins[key] == sha((base / filename).read_bytes()), 'GLM canonical capture pin', name + '/' + filename)
    s.check(intent['reportedFileSha256'] == pins['formalReportSha256'], 'GLM canonical own formal report', name)
    s.check(r['kind'] == 'glm-formal' and r['outcome'] == 'PASS' and r['complete'] is True
            and r['auditPassed'] is True and r['mode'] == 'live' and r['gitCommit'] == SOURCE,
            'GLM complete formal outcome', name)
    s.check(r['budget']['callsUsed'] == r['budget']['attemptsReserved'] == r['budget']['httpAttempts'] == 22
            and r['budget']['retries'] == r['budget']['replayAttempts'] == 0
            and r['budget']['maxCalls'] == 24 and r['budget']['maxAttempts'] == 32,
            'GLM fixed process budget', name)
    fixed_plan = load(base / 'GLM11-sources/plan.json')
    s.check((base / 'GLM11-sources/plan.json').read_bytes() ==
            s.git('ai/live/testdata/glm-candidate/plan.json'), 'GLM frozen plan source', name)
    expected = [scene['id'] for scene in fixed_plan['routes'][r['route']]]
    s.check(r['expected'] == expected and [x['id'] for x in r['scenarios']] == expected
            and r['models'] == {'glm-5.2': 'PASS', 'glm-5.3': 'PASS'}
            and len(manifest['cases']) == 23, 'GLM exact22scene inventory and sources', name)
    for path, pin in load(base / 'glm-execution-source.json').items():
        s.source(path, pin)
    s.check(p['gitCommit'] == SOURCE and p['provider'] == 'zhipu' and p['catalogHash'] == r['catalogHash']
            and p['catalogVersion'] == r['catalogVersion'] and p['api'] == r['api']
            and p['endpoint'] == r['endpoint'] and p['expected'] == expected
            and p['budget']['callsUsed'] == p['budget']['httpAttempts'] == 22,
            'GLM published support identity and inventory', name)
    source_base = base / 'GLM11-sources'
    sources_raw = (source_base / 'sources.json').read_bytes()
    sources = json.loads(sources_raw)
    s.check(sha(sources_raw) == r['sourceManifestHash'] == p['glm']['sourceManifestHash'],
            'GLM official source manifest', name)
    for source in sources['sources']:
        s.check(sha((source_base / source['file']).read_bytes()) == source['sha256'],
                'GLM official source pin', name + '/' + source['file'])
    for key, file in [('candidateSHA256', 'candidate.json'), ('planSHA256', 'plan.json')]:
        s.check(sha((source_base / file).read_bytes()) == sources[key], 'GLM official candidate and plan', name + '/' + file)
    reporting = Counter()
    tokens = Counter()
    known_usd = Decimal('0')
    scenes = []
    for scene, published in zip(r['scenarios'], p['scenarios']):
        s.check(scene['outcome'] == 'PASS' and scene['calls'] == scene['httpAttempts'] == 1
                and scene['replayAttempts'] == 0 and published['id'] == scene['id']
                and published['model'] == scene['model'] and published['outcome'] == 'PASS'
                and published['calls'] == published['attempts'] == 1,
                'GLM own scene facts', name + '/' + scene['id'])
        case = base / published['caseId']
        assertions = load(case / 'assertions.json')
        s.check(assertions['status'] == 'PASS' and all(x['pass'] for x in assertions['assertions']),
                'GLM own scene assertions', name + '/' + scene['id'])
        observations = load(case / 'observations-1.json')
        kinds = Counter(x['kind'] for x in observations)
        s.check(kinds['call_started'] == kinds['call_finished'] == kinds['attempt_started'] == kinds['attempt_finished'] == 1,
                'GLM Observer accounting settles', name + '/' + scene['id'])
        finished = [x['attempt'] for x in observations if x['kind'] == 'attempt_finished'][0]
        s.check(finished['httpStatus'] == 200 and scene['usageReporting'] == [finished['usageReporting']],
                'GLM actual HTTP and reporting label', name + '/' + scene['id'])
        exchanges = load(case / 'attempt-1-exchanges.json')
        s.check(len(exchanges) == 1, 'GLM one actual exchange', name + '/' + scene['id'])
        models = set()
        for exchange in exchanges:
            suffix = {'chat': '/chat/completions', 'responses': '/responses', 'messages': '/v1/messages'}[r['route']]
            s.check(exchange['status'] == 200 and exchange['url'].split('?', 1)[0] == r['endpoint'] + suffix,
                    'GLM actual endpoint', name + '/' + scene['id'])
            s.redacted_exchange(name + '/' + scene['id'], exchange)
            models.update(wire_models(exchange['responseBody']))
        s.check(models and all(model.lower() == scene['model'] for model in models),
                'GLM actual wire model', name + '/' + scene['id'])
        reporting[finished['usageReporting']] += 1
        canceled = scene['id'].endswith('/cancel')
        if canceled:
            s.check(finished['usageReporting'] in ('partial', 'unreported'), 'GLM cancellation unknown final usage', name + '/' + scene['id'])
        else:
            s.check(finished['usageReporting'] in ('partial', 'complete') and finished['usage']['totalTokens'] > 0,
                    'GLM known usage', name + '/' + scene['id'])
            for key in ('input', 'output', 'cacheRead', 'cacheWrite', 'reasoning', 'totalTokens'):
                tokens[key] += finished['usage'].get(key, 0)
            known_usd += Decimal(str(finished['usage']['cost']['total']))
        scenes.append({'id': scene['id'], 'model': scene['model'], 'actualModels': sorted(models),
                       'outcome': scene['outcome'], 'attempts': 1,
                       'usageReporting': finished['usageReporting'], 'finalConsumptionUnknown': canceled})
    model_reports = []
    for model in ('glm-5.3', 'glm-5.2'):
        mr = load(base / ('formal-' + model + '-report.json'))
        s.check(mr['kind'] == 'glm-model-formal' and mr['model'] == model and mr['outcome'] == 'PASS'
                and mr['complete'] and mr['auditPassed'] and mr['gitCommit'] == SOURCE
                and mr['calls'] == mr['httpAttempts'] == 11 and mr['replayAttempts'] == 0
                and [x['id'] for x in mr['scenarios']] == [x for x in expected if x.startswith(model + '/')],
                'GLM model-qualified formal report', name + '/' + model)
        model_reports.append({'model': model, 'reportSha256': sha((base / ('formal-' + model + '-report.json')).read_bytes()),
                              'calls': 11, 'attempts': 11, 'reportedKnownUsage': mr['reportedKnownUsage']})
    return {'family': 'glm', 'job': name, 'archiveDirectory': prefix,
            'session': base.name, 'sourceCommit': SOURCE, 'route': r['route'],
            'api': r['api'], 'endpoint': r['endpoint'], 'models': r['models'],
            'outcome': r['outcome'], 'complete': r['complete'], 'files': count, 'bytes': size,
            'reportFile': 'formal-glm-report.json', 'sealFile': 'glm-integrity.json',
            'reportSha256': pins['formalReportSha256'], 'sealSha256': pins['integritySha256'],
            'publishedSupportReportSha256': pins['supportReportSha256'],
            'executionSourceSha256': pins['executionSourceSha256'],
            'catalogHash': r['catalogHash'], 'catalogVersion': r['catalogVersion'],
            'budget': r['budget'], 'scenes': scenes, 'modelReports': model_reports,
            'knownUsageAttempts': 20, 'unknownFinalConsumptionAttempts': 2,
            'observerUsageReportingCounts': dict(reporting), 'knownUsageTokens': dict(tokens),
            'knownUsageEstimatedUSD': str(known_usd), 'knownCostIsNotInvoice': True,
            'accountVerification': r['accountVerification'], 'regionVerification': r['regionVerification'],
            'privilegeVerification': r['privilegeVerification']}
