"""Finalize only after the parent confirms all three selected R1 processes closed."""
from pathlib import Path
import argparse
import datetime
import gzip
import io
import json
import tarfile
from common import State, ROOT, COLLECTION, OUT, SOURCE, STEM, sha, load
from glm import curate as success
from glm_forensic import curate as forensic

parser = argparse.ArgumentParser()
parser.add_argument('--all-three-closed', action='store_true', required=True)
parser.parse_args()
s = State()
prepared = load(OUT / 'prepared-state.json')
s.check(prepared['sourceCommit'] == SOURCE and prepared['generationSourceFiles'] == 1034,
        'prepared committed source byte proof', SOURCE)
for name, pin in prepared['stagedFiles'].items():
    if not name.startswith('source/'):
        continue
    raw = (OUT / 'stage' / name).read_bytes()
    s.check(sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'prepared source exact bytes', name)
    s.add(name, raw, 'git:' + SOURCE + ':' + name.split('/' + SOURCE + '/', 1)[1])
    s.git_cache[name.split('/' + SOURCE + '/', 1)[1]] = raw
s.source_manifest()
plan = load(COLLECTION / 'plan.json')
human = load(COLLECTION / 'human-approval.json')
review = load(COLLECTION / 'prerelease-source-review.json')
s.check(plan['round'] == 'corrective-1' and plan['automaticProcessReruns'] is False
        and plan['noSceneSplice'] is True and plan['defaultRetries'] == 0,
        'fixed single corrective round', SOURCE)
for value in (human, review):
    s.check(value['decision'] == 'APPROVED' and value['sourceCommit'] == SOURCE,
            'exact retained approvals', SOURCE)
    for key, file in [('sourceManifestSHA256', 'source-at-start.json'),
                      ('binariesManifestSHA256', 'binaries.json'), ('planSHA256', 'plan.json')]:
        s.check(value[key] == sha((COLLECTION / file).read_bytes()), 'approved source and plan binding', file)
s.check(human['checksSHA256'] == sha((COLLECTION / 'checks.json').read_bytes())
        and human['replyReference'].endswith('sha256:' + sha((COLLECTION / 'user-approval-reply.json').read_bytes())),
        'exact approved checks and human reply', SOURCE)
for path in sorted(COLLECTION.iterdir()):
    if path.is_file() and path.name != 'live.test':
        s.check(path.suffix in ('.json', '.log'), 'closed collection metadata selection', path.name)
        s.file('collection/' + path.name, path)
parent = ROOT / '.evidence/minimax-global-glm-corrective-1-reviewed-parent'
for path in sorted(parent.iterdir()):
    if path.is_file():
        s.check(path.suffix in ('.json', '.log'), 'closed parent command selection', path.name)
        s.file('parent-commands/' + path.name, path)
reports = []
for route in ('chat', 'responses', 'messages'):
    name = 'glm-corrective-1-' + route
    path = ROOT / '.evidence/minimax-launches' / (name + '.json')
    intent = load(path)
    s.check(intent['state'] == 'COMPLETED' and intent['exitCode'] in (0, 1)
            and intent['sourceCommit'] == SOURCE and intent['correctiveRound'] == 'corrective-1'
            and intent['automaticReruns'] is False
            and intent['launcherAudit'] == {'passed': True, 'findings': []},
            'closed audited actual canonical launch', name)
    for key, file in [('humanApprovalSha256', 'human-approval.json'),
                      ('sourceManifestSha256', 'source-at-start.json'),
                      ('binariesManifestSha256', 'binaries.json'), ('planSha256', 'plan.json')]:
        s.check(intent[key] == sha((COLLECTION / file).read_bytes()), 'actual approved launch binding', name + '/' + file)
    s.check(intent['originalReceipts'] == plan['originalReceipts'] == human['originalReceipts'],
            'exact original accounting lineage', name)
    s.check(path.read_bytes() == (COLLECTION / (name + '-intent.json')).read_bytes(),
            'canonical and collection intent bytes', name)
    s.file('launches/' + path.name, path)
    report = success(s, name, intent) if intent['exitCode'] == 0 else forensic(s, name, intent)
    report['canonicalCapturePinsPresent'] = 'capturePins' in intent
    report['supportEligible'] = intent['exitCode'] == 0 and 'capturePins' in intent and report['complete'] is True
    reports.append(report)
for name, pin in plan['originalReceipts'].items():
    path = ROOT / '.evidence/minimax-launches' / (name + '.json')
    original = load(path)
    s.check(sha(path.read_bytes()) == pin['receiptSHA256']
            and original['sourceCommit'] == pin['sourceCommit']
            and original['reportedFileSha256'] == pin['reportSHA256']
            and original['budget']['status'] == pin['status'], 'unchanged original canonical receipt', name)
    s.file('lineage/original-receipts/' + path.name, path)
consumption = load(COLLECTION / 'corrective-consumption.json')
s.check(consumption['originalReceipts'] == plan['originalReceipts']
        and consumption['budget'] == plan['budget'] and consumption['automaticReruns'] is False,
        'final lifetime consumption scope', SOURCE)
s.check(consumption['lifetime'] == {'calls': 132, 'attempts': 132, 'conservativeCalls': 132,
        'conservativeAttempts': 132, 'maxCalls': 138, 'maxAttempts': 162}, 'original plus R1 consumed totals', SOURCE)
rows = {row['route']: row for row in consumption['routes']}
for report in reports:
    row = rows[report['job']]
    s.check(row['state'] == 'REPORTED' and row['status'] == report['outcome']
            and row['calls'] == row['attempts'] == 22, 'final own route consumption', report['job'])
s.check([report['outcome'] for report in reports] == ['PASS', 'FAIL', 'PASS']
        and [report['supportEligible'] for report in reports] == [True, False, True],
        'truthful partial corrective qualification', SOURCE)
prepay_path = OUT / 'corrective-approved-prepay-5bf2c16.json'
prepay = load(prepay_path)
prepay_archive = OUT / prepay['archive']
s.check(sha(prepay_archive.read_bytes()) == prepay['archiveSha256'] and
        prepay['caseOutcomes'] == {'PASS': 336, 'NOT_RUN': 62} and prepay['auditFindings'] == 0,
        'separate exact passed prepay raw boundary', SOURCE)
s.file('lineage/approved-prepay-index.json', prepay_path)
external = []
for label, path, pin in [
    ('candidate-C', OUT.parent / 'barness-minimax-global-candidate-capsule/international-candidates-7605332.tar.gz',
     '06fca74279c09495cf817c377311718f66290b63c43103285c26cfd87753ca08'),
    ('original-M', OUT.parent / 'barness-minimax-global-formal-glm-capsule/international-formal-glm-8900034.tar.gz',
     '8b649a95fbc5d0e668173400a92ce2395ef86dc491762f6b9fff9a8ecf5aa07e'),
    ('failed-Q-9dc', ROOT / '.evidence/minimax-retained/glm-corrective-q-9dc-audit-failure.tar.gz',
     '56e08cbf7105f4fe1a1751bae42ba83988bcdbb4d1b1d443dd9bcd9a2d62ae3c'),
    ('failed-Q-9dc-source-proof', OUT.parent / 'barness-minimax-root-preflight-failure-capsule/q-9dc-committed-source-proof.tar.gz',
     '7fe0d49506b8c31c445f5ebc9f8868e25dbbee4e875e62e43ea226356601bd86'),
    ('approved-prepay-Q', prepay_archive, prepay['archiveSha256'])]:
    s.check(sha(path.read_bytes()) == pin, 'immutable external retained lineage', label)
    external.append({'kind': label, 'archive': path.name, 'sha256': pin,
                     'bytes': path.stat().st_size, 'includedInActualCapsule': False})
for axis in ('standards', 'spec'):
    for extension in ('md', 'json'):
        p = Path('/tmp/barness-minimax-final-source-' + axis + '-review.' + extension)
        if extension == 'json':
            v = load(p)
            s.check(v['verdict'] == 'PASS' and v['findings'] == [], 'retained parent source review', axis)
        s.file('parent-audits/' + p.name, p)
archive = OUT / (STEM + '.tar.gz')
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, raw in sorted(s.items.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(raw), 0o644, 0
                tar.addfile(info, io.BytesIO(raw))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    s.check(len(members) == len(s.items) and {m.name for m in members} == set(s.items),
            'complete actual archive roundtrip inventory', SOURCE)
    for member in members:
        s.check(member.isfile() and tar.extractfile(member).read() == s.items[member.name],
                'actual archive roundtrip exact bytes', member.name)
created = datetime.datetime.now(datetime.timezone.utc).isoformat()
index = {'schema': 1, 'kind': 'actual-approved-GLM-corrective-1-PARTIAL-checkpoint',
         'createdAt': created, 'sourceCommit': SOURCE, 'archive': archive.name,
         'archiveBytes': archive.stat().st_size, 'archiveSha256': sha(archive.read_bytes()),
         'files': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(s.items.items())},
         'generationSourceFiles': 1034, 'portableSourceFiles': sum(name.startswith('source/') for name in s.items),
         'reports': reports, 'qualification': 'PARTIAL', 'completeThreeRouteRenewal': False,
         'individuallyEligibleOwnRoutes': [r['job'] for r in reports if r['supportEligible']],
         'externalBinaries': prepared['externalBinaries'], 'externalLineage': external,
         'unchangedM3ExecutionSources': prepared['unchangedM3ExecutionSources'],
         'originalBudget': {'calls': 66, 'attempts': 66}, 'correctiveBudget': {'calls': 66, 'attempts': 66,
         'maxCalls': 72, 'maxAttempts': 96}, 'currentRenewalLifetime': consumption['lifetime'],
         'automaticReruns': False, 'additionalRoundAuthorized': False,
         'checks': dict(s.checks), 'totalChecks': sum(s.checks.values()),
         'credentialsReadByCurator': False, 'networkUsedByCurator': False,
         'testsRunByCurator': False, 'rootModifiedByCurator': False,
         'authority': 'Original common-root canonical launcher receipts and exact approved human/source/plan hashes. Producer seal or failed view alone never qualifies support.',
         'scope': 'R1 only. Responses remains failed and incomplete; original failed M and 9dc preflight remain unchanged. No three-route GLM promotion or final release certification.'}
index_path = OUT / (STEM + '.json')
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
lines = ['# Approved GLM corrective round: immutable actual evidence', '',
         'Integrity PASS; actual qualification PARTIAL. Captured source `' + SOURCE + '`.', '',
         f"All {sum(s.checks.values()):,} final curation checks passed. Actual capsule: "
         f"{archive.stat().st_size:,} bytes / {len(s.items)} exact files, including all 1,034 committed "
         'generation-source files plus the captured README execution pin, three own raw route captures, '
         'canonical receipts, exact approvals/reply, closed command metadata and final consumption. '
         'Every archived byte passed a roundtrip comparison. Prepared executable binaries are excluded '
         'and retain original hash/size/location in the index.', '',
         '| Corrective route | Own cases | Calls / attempts | Qualification |',
         '| --- | --- | --- | --- |',
         '| Chat | 22 PASS | 22 / 22 | Complete; original canonical capture pins qualify |',
         '| Responses | 21 PASS / 1 FAIL | 22 / 22 | Incomplete; no canonical successful capture pins |',
         '| Messages | 22 PASS | 22 / 22 | Complete; original canonical capture pins qualify |', '',
         'Responses preserves the existing producer seal and `live-report.json` as failed forensic bytes. '
         'Its own report stays FAIL / complete false. The sole failure is `glm-5.2/native-history`: no '
         'visible final text, no capture truncation, known input 63 / output 2 / reasoning 2. Both '
         'model-qualified views remain incomplete, including the GLM5.3 view whose outcome is PASS. '
         'An existing seal or view does not establish successful support, and none was minted by this curator.', '',
         'All actual exchanges returned HTTP 200 and matched the selected model. Exact complete/partial/'
         'unreported usage labels remain in the index. Known counters do not make partial reporting '
         'complete; omitted categories and cancellation consumption remain unknown. Estimated known '
         'cost is not an invoice. Selected-key launcher audits and capture audits have no findings.', '',
         'R1 consumed 66 calls / 66 attempts within the user-approved 72 / 96 caps. Original renewal '
         'receipts retain 66 / 66 and their PASS / FAIL / PASS statuses. Current renewal lifetime is '
         '132 / 132 within 138 / 162. There was no automatic process rerun, scene splice, history reset '
         'or second corrective-round authorization.', '',
         'The passed prepay full raw bundle is separately staged: 336 PASS / 62 NOT_RUN, audit 0, both '
         'vets and Go exit 0. Its archive/index/inventory remain an external byte boundary to avoid '
         'duplicating the large bundle in this actual capsule. Earlier candidate C, original M and failed '
         '9dc Q archives/source proof are pinned externally and unchanged. All three retained M3 formal '
         'execution maps (263 files each) are byte-identical at this corrective source. Parent source '
         'Standards/Spec reviews are retained separately; they do not replace actual route qualification.', '',
         'This does not qualify the whole three-route GLM renewal and does not authorize another paid '
         'round. No renewal promotion or final release gate was run by this curator. No repository files '
         'were changed, credentials read, tests executed or vendors called.', '',
         'Portable verification uses `verify_actual.py` for this capsule and the separate passed-prepay '
         'archive/index/inventory. Earlier lineage archives can additionally be supplied for boundary hashes.', '',
         'Actual archive SHA-256: `' + index['archiveSha256'] + '`.']
audit_path = OUT / (STEM + '-audit.md')
audit_path.write_text('\n'.join(lines) + '\n')
scripts = ('common.py', 'glm.py', 'glm_forensic.py', 'prepare_actual.py',
           'prepare_closed_responses.py', 'retain_prepay.py', 'retain_actual.py', 'verify_actual.py')
provenance = {'schema': 1, 'createdAt': created, 'sourceCommit': SOURCE,
              'curator': '/root/candidate_capsule', 'qualification': 'PARTIAL',
              'scripts': {name: {'sha256': sha((OUT / name).read_bytes()), 'bytes': (OUT / name).stat().st_size}
                          for name in scripts},
              'outputs': {path.name: {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
                          for path in (archive, index_path, audit_path)},
              'credentialsRead': False, 'networkUsed': False, 'testsRun': False, 'rootModified': False}
prov_path = OUT / (STEM + '-provenance.json')
prov_path.write_text(json.dumps(provenance, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'files': len(s.items), 'checks': sum(s.checks.values()), 'qualification': 'PARTIAL',
                  'outputs': {path.name: {'sha256': sha(path.read_bytes()), 'bytes': path.stat().st_size}
                              for path in (archive, index_path, audit_path, prov_path)}}, indent=2))
