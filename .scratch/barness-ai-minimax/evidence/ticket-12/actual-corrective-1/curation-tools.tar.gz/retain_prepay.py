"""Stage the closed passed keyless bundle separately; never inspect live R1 routes."""
from pathlib import Path, PurePosixPath
from collections import Counter
import gzip
import hashlib
import json
import os
import stat
import tarfile
from common import ROOT, COLLECTION, OUT, SOURCE, sha, load

NAME = 'corrective-approved-prepay-5bf2c16'
command = load(COLLECTION / 'no-key-live-command.json')
assert command['exitCode'] == 0 and command['credentialsRead'] is False
assert command['launcherAudit'] == {'passed': True, 'findings': []}
base = COLLECTION / 'no-key-live'
sessions = [p for p in base.iterdir() if p.is_dir() and (p / 'manifest.json').is_file()]
main = max(sessions, key=lambda p: len(load(p / 'manifest.json')['cases']))
paths = {}
inventory = {}
walked = 0
total = 0
stack = [(base, 0)]
while stack:
    folder, depth = stack.pop()
    assert depth <= 24
    with os.scandir(folder) as entries:
        for entry in entries:
            walked += 1
            assert walked <= 400000
            p = Path(entry.path)
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISDIR(info.st_mode):
                stack.append((p, depth + 1))
                continue
            key = 'no-key-live/' + p.relative_to(base).as_posix()
            assert key not in paths and '..' not in PurePosixPath(key).parts
            if stat.S_ISLNK(info.st_mode):
                raw = os.fsencode(os.readlink(p))
                assert len(raw) <= 4096
                pin = {'bytes': len(raw), 'sha256': sha(raw), 'kind': 'intentional-negative-symlink'}
            else:
                assert stat.S_ISREG(info.st_mode) and info.st_size <= 64 << 20
                raw = p.read_bytes()
                assert len(raw) == info.st_size
                pin = {'bytes': len(raw), 'sha256': sha(raw)}
            total += len(raw)
            assert total <= 512 << 20
            paths[key], inventory[key] = p, pin
for group in ('prepay', 'prepay-parent'):
    for p in (OUT / 'stage' / group).iterdir():
        assert p.is_file() and not p.is_symlink() and p.stat().st_size <= 8 << 20
        key = group + '/' + p.name
        paths[key] = p
        raw = p.read_bytes()
        inventory[key] = {'bytes': len(raw), 'sha256': sha(raw)}
manifest = load(main / 'manifest.json')
outcomes = Counter(case['status'] for case in manifest['cases'])
assert outcomes == {'PASS': 336, 'NOT_RUN': 62} and manifest['git_commit'] == SOURCE
assert load(main / 'audit.json') == {'findings': []}
refs = 0
for case in manifest['cases']:
    for name, pin in case.get('artifacts', {}).items():
        key = 'no-key-live/' + main.name + '/' + case['dir'] + '/' + name
        assert inventory[key]['sha256'] == pin
        refs += 1
archive = OUT / (NAME + '.tar.gz')
with archive.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for key, p in sorted(paths.items()):
                info = tarfile.TarInfo(key)
                info.mode = 0o600
                if inventory[key].get('kind'):
                    info.type = tarfile.SYMTYPE
                    info.linkname = os.readlink(p)
                    tar.addfile(info)
                else:
                    info.size = inventory[key]['bytes']
                    with p.open('rb') as f:
                        tar.addfile(info, f)
seen = set()
with tarfile.open(archive, 'r|gz') as tar:
    for member in tar:
        pin = inventory[member.name]
        assert member.name not in seen
        seen.add(member.name)
        if member.issym():
            raw = os.fsencode(member.linkname)
            assert pin.get('kind') == 'intentional-negative-symlink'
        else:
            assert member.isfile() and not pin.get('kind')
            raw = tar.extractfile(member).read()
        assert len(raw) == pin['bytes'] and sha(raw) == pin['sha256']
assert seen == set(inventory)
inv_path = OUT / (NAME + '-files.json.gz')
with inv_path.open('wb') as target:
    with gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as gz:
        gz.write(json.dumps(inventory, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode())
index = {'schema': 1, 'kind': 'passed-approved-keyless-prepay-original-bytes',
         'sourceCommit': SOURCE, 'archive': archive.name, 'archiveBytes': archive.stat().st_size,
         'archiveSha256': sha(archive.read_bytes()), 'inventory': inv_path.name,
         'inventorySha256': sha(inv_path.read_bytes()), 'entries': len(inventory),
         'regularFiles': sum(not pin.get('kind') for pin in inventory.values()),
         'negativeSymlinkFixtures': sum(bool(pin.get('kind')) for pin in inventory.values()),
         'expandedBytesIncludingSymlinkText': sum(pin['bytes'] for pin in inventory.values()),
         'manifest': 'no-key-live/' + main.name + '/manifest.json',
         'mainArtifactReferences': refs, 'caseOutcomes': dict(outcomes), 'auditFindings': 0,
         'goExit': 0, 'vetExit': 0, 'vetLiveExit': 0, 'credentialsReadByCurator': False,
         'vendorCallsByCurator': 0, 'rootModifiedByCurator': False,
         'archiveByteRoundtripVerified': True,
         'binaryScope': 'Prepared live.test excluded; exact original hash, size and origin remain in prepared-state.json.',
         'actualR1RoutesIncluded': False, 'mutableConsumptionSnapshotted': False,
         'retention': 'Staged under /tmp only. Parent may copy this unchanged archive into common ignored retention.'}
index_path = OUT / (NAME + '.json')
index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k:index[k] for k in ('archiveBytes','archiveSha256','entries','regularFiles',
                 'negativeSymlinkFixtures','mainArtifactReferences','caseOutcomes','auditFindings',
                 'mutableConsumptionSnapshotted')}, indent=2))
