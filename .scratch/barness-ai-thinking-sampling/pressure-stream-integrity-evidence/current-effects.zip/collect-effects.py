import datetime, hashlib, json, os, shlex, signal, subprocess
from pathlib import Path

root = Path.cwd()
out = root / '.evidence/pressure-integrity/current-effects'
out.mkdir(mode=0o700, exist_ok=False)
base = {k: os.environ[k] for k in ('PATH','HOME','TMPDIR','GOCACHE','GOPATH') if k in os.environ}
binary = out / 'chineseeval'
build = ['go','build','-o',str(binary),'./ai/examples/chineseeval/cmd/chineseeval']
subprocess.run(build,env=base,check=True,timeout=120)
records = []
for route, key_name, key_env, account in [('jev','TYPESAFE_KEY','BARNESS_AI_CHINESE_EVAL_TYPESAFE_KEY','local-typesafe@region-permissions-unconfirmed'),('luna','OPENAI_KEY','BARNESS_AI_CHINESE_EVAL_OPENAI_KEY','local-openai@region-unreported')]:
    values = []
    for line in (root / '.env').read_text().splitlines() if (root / '.env').exists() else []:
        name, sep, value = line.strip().removeprefix('export ').partition('=')
        if sep and name.strip() == key_name:
            parts = shlex.split(value,comments=True)
            if len(parts) > 1: raise SystemExit('ambiguous selected credential')
            values.append(parts[0] if parts else '')
    if len(values) > 1: raise SystemExit('duplicate selected credential')
    key = values[0] if values else ''
    folder = out / route
    folder.mkdir(mode=0o700)
    env = dict(base)
    env.update(BARNESS_AI_CHINESE_EVAL='1',BARNESS_AI_CHINESE_EVAL_ACCOUNT_ALIAS=account)
    env[key_env] = key
    command = [str(binary),'-route',route,'-out',str(folder / 'bundles'),'-live','-proxy','http://127.0.0.1:7890']
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child = subprocess.Popen(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    watchdog = False
    try: output,_ = child.communicate(timeout=620)
    except subprocess.TimeoutExpired:
        watchdog = True
        child.send_signal(signal.SIGTERM)
        try: output,_ = child.communicate(timeout=15)
        except subprocess.TimeoutExpired:
            child.kill(); output,_ = child.communicate()
    if key: output = output.replace(key.encode(),b'[REDACTED]')
    output = output.replace(str(root).encode(),b'[REPO]').replace(str(Path.home()).encode(),b'[HOME]')
    (folder/'execution.log').write_bytes(output)
    reports = list((folder/'bundles').glob('*/evaluation-report.json'))
    report = json.loads(reports[0].read_text()) if len(reports) == 1 else {}
    receipt = {'route':route,'command':[x.replace(str(root),'[REPO]') for x in command],'buildCommand':[x.replace(str(root),'[REPO]') for x in build], 'gitCommit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'binarySHA256':hashlib.sha256(binary.read_bytes()).hexdigest(),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':child.returncode,'watchdogTriggered':watchdog,'credentialSource':'.env:'+key_name,'keyPresent':bool(key),'environmentNames':sorted(env),'accountAlias':account,'accountVerification':'unknown','permissionVerification':'unknown','proxy':'http://127.0.0.1:7890','budget':{'calls':24,'attempts':24,'retries':0,'concurrency':1,'totalSeconds':600,'callSeconds':15},'status':report.get('status','FAIL'),'bundle':str(reports[0].parent.relative_to(root)) if len(reports)==1 else None}
    (folder/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    records.append(receipt)
    (out/'collection.json').write_text(json.dumps(records,indent=2)+'\n')
    print(route,receipt['status'],'exit',child.returncode,flush=True)
