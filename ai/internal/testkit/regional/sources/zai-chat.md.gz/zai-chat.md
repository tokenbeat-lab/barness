> ## Documentation Index
> Fetch the complete documentation index at: https://docs.z.ai/llms.txt
> Use this file to discover all available pages before exploring further.

# Chat Completion

> Create a chat completion model that generates AI replies for given conversation messages. It supports multimodal inputs (text, images, audio, video, file), offers configurable parameters (like temperature, max tokens, tool use), and supports both streaming and non-streaming output modes.



## OpenAPI

````yaml POST /paas/v4/chat/completions
openapi: 3.0.1
info:
  title: Z.AI API
  description: Z.AI API available endpoints
  license:
    name: Z.AI Developer Agreement and Policy
    url: https://chat.z.ai/legal-agreement/terms-of-service
  version: 1.0.0
  contact:
    name: Z.AI Developers
    url: https://chat.z.ai/legal-agreement/privacy-policy
    email: user_feedback@z.ai
servers:
  - url: https://api.z.ai/api
    description: Production server
security:
  - bearerAuth: []
paths:
  /paas/v4/chat/completions:
    post:
      description: >-
        Create a chat completion model that generates AI replies for given
        conversation messages. It supports multimodal inputs (text, images,
        audio, video, file), offers configurable parameters (like temperature,
        max tokens, tool use), and supports both streaming and non-streaming
        output modes.
      parameters:
        - $ref: '#/components/parameters/AcceptLanguage'
      requestBody:
        content:
          application/json:
            schema:
              oneOf:
                - $ref: '#/components/schemas/ChatCompletionTextRequest'
                  title: Text Model
                - $ref: '#/components/schemas/ChatCompletionVisionRequest'
                  title: Vision Model
            examples:
              Basic Example:
                value:
                  model: glm-5.3
                  messages:
                    - role: system
                      content: You are a helpful coding assistant.
                    - role: user
                      content: >-
                        Write a Python function to calculate the factorial of a
                        number.
                  temperature: 1
                  stream: false
              Stream Example:
                value:
                  model: glm-5.3
                  messages:
                    - role: system
                      content: You are a helpful coding assistant.
                    - role: user
                      content: >-
                        Write a Python function to calculate the factorial of a
                        number.
                  temperature: 1
                  stream: true
              Thinking Example:
                value:
                  model: glm-5.3
                  messages:
                    - role: system
                      content: You are a helpful coding assistant.
                    - role: user
                      content: >-
                        Write a Python function to calculate the factorial of a
                        number.
                  thinking:
                    type: enabled
                  stream: true
              Multi Conversation:
                value:
                  model: glm-5.3
                  messages:
                    - role: system
                      content: You are a professional programming assistant.
                    - role: user
                      content: What is recursion?
                    - role: assistant
                      content: >-
                        Recursion is a programming technique where a function
                        calls itself to solve a problem... What is recursion
                    - role: user
                      content: Can you give me an example of Python recursion?
                  stream: true
              Image Visual Example:
                value:
                  model: glm-5.3-flashx
                  messages:
                    - role: user
                      content:
                        - type: image_url
                          image_url:
                            url: https://cdn.bigmodel.cn/static/logo/register.png
                        - type: image_url
                          image_url:
                            url: https://cdn.bigmodel.cn/static/logo/api-key.png
                        - type: text
                          text: What are the pics talk about?
              Video Visual Example:
                value:
                  model: glm-5.3-flashx
                  messages:
                    - role: user
                      content:
                        - type: video_url
                          video_url:
                            url: >-
                              https://cdn.bigmodel.cn/agent-demos/lark/113123.mov
                        - type: text
                          text: What are the video show about?
              File Visual Example:
                value:
                  model: glm-5.3-flash
                  messages:
                    - role: user
                      content:
                        - type: file
                          file:
                            file_url: https://cdn.bigmodel.cn/static/demo/demo2.txt
                        - type: file
                          file:
                            file_url: https://cdn.bigmodel.cn/static/demo/demo1.pdf
                        - type: text
                          text: What are the files show about?
              Function Call Example:
                value:
                  model: glm-5.3
                  messages:
                    - role: user
                      content: >-
                        Is there an example of how the weather in Beijing is
                        today?
                  tools:
                    - type: function
                      function:
                        name: get_weather
                        description: Get weather information for the specified city.
                        parameters:
                          type: object
                          properties:
                            city:
                              type: string
                              description: City Name
                          required:
                            - city
                  tool_choice: auto
                  temperature: 0.3
        required: true
      responses:
        '200':
          description: Processing successful
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/ChatCompletionResponse'
        default:
          description: The request has failed.
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Error'
components:
  parameters:
    AcceptLanguage:
      name: Accept-Language
      in: header
      schema:
        type: string
        description: Config desired response language for HTTP requests.
        default: en-US,en
        example: en-US,en
        enum:
          - en-US,en
      required: false
  schemas:
    ChatCompletionTextRequest:
      required:
        - model
        - messages
      type: object
      properties:
        model:
          type: string
          description: >-
            The model code to be called. GLM-5.3, GLM-5.2, GLM-5.1 are the
            latest flagship model series, foundational models specifically
            designed for agent applications.
          example: glm-5.3
          default: glm-5.3
          enum:
            - glm-5.3
            - glm-5.2
            - glm-5.1
            - glm-5
            - glm-4.7
            - glm-4.6
        messages:
          type: array
          description: >-
            The current conversation message list as the model’s prompt input,
            provided in JSON array format, e.g.,`{“role”: “user”, “content”:
            “Hello”}`. Possible message types include system messages, user
            messages, assistant messages, and tool messages. Note: The input
            must not consist of system messages or assistant messages only.
          items:
            oneOf:
              - title: User Message
                type: object
                properties:
                  role:
                    type: string
                    enum:
                      - user
                    description: Role of the message author
                    default: user
                  content:
                    oneOf:
                      - type: string
                        description: Text message content
                        example: >-
                          What opportunities and challenges will the Chinese
                          large model industry face in 2025?
                required:
                  - role
                  - content
              - title: System Message
                type: object
                properties:
                  role:
                    type: string
                    enum:
                      - system
                    description: Role of the message author
                    default: system
                  content:
                    oneOf:
                      - type: string
                        description: Message text content
                        example: You are a helpful assistant.
                required:
                  - role
                  - content
              - title: Assistant Message
                type: object
                description: Can include tool calls
                properties:
                  role:
                    type: string
                    enum:
                      - assistant
                    description: Role of the message author
                    default: assistant
                  content:
                    oneOf:
                      - type: string
                        description: Text message content
                        example: I'll help you with that analysis.
                  tool_calls:
                    type: array
                    description: >-
                      Tool call messages generated by the model. When this field
                      is provided, content is usually empty.
                    items:
                      type: object
                      properties:
                        id:
                          type: string
                          description: Tool call ID
                        type:
                          type: string
                          description: Tool type, supports web_search, retrieval, function
                          enum:
                            - function
                            - web_search
                            - retrieval
                        function:
                          type: object
                          description: >-
                            Function call information, not empty when type is
                            function
                          properties:
                            name:
                              type: string
                              description: Function name
                            arguments:
                              type: string
                              description: Function parameters, JSON format string
                          required:
                            - name
                            - arguments
                      required:
                        - id
                        - type
                required:
                  - role
              - title: Tool Message
                type: object
                properties:
                  role:
                    type: string
                    enum:
                      - tool
                    description: Role of the message author
                    default: tool
                  content:
                    oneOf:
                      - type: string
                        description: Message text content
                        example: 'Function executed successfully with result: ...'
                  tool_call_id:
                    type: string
                    description: Indicates the tool call ID corresponding to this message
                required:
                  - role
                  - content
                  - tool_call_id
          minItems: 1
        do_sample:
          type: boolean
          example: true
          default: true
          description: >-
            When do_sample is true, sampling strategy is enabled; when do_sample
            is false, sampling strategy parameters such as temperature and top_p
            will not take effect. Default value is `true`.
        stream:
          type: boolean
          example: false
          default: false
          description: >-
            This parameter should be set to false or omitted when using
            synchronous call. It indicates that the model returns all content at
            once after generating all content. Default value is false. If set to
            true, the model will return the generated content in chunks via
            standard Event Stream. When the Event Stream ends, a `data: [DONE]`
            message will be returned.
        thinking:
          $ref: '#/components/schemas/ChatThinking'
        reasoning_effort:
          type: string
          description: >-
            Controls the model's reasoning effort level, takes effect when
            `thinking` is enabled. Default is `max`, supported by `GLM-5.2` and
            above. For the `GLM-5.3` `GLM-5.3-FLASH` model, only the `low` /
            `high` / `max` levels are supported. For the `GLM-5.2` model, for
            compatibility with other protocols, passing `none` or `minimal` will
            cause the model to skip thinking; `low` and `medium` will be mapped
            to `high`; `xhigh` will be mapped to `max`.
          example: max
          default: max
          enum:
            - max
            - xhigh
            - high
            - medium
            - low
            - minimal
            - none
        temperature:
          type: number
          description: >-
            Sampling temperature, controls the randomness of the output, must be
            a positive number within the range: `[0.0, 1.0]`. The GLM-5.3,
            GLM-5.2, GLM-5.1, GLM-5, GLM-4.7, GLM-4.6 series default value is
            `1.0`
          format: float
          example: 1
          default: 1
          minimum: 0
          maximum: 1
        top_p:
          type: number
          description: >-
            Another method of temperature sampling, value range is: `[0.01,
            1.0]`. The GLM-5.3, GLM-5.2, GLM-5.1, GLM-5, GLM-4.7, GLM-4.6 series
            default value is `0.95`.
          format: float
          example: 0.95
          default: 0.95
          minimum: 0.01
          maximum: 1
        max_tokens:
          type: integer
          description: >-
            The maximum number of tokens for model output, the GLM-5.3, GLM-5.2,
            GLM-5.1, GLM-5, GLM-4.7, GLM-4.6 series supports 128K maximum
            output.
          example: 1024
          minimum: 1
          maximum: 131072
        tool_stream:
          type: boolean
          example: false
          default: false
          description: >-
            Whether to enable streaming response for Function Calls. Default
            value is false. Only supported by the GLM-5.3, GLM-5.2, GLM-5.1,
            GLM-5, GLM-4.7, and GLM-4.6 series. Refer to the [Stream Tool
            Call](/guides/tools/stream-tool)
        tools:
          type: array
          description: >
            A list of tools the model may call. Currently, only functions are
            supported as a tool. Use this to provide a list of functions the
            model may generate JSON inputs for. A max of 128 functions are
            supported.
          items:
            anyOf:
              - $ref: '#/components/schemas/FunctionToolSchema'
              - $ref: '#/components/schemas/RetrievalToolSchema'
              - $ref: '#/components/schemas/WebSearchToolSchema'
        tool_choice:
          oneOf:
            - type: string
              enum:
                - auto
              description: >-
                Used to control how the model selects which function to call.
                This is only applicable when the tool type is function. The
                default value is auto, and only auto is supported.
          description: Controls how the model selects a tool.
        stop:
          type: array
          description: >-
            Stop word list. Generation stops when the model encounters any
            specified string. Currently, only one stop word is supported, in the
            format ["stop_word1"].
          items:
            type: string
          maxItems: 4
        response_format:
          type: object
          description: >-
            Specifies the response format of the model. Defaults to text. Only
            text models support this field. `type` converges to three values:
            `text` (plain text output), `json_object` (JSON output).
          properties:
            type:
              type: string
              enum:
                - text
                - json_object
              default: text
              description: >-
                Output format type: text for plain text, json_object for
                JSON-formatted output.
          required:
            - type
        request_id:
          type: string
          description: >-
            Passed by the user side, needs to be unique; used to distinguish
            each request, 6–64 characters. If not provided by the user side, the
            platform will generate one by default.
          minLength: 6
          maxLength: 64
        user_id:
          type: string
          description: >-
            Unique ID for the end user, 6–128 characters. Avoid using sensitive
            information.
          minLength: 6
          maxLength: 128
    ChatCompletionVisionRequest:
      required:
        - model
        - messages
      type: object
      properties:
        model:
          type: string
          description: >-
            The model code to be called. The `GLM-5.3-Flash` series supports
            visual understanding, delivering excellent multimodal comprehension
            and tool calling capabilities.
          example: glm-5.3-flashx
          default: glm-5.3-flashx
          enum:
            - glm-5.3-flashx
            - glm-5.3-flash
        messages:
          type: array
          description: >-
            The current conversation message list as the model’s prompt input,
            provided in JSON array format, e.g.,`{“role”: “user”, “content”:
            “Hello”}`. Possible message types include system messages, user
            messages. Note: The input must not consist of system or assistant
            messages only.
          items:
            oneOf:
              - title: User Message
                type: object
                properties:
                  role:
                    type: string
                    enum:
                      - user
                    description: Role of the message author
                    default: user
                  content:
                    oneOf:
                      - type: array
                        description: >-
                          Multimodal message content, supports text, images,
                          video, file
                        items:
                          $ref: '#/components/schemas/VisionMultimodalContentItem'
                      - type: string
                        description: >-
                          Text message content (can switch to multimodal message
                          above)
                        example: >-
                          What opportunities and challenges will the Chinese
                          large model industry face in 2025?
                required:
                  - role
                  - content
              - title: System Message
                type: object
                properties:
                  role:
                    type: string
                    enum:
                      - system
                    description: Role of the message author
                    default: system
                  content:
                    oneOf:
                      - type: string
                        description: Message text content
                        example: You are a helpful assistant.
                required:
                  - role
                  - content
              - title: Assistant Message
                type: object
                description: Can include tool calls
                properties:
                  role:
                    type: string
                    enum:
                      - assistant
                    description: Role of the message author
                    default: assistant
                  content:
                    oneOf:
                      - type: string
                        description: Text message content
                        example: I'll help you with that analysis.
                required:
                  - role
          minItems: 1
        do_sample:
          type: boolean
          example: true
          default: true
          description: >-
            When do_sample is true, sampling strategy is enabled; when do_sample
            is false, sampling strategy parameters such as temperature and top_p
            will not take effect. Default value is `true`.
        stream:
          type: boolean
          example: false
          default: false
          description: >-
            This parameter should be set to false or omitted when using
            synchronous call. It indicates that the model returns all content at
            once after generating all content. Default value is false. If set to
            true, the model will return the generated content in chunks via
            standard Event Stream. When the Event Stream ends, a `data: [DONE]`
            message will be returned.
        thinking:
          $ref: '#/components/schemas/ChatThinking'
        reasoning_effort:
          type: string
          description: >-
            Controls the model's reasoning effort level, takes effect when
            `thinking` is enabled. Default is `max`.
          example: max
          default: max
          enum:
            - max
            - high
            - low
        temperature:
          type: number
          description: >-
            Sampling temperature, controls the randomness of the output, must be
            a positive number within the range: `[0.0, 1.0]`. For
            `GLM-5.3-Flash` series the default value is `1.0`.
          format: float
          example: 1
          default: 1
          minimum: 0
          maximum: 1
        top_p:
          type: number
          description: >-
            Another method of temperature sampling, value range is: `[0.01,
            1.0]`. For `GLM-5.3-Flash` series the default value is `0.95`.
          format: float
          example: 0.95
          default: 0.95
          minimum: 0.01
          maximum: 1
        max_tokens:
          type: integer
          description: >-
            The maximum number of tokens for model output. `GLM-5.3-Flash`
            series supports a maximum output length of 128K.
          example: 1024
          minimum: 1
          maximum: 131072
        tools:
          type: array
          description: >
            A list of tools the model may call. Only supported by
            `GLM-5.3-Flash` series.Use this to provide a list of functions the
            model may generate JSON inputs for. A max of 128 functions are
            supported.
          items:
            anyOf:
              - $ref: '#/components/schemas/FunctionToolSchema'
        tool_choice:
          oneOf:
            - type: string
              enum:
                - auto
              description: >-
                Used to control how the model selects which function to call.
                This is only applicable when the tool type is function. The
                default value is auto, and only auto is supported.
          description: Controls how the model selects a tool.
        stop:
          type: array
          description: >-
            Stop word list. Generation stops when the model encounters any
            specified string. Currently, only one stop word is supported, in the
            format ["stop_word1"].
          items:
            type: string
          maxItems: 4
        request_id:
          type: string
          description: >-
            Passed by the user side, needs to be unique; used to distinguish
            each request, 6–64 characters. If not provided by the user side, the
            platform will generate one by default.
          minLength: 6
          maxLength: 64
        user_id:
          type: string
          description: >-
            Unique ID for the end user, 6–128 characters. Avoid using sensitive
            information.
          minLength: 6
          maxLength: 128
    ChatCompletionResponse:
      type: object
      properties:
        id:
          type: string
          description: Task ID
        request_id:
          description: Request ID
          type: string
        created:
          description: Request creation time, Unix timestamp in seconds
          type: integer
        model:
          description: Model name
          type: string
        choices:
          type: array
          description: List of model responses
          items:
            type: object
            properties:
              index:
                type: integer
                description: Result index.
              message:
                $ref: '#/components/schemas/ChatCompletionResponseMessage'
              finish_reason:
                type: string
                description: >-
                  Reason for model inference termination. Can be `stop`,
                  `tool_calls`, `length`, `sensitive`,
                  `model_context_window_exceeded` or `network_error`.
        usage:
          type: object
          description: Token usage statistics returned when the model call ends.
          properties:
            prompt_tokens:
              type: number
              description: Number of tokens in user input
            completion_tokens:
              type: number
              description: Number of output tokens
            prompt_tokens_details:
              type: object
              properties:
                cached_tokens:
                  type: number
                  description: Number of tokens served from cache
            total_tokens:
              type: integer
              description: Total number of tokens
        web_search:
          description: Search results.
          type: array
          items:
            $ref: '#/components/schemas/WebSearchObjectResponse'
    Error:
      required:
        - code
        - message
      type: object
      description: The request has failed.
      properties:
        code:
          type: integer
          format: int32
          description: Error code.
        message:
          type: string
          description: Error message.
    ChatThinking:
      type: object
      description: >-
        Only supported by GLM-4.6 series and higher models. This parameter is
        used to control whether the model enable the chain of thought.
      properties:
        type:
          type: string
          description: >-
            Whether to enable the chain of thought(`GLM-5.3` `GLM-5.3-FLASH`
            series can only be enabled, and the thinking depth is controlled by
            `reasoning_effort`; for other models, when enabled, GLM-5.2 GLM-5.1
            GLM-5 GLM-4.6 and others will automatically determine whether to
            think, while GLM-4.7 will think compulsorily), default: enabled
          default: enabled
          enum:
            - enabled
            - disabled
        clear_thinking:
          type: boolean
          description: >-
            Default value is True. Controls whether to clear `reasoning_content`
            from previous conversation turns. View more in [Thinking
            Mode](/guides/capabilities/thinking-mode). 
             - `true` (default): For this request, the system ignores/removes `reasoning_content` from prior turns, and only keeps non-reasoning context (e.g., user/assistant visible text, tool calls, and tool results). This is recommended for general chat or lightweight tasks to reduce context length and cost. 
             - `false`: Retains `reasoning_content` from prior turns and includes it in the context sent to the model. To enable Preserved Thinking, you must forward the full, unmodified, and correctly ordered historical `reasoning_content` in `messages`. Missing, truncated, rewritten, or reordered blocks may degrade performance or prevent the feature from taking effect. 
             - Notes: This parameter only affects cross-turn historical thinking blocks; it does not change whether the model generates/returns thinking in the current turn.
          default: true
          example: true
    FunctionToolSchema:
      type: object
      title: Function Call
      properties:
        type:
          type: string
          default: function
          enum:
            - function
        function:
          $ref: '#/components/schemas/FunctionObject'
      required:
        - type
        - function
      additionalProperties: false
    RetrievalToolSchema:
      type: object
      title: Retrieval
      properties:
        type:
          type: string
          default: retrieval
          enum:
            - retrieval
        retrieval:
          $ref: '#/components/schemas/RetrievalObject'
      required:
        - type
        - retrieval
      additionalProperties: false
    WebSearchToolSchema:
      type: object
      title: Web Search
      properties:
        type:
          type: string
          default: web_search
          enum:
            - web_search
        web_search:
          $ref: '#/components/schemas/WebSearchObject'
      required:
        - type
        - web_search
      additionalProperties: false
    VisionMultimodalContentItem:
      oneOf:
        - title: Text
          type: object
          properties:
            type:
              type: string
              enum:
                - text
              description: Content type is text
              default: text
            text:
              type: string
              description: Text content
          required:
            - type
            - text
          additionalProperties: false
        - title: Image
          type: object
          properties:
            type:
              type: string
              enum:
                - image_url
              description: Content type is image URL
              default: image_url
            image_url:
              type: object
              description: Image information
              properties:
                url:
                  type: string
                  description: >-
                    Image URL or Base64 encoding. Image size limit is under 5M
                    per image, with pixels not exceeding 6000*6000. GLM-5V are
                    limited to 150 sheets.Supports jpg, png, jpeg formats.
              required:
                - url
              additionalProperties: false
          required:
            - type
            - image_url
          additionalProperties: false
        - title: Video
          type: object
          properties:
            type:
              type: string
              enum:
                - video_url
              description: Content type is video URL
              default: video_url
            video_url:
              type: object
              description: Video information.
              properties:
                url:
                  type: string
                  description: >-
                    Video URL address.The video size is limited to within 200
                    MB,and the format supports `mp4`，`mkv`，`mov`.
              required:
                - url
              additionalProperties: false
          required:
            - type
            - video_url
          additionalProperties: false
        - title: File
          type: object
          properties:
            type:
              type: string
              enum:
                - file
              description: >-
                Content type is file. New unified file type, compatible with the
                legacy `file_url` type but not recommended for new scenarios.
                Not support passing both the `file` and `image_url` or
                `video_url` parameters at the same time.
              default: file
            file:
              type: object
              description: >-
                File content, supports one of `file_id`, `file_url`, or
                `file_data`. Single file size limit is `50M`.
              properties:
                file_id:
                  type: string
                  description: >-
                    The ID returned by the [File Upload
                    API](/api-reference/agents/file-upload), only GLM-5.3-Flash
                    series supported.
                file_url:
                  type: string
                  description: >-
                    File URL address. Only GLM-5.3-Flash series. Supports
                    formats such as pdf, txt, word, jsonl, xlsx, pptx, with a
                    maximum of 50.
                file_data:
                  type: string
                  description: >-
                    Base64 file content in the format
                    `data:<MIME>;base64,<BASE64_DATA>`.
                filename:
                  type: string
                  description: File name.
              additionalProperties: false
          required:
            - type
            - file
          additionalProperties: false
    ChatCompletionResponseMessage:
      type: object
      properties:
        role:
          type: string
          description: Current conversation role, default is ‘assistant’ (model)
          example: assistant
        content:
          type: string
          description: >-
            Current conversation content. Hits function is null, otherwise
            returns model inference result.
        tool_calls:
          type: array
          description: >-
            Function names and parameters generated by the model that should be
            called.
          items:
            $ref: '#/components/schemas/ChatCompletionResponseMessageToolCall'
    WebSearchObjectResponse:
      type: object
      properties:
        title:
          type: string
          description: Title.
        content:
          type: string
          description: Content summary.
        link:
          type: string
          description: Result URL.
        media:
          type: string
          description: Website name.
        icon:
          type: string
          description: Website icon.
        refer:
          type: string
          description: Index number.
        publish_date:
          type: string
          description: Website publication date.
    FunctionObject:
      type: object
      properties:
        name:
          type: string
          description: >-
            The name of the function to be called. Must be a-z, A-Z, 0-9, or
            contain underscores and dashes, with a maximum length of 64.
          minLength: 1
          maxLength: 64
          pattern: ^[a-zA-Z0-9_-]+$
        description:
          type: string
          description: >-
            A description of what the function does, used by the model to choose
            when and how to call the function.
        parameters:
          $ref: '#/components/schemas/FunctionParameters'
      required:
        - name
        - description
        - parameters
    RetrievalObject:
      type: object
      properties:
        knowledge_id:
          type: string
          description: Knowledge base ID, created or obtained from the platform
        prompt_template:
          type: string
          description: >-
            Prompt template for requesting the model, a custom request template
            containing placeholders `{{ knowledge }}` and `{{ question }}`.
            Default template: Search for the answer to the question
            `{{question}}` in the document `{{ knowledge }}`. If an answer is
            found, respond only using statements from the document; if no answer
            is found, use your own knowledge to answer and inform the user that
            the information is not from the document. Do not repeat the
            question, start the answer directly.
      required:
        - knowledge_id
    WebSearchObject:
      type: object
      properties:
        enable:
          type: boolean
          description: |-
            Whether to enable search functionality.
            Default is `false`. Set to true to `enable`.
        search_engine:
          type: string
          description: |-
            Type of search engine.
            Default is `search_pro_jina`. Supports: `search_pro_jina`.
          enum:
            - search_pro_jina
        search_query:
          type: string
          description: Force trigger a search
        count:
          type: integer
          description: |
            Number of returned results
            Range: `1-50`, max `50` results per search
            Default is `10`
            Supported engines: `search_pro_jina`
          minimum: 1
          maximum: 50
        search_domain_filter:
          type: string
          description: >-
            Limits search results to specified whitelisted domains. Whitelist:
            input domains directly (e.g., www.example.com)

            Supported engines: `search_pro_jina`
        search_recency_filter:
          type: string
          description: |-
            Limits search to a specific time range.
            Default is `noLimit`
            Values:
            `oneDay`, within a day
            `oneWeek`, within a week
            `oneMonth`, within a month
            `oneYear`, within a year
            `noLimit`, no limit (default)
            Supported engines: `search_pro_jina`
          enum:
            - oneDay
            - oneWeek
            - oneMonth
            - oneYear
            - noLimit
        content_size:
          type: string
          description: >-
            Number of characters for webpage summaries.

            Default is `medium`

            `medium`: Balanced mode for most queries. 400-600 characters

            `high`: Maximizes context for comprehensive answers, 2500
            characters.
          enum:
            - medium
            - high
        result_sequence:
          type: string
          description: >-
            Specifies whether search results are shown before or after model
            response. Options: `before`, `after`. Default is `after`
          enum:
            - before
            - after
        search_result:
          type: boolean
          description: |-
            Whether to return search results in the response.
            Default is `false`
        require_search:
          type: boolean
          description: |-
            Whether to force model response based on search result.
            Default is `false`
        search_prompt:
          type: string
          description: >-
            Prompt to customize how search results are processed.

            Default Prompt:

            `You are an intelligent Q&A expert with the ability to synthesize
            information, recognize time, understand semantics, and clean
            contradictory data. The current date is {{current_date}}. Use this
            as the only time reference. Based on the following information,
            provide a comprehensive and accurate answer to the user's
            question.Only extract valuable content for the answer. Ensure the
            answer is timely and authoritative. State the answer directly
            without citing data sources or internal processes.`
      required:
        - search_engine
    ChatCompletionResponseMessageToolCall:
      type: object
      properties:
        function:
          type: object
          description: >-
            Contains the function name and JSON format parameters generated by
            the model.
          properties:
            name:
              type: string
              description: Model-generated function name.
            arguments:
              type: object
              description: >-
                JSON format of the function call parameters generated by the
                model. Validate the parameters before calling the function.
          required:
            - name
            - arguments
        id:
          type: string
          description: Unique identifier for the hit function.
        type:
          type: string
          description: Tool type called by the model, currently only supports ‘function’.
    FunctionParameters:
      type: object
      description: >-
        Parameters defined using JSON Schema. Must pass a JSON Schema object to
        accurately define accepted parameters. Omit if no parameters are needed
        when calling the function.
      additionalProperties: true
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      description: >-
        Use the following format for authentication: Bearer [<your api
        key>](https://z.ai/manage-apikey/apikey-list)

````

This documentation is built and hosted on [Mintlify](https://mintlify.com), a developer documentation platform.